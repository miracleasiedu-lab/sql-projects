# FIFA 23 Recruitment & Player Performance Analysis — MySQL Project

Relational MySQL model and recruitment analytics built from the FIFA 23 player dataset.
Every figure in the report was produced by the scripts in `sql/` on MySQL 8.0.46;
the exact outputs are saved in `results/`.

## Contents

| Folder | What it holds |
| --- | --- |
| `report/` | Full project report (add the export from the Claude Doc here; see below) |
| `sql/` | 10 numbered MySQL scripts: schema, load, cleaning, validation, KPIs, analyses, advanced SQL |
| `results/` | Captured output of each script from the final end-to-end run |
| `dataset/` | Source CSVs (players file is CRLF; teams file is LF) |
| `docs/` | Entity-relationship diagram (SVG) |

## How to run

From this folder, on MySQL 8.0+:

```bash
mysql -u root -p < sql/01_create_schema.sql
mysql --local-infile=1 -u root -p < sql/02_load_staging.sql
for f in 03 04 05 06 07 08 09 10; do mysql -u root -p --table < sql/${f}_*.sql; done
```

Script 02 loads `dataset/...` by relative path, so run it from this folder.
Integrity checks to look for in the output: script 03 reports `rating_mismatches = 0`
and 15 flagged clubs; script 04 reports 0 orphan foreign keys.

## Scripts

| Script | Purpose |
| --- | --- |
| 01_create_schema.sql | Database, staging, quarantine table, 7-table model with PK/FK/UNIQUE/CHECK |
| 02_load_staging.sql | LOAD DATA for both CSVs, row reconciliation |
| 03_clean_and_populate.sql | Profiling, de-duplication, placeholder → NULL, club flags, bridge + unpivot, reconciliation |
| 04_relationship_validation.sql | Proof the teams file cannot be joined; model integrity checks |
| 05_analysis_views.sql | vw_player_profile (analysis population: 18,401 real players) |
| 06_kpis.sql | Phase 1 — 10 KPIs |
| 07_univariate.sql | Phase 2 — 10 univariate analyses |
| 08_bivariate.sql | Phase 3 — 10 bivariate analyses |
| 09_multivariate.sql | Phase 4 — 10 multivariate analyses |
| 10_advanced_sql.sql | Views, window functions, recruitment score, shortlist, budget package (A1–A11) |

## Important data notes

- `dataset/teams_INCOMPATIBLE_NOT_FIFA.csv` is Olympic medal data (1964–2016). It is loaded
  only into the quarantine table `qrn_olympic_teams_raw` for validation and has no relationship
  to any model table. A FIFA 23 clubs file is needed for a genuine Players → Clubs model.
- AFC Richmond (fictional) is excluded from analysis. 15 clubs matching a generated-name
  pattern (20 players, all Brazilian) are excluded from the recruitment shortlist.
- Ratings and values are EA's FIFA 23 estimates at a single point in time, not live market data.
