/* =====================================================================
   07_univariate.sql — Phase 2: 10 univariate analyses
   ===================================================================== */
USE fifa23_recruitment;

-- U1: Age distribution
SELECT age_band, COUNT(*) AS players,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct
FROM vw_player_profile GROUP BY age_band ORDER BY age_band;

-- U2: Best-position distribution
SELECT position_group, best_position, COUNT(*) AS players,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct
FROM vw_player_profile
GROUP BY position_group, best_position, sort_order
ORDER BY sort_order;

-- U3: Nationality — top 15 talent sources
SELECT nationality, COUNT(*) AS players,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct
FROM vw_player_profile GROUP BY nationality
ORDER BY players DESC LIMIT 15;

-- U4: Overall rating — distribution percentiles (window functions)
WITH r AS (SELECT overall, PERCENT_RANK() OVER (ORDER BY overall) AS pr FROM vw_player_profile)
SELECT MIN(overall) AS min_overall,
       MIN(CASE WHEN pr >= 0.25 THEN overall END) AS p25,
       MIN(CASE WHEN pr >= 0.50 THEN overall END) AS p50,
       MIN(CASE WHEN pr >= 0.75 THEN overall END) AS p75,
       MIN(CASE WHEN pr >= 0.90 THEN overall END) AS p90,
       MIN(CASE WHEN pr >= 0.99 THEN overall END) AS p99,
       MAX(overall) AS max_overall,
       ROUND(STDDEV_POP(overall), 2) AS std_dev
FROM r;

-- U5: Potential — distribution by band
SELECT CASE WHEN potential >= 85 THEN '1. 85+ (world class)'
            WHEN potential >= 80 THEN '2. 80-84'
            WHEN potential >= 75 THEN '3. 75-79'
            WHEN potential >= 70 THEN '4. 70-74'
            ELSE '5. <70' END AS potential_band,
       COUNT(*) AS players, ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct
FROM vw_player_profile GROUP BY potential_band ORDER BY potential_band;

-- U6: Market value — distribution by band
SELECT CASE WHEN value_eur IS NULL     THEN '0. Not valued'
            WHEN value_eur <  500000   THEN '1. < 0.5m'
            WHEN value_eur < 1000000   THEN '2. 0.5-1m'
            WHEN value_eur < 5000000   THEN '3. 1-5m'
            WHEN value_eur < 20000000  THEN '4. 5-20m'
            WHEN value_eur < 50000000  THEN '5. 20-50m'
            ELSE '6. 50m+' END AS value_band,
       COUNT(*) AS players, ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct,
       ROUND(SUM(value_eur) / 1e9, 2) AS total_value_bn
FROM vw_player_profile GROUP BY value_band ORDER BY value_band;

-- U7: Wage — distribution by band
SELECT CASE WHEN wage_eur IS NULL   THEN '0. Free agent'
            WHEN wage_eur <  2000   THEN '1. < 2k'
            WHEN wage_eur <  5000   THEN '2. 2-5k'
            WHEN wage_eur < 20000   THEN '3. 5-20k'
            WHEN wage_eur < 50000   THEN '4. 20-50k'
            WHEN wage_eur <100000   THEN '5. 50-100k'
            ELSE '6. 100k+' END AS wage_band,
       COUNT(*) AS players, ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct
FROM vw_player_profile GROUP BY wage_band ORDER BY wage_band;

-- U8: Preferred foot and weak-foot rating
SELECT preferred_foot, COUNT(*) AS players,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct,
       ROUND(AVG(weak_foot_rating), 2) AS avg_weak_foot,
       SUM(weak_foot_rating >= 4) AS weak_foot_4_plus
FROM vw_player_profile GROUP BY preferred_foot;

-- U9: Contract expiry year
SELECT COALESCE(contract_until, 'Free agent') AS contract_until, COUNT(*) AS players,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct
FROM vw_player_profile GROUP BY contract_until ORDER BY contract_until;

-- U10: Growth headroom (Potential - Overall)
SELECT CASE WHEN growth_headroom = 0  THEN '1. 0 (at ceiling)'
            WHEN growth_headroom <= 4 THEN '2. 1-4'
            WHEN growth_headroom <= 9 THEN '3. 5-9'
            WHEN growth_headroom <=14 THEN '4. 10-14'
            ELSE '5. 15+' END AS headroom_band,
       COUNT(*) AS players, ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 1) AS pct,
       ROUND(AVG(age), 1) AS avg_age
FROM vw_player_profile GROUP BY headroom_band ORDER BY headroom_band;
