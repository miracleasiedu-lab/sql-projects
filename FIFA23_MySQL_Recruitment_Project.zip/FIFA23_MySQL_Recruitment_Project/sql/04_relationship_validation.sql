/* =====================================================================
   04_relationship_validation.sql
   Part A: can the supplied "teams" file be related to FIFA players?
   Part B: referential integrity and cardinality of the built model.
   ===================================================================== */
USE fifa23_recruitment;

/* ---------------- PART A: the supplied teams file ---------------- */

-- A1. Grain and time span of the teams file
SELECT COUNT(*) AS rows_total,
       COUNT(DISTINCT team) AS distinct_team_codes,
       COUNT(DISTINCT CONCAT(team, '|', year)) AS distinct_team_year,
       MIN(year) AS first_year, MAX(year) AS last_year,
       COUNT(DISTINCT year) AS editions,
       SUM(prev_medals = '') AS missing_prev_medals
FROM qrn_olympic_teams_raw;

-- A2. Club-level join attempts: club name vs team code and vs country (expect 0)
SELECT
  (SELECT COUNT(*) FROM dim_club c JOIN (SELECT DISTINCT team FROM qrn_olympic_teams_raw) t ON t.team = c.club_name)       AS clubs_matching_team_code,
  (SELECT COUNT(*) FROM dim_club c JOIN (SELECT DISTINCT country FROM qrn_olympic_teams_raw) t ON t.country = c.club_name) AS clubs_matching_country;

-- A3. The tempting false join: nationality name vs Olympic country name
SELECT COUNT(*) AS nationalities,
       SUM(t.country IS NOT NULL) AS names_that_match,
       SUM(t.country IS NULL) AS names_unmatched
FROM dim_nationality n
LEFT JOIN (SELECT DISTINCT country FROM qrn_olympic_teams_raw) t ON t.country = n.nationality_name;

-- A4. Unmatched nationalities (shows the semantic mismatch: home nations compete as Great Britain)
SELECT n.nationality_name, COUNT(p.player_id) AS players
FROM dim_nationality n
JOIN player p ON p.nationality_id = n.nationality_id
LEFT JOIN (SELECT DISTINCT country FROM qrn_olympic_teams_raw) t ON t.country = n.nationality_name
WHERE t.country IS NULL
GROUP BY n.nationality_name
ORDER BY players DESC;

-- A5. Fan-out proof: joining on nationality multiplies player rows (grain violation)
SELECT (SELECT COUNT(*) FROM player) AS player_rows,
       COUNT(*) AS rows_after_join,
       ROUND(COUNT(*) / (SELECT COUNT(*) FROM player), 2) AS multiplication_factor
FROM player p
JOIN dim_nationality n ON n.nationality_id = p.nationality_id
JOIN qrn_olympic_teams_raw t ON t.country = n.nationality_name;

/* ---------------- PART B: model integrity ---------------- */

-- B1. Primary-key uniqueness and orphan foreign keys (all orphan counts should be 0)
SELECT
  (SELECT COUNT(*) - COUNT(DISTINCT player_id) FROM player)                                         AS dup_player_ids,
  (SELECT COUNT(*) FROM player p LEFT JOIN dim_club c ON c.club_id = p.club_id
     WHERE p.club_id IS NOT NULL AND c.club_id IS NULL)                                              AS orphan_club_fk,
  (SELECT COUNT(*) FROM player p LEFT JOIN dim_nationality n ON n.nationality_id = p.nationality_id
     WHERE n.nationality_id IS NULL)                                                                 AS orphan_nationality_fk,
  (SELECT COUNT(*) FROM player p LEFT JOIN dim_position d ON d.position_code = p.best_position
     WHERE d.position_code IS NULL)                                                                  AS orphan_position_fk,
  (SELECT COUNT(*) FROM player_attributes a LEFT JOIN player p ON p.player_id = a.player_id
     WHERE p.player_id IS NULL)                                                                      AS orphan_attributes,
  (SELECT COUNT(*) FROM player WHERE club_id IS NULL)                                                AS players_without_club;

-- B2. Unmatched records in both directions (clubs with no players; players with no attributes)
SELECT
  (SELECT COUNT(*) FROM dim_club c WHERE NOT EXISTS (SELECT 1 FROM player p WHERE p.club_id = c.club_id))        AS clubs_without_players,
  (SELECT COUNT(*) FROM player p WHERE NOT EXISTS (SELECT 1 FROM player_attributes a WHERE a.player_id = p.player_id)) AS players_without_attributes,
  (SELECT COUNT(*) FROM player p WHERE (SELECT COUNT(*) FROM player_position_rating r WHERE r.player_id = p.player_id) <> 17) AS players_without_17_ratings;

-- B3. Cardinality of Club 1 : N Player
SELECT MIN(n) AS min_players_per_club, MAX(n) AS max_players_per_club,
       ROUND(AVG(n), 1) AS avg_players_per_club
FROM (SELECT club_id, COUNT(*) AS n FROM player WHERE club_id IS NOT NULL GROUP BY club_id) x;

-- B4. Cardinality of Player M : N Position (bridge)
SELECT MIN(n) AS min_positions, MAX(n) AS max_positions, ROUND(AVG(n), 2) AS avg_positions
FROM (SELECT player_id, COUNT(*) AS n FROM player_position GROUP BY player_id) x;

-- B5. Consistency: is best_position one of the positions the player is listed at?
SELECT SUM(EXISTS (SELECT 1 FROM player_position pp
                   WHERE pp.player_id = p.player_id AND pp.position_code = p.best_position)) AS best_pos_in_listed,
       SUM(NOT EXISTS (SELECT 1 FROM player_position pp
                   WHERE pp.player_id = p.player_id AND pp.position_code = p.best_position)) AS best_pos_not_listed
FROM player p;

-- B6. Natural-key check: jersey numbers unique within each club
SELECT COUNT(*) AS duplicate_club_jersey_pairs
FROM (SELECT club_id, club_jersey_number FROM player
      WHERE club_id IS NOT NULL GROUP BY club_id, club_jersey_number HAVING COUNT(*) > 1) x;
