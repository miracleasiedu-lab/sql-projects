/* =====================================================================
   FIFA 23 Recruitment & Player Performance Analysis
   01_create_schema.sql  —  MySQL 8.0+
   Creates: staging layer, quarantine table, normalised analytical model
   ===================================================================== */

DROP DATABASE IF EXISTS fifa23_recruitment;
CREATE DATABASE fifa23_recruitment
  CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE fifa23_recruitment;

/* ---------------------------------------------------------------------
   LAYER 1 — STAGING (raw text, loaded 1:1 from CSV, no transformation)
   All columns VARCHAR(150) (longest source value is 48 chars) so that placeholder values such as '-' load
   without silent truncation or coercion to 0.
   --------------------------------------------------------------------- */
CREATE TABLE stg_players_raw (
    stg_row_id                   INT AUTO_INCREMENT PRIMARY KEY,
    known_as                     VARCHAR(150),  -- source: 'Known As'
    full_name                    VARCHAR(150),  -- source: 'Full Name'
    overall                      VARCHAR(150),  -- source: 'Overall'
    potential                    VARCHAR(150),  -- source: 'Potential'
    value_eur                    VARCHAR(150),  -- source: 'Value(in Euro)'
    positions_played             VARCHAR(150),  -- source: 'Positions Played'
    best_position                VARCHAR(150),  -- source: 'Best Position'
    nationality                  VARCHAR(150),  -- source: 'Nationality'
    image_link                   VARCHAR(150),  -- source: 'Image Link'
    age                          VARCHAR(150),  -- source: 'Age'
    height_cm                    VARCHAR(150),  -- source: 'Height(in cm)'
    weight_kg                    VARCHAR(150),  -- source: 'Weight(in kg)'
    total_stats                  VARCHAR(150),  -- source: 'TotalStats'
    base_stats                   VARCHAR(150),  -- source: 'BaseStats'
    club_name                    VARCHAR(150),  -- source: 'Club Name'
    wage_eur                     VARCHAR(150),  -- source: 'Wage(in Euro)'
    release_clause               VARCHAR(150),  -- source: 'Release Clause'
    club_position                VARCHAR(150),  -- source: 'Club Position'
    contract_until               VARCHAR(150),  -- source: 'Contract Until'
    club_jersey_number           VARCHAR(150),  -- source: 'Club Jersey Number'
    joined_on                    VARCHAR(150),  -- source: 'Joined On'
    on_loan                      VARCHAR(150),  -- source: 'On Loan'
    preferred_foot               VARCHAR(150),  -- source: 'Preferred Foot'
    weak_foot_rating             VARCHAR(150),  -- source: 'Weak Foot Rating'
    skill_moves                  VARCHAR(150),  -- source: 'Skill Moves'
    international_reputation     VARCHAR(150),  -- source: 'International Reputation'
    national_team_name           VARCHAR(150),  -- source: 'National Team Name'
    national_team_image_link     VARCHAR(150),  -- source: 'National Team Image Link'
    national_team_position       VARCHAR(150),  -- source: 'National Team Position'
    national_team_jersey_number  VARCHAR(150),  -- source: 'National Team Jersey Number'
    attacking_work_rate          VARCHAR(150),  -- source: 'Attacking Work Rate'
    defensive_work_rate          VARCHAR(150),  -- source: 'Defensive Work Rate'
    pace_total                   VARCHAR(150),  -- source: 'Pace Total'
    shooting_total               VARCHAR(150),  -- source: 'Shooting Total'
    passing_total                VARCHAR(150),  -- source: 'Passing Total'
    dribbling_total              VARCHAR(150),  -- source: 'Dribbling Total'
    defending_total              VARCHAR(150),  -- source: 'Defending Total'
    physicality_total            VARCHAR(150),  -- source: 'Physicality Total'
    crossing                     VARCHAR(150),  -- source: 'Crossing'
    finishing                    VARCHAR(150),  -- source: 'Finishing'
    heading_accuracy             VARCHAR(150),  -- source: 'Heading Accuracy'
    short_passing                VARCHAR(150),  -- source: 'Short Passing'
    volleys                      VARCHAR(150),  -- source: 'Volleys'
    dribbling                    VARCHAR(150),  -- source: 'Dribbling'
    curve                        VARCHAR(150),  -- source: 'Curve'
    freekick_accuracy            VARCHAR(150),  -- source: 'Freekick Accuracy'
    long_passing                 VARCHAR(150),  -- source: 'LongPassing'
    ball_control                 VARCHAR(150),  -- source: 'BallControl'
    acceleration                 VARCHAR(150),  -- source: 'Acceleration'
    sprint_speed                 VARCHAR(150),  -- source: 'Sprint Speed'
    agility                      VARCHAR(150),  -- source: 'Agility'
    reactions                    VARCHAR(150),  -- source: 'Reactions'
    balance                      VARCHAR(150),  -- source: 'Balance'
    shot_power                   VARCHAR(150),  -- source: 'Shot Power'
    jumping                      VARCHAR(150),  -- source: 'Jumping'
    stamina                      VARCHAR(150),  -- source: 'Stamina'
    strength                     VARCHAR(150),  -- source: 'Strength'
    long_shots                   VARCHAR(150),  -- source: 'Long Shots'
    aggression                   VARCHAR(150),  -- source: 'Aggression'
    interceptions                VARCHAR(150),  -- source: 'Interceptions'
    positioning                  VARCHAR(150),  -- source: 'Positioning'
    vision                       VARCHAR(150),  -- source: 'Vision'
    penalties                    VARCHAR(150),  -- source: 'Penalties'
    composure                    VARCHAR(150),  -- source: 'Composure'
    marking                      VARCHAR(150),  -- source: 'Marking'
    standing_tackle              VARCHAR(150),  -- source: 'Standing Tackle'
    sliding_tackle               VARCHAR(150),  -- source: 'Sliding Tackle'
    goalkeeper_diving            VARCHAR(150),  -- source: 'Goalkeeper Diving'
    goalkeeper_handling          VARCHAR(150),  -- source: 'Goalkeeper Handling'
    goalkeeper_kicking           VARCHAR(150),  -- source: ' GoalkeeperKicking'
    goalkeeper_positioning       VARCHAR(150),  -- source: 'Goalkeeper Positioning'
    goalkeeper_reflexes          VARCHAR(150),  -- source: 'Goalkeeper Reflexes'
    st_rating                    VARCHAR(150),  -- source: 'ST Rating'
    lw_rating                    VARCHAR(150),  -- source: 'LW Rating'
    lf_rating                    VARCHAR(150),  -- source: 'LF Rating'
    cf_rating                    VARCHAR(150),  -- source: 'CF Rating'
    rf_rating                    VARCHAR(150),  -- source: 'RF Rating'
    rw_rating                    VARCHAR(150),  -- source: 'RW Rating'
    cam_rating                   VARCHAR(150),  -- source: 'CAM Rating'
    lm_rating                    VARCHAR(150),  -- source: 'LM Rating'
    cm_rating                    VARCHAR(150),  -- source: 'CM Rating'
    rm_rating                    VARCHAR(150),  -- source: 'RM Rating'
    lwb_rating                   VARCHAR(150),  -- source: 'LWB Rating'
    cdm_rating                   VARCHAR(150),  -- source: 'CDM Rating'
    rwb_rating                   VARCHAR(150),  -- source: 'RWB Rating'
    lb_rating                    VARCHAR(150),  -- source: 'LB Rating'
    cb_rating                    VARCHAR(150),  -- source: 'CB Rating'
    rb_rating                    VARCHAR(150),  -- source: 'RB Rating'
    gk_rating                    VARCHAR(150)   -- source: 'GK Rating'
) ENGINE=InnoDB;

/* Quarantine: the supplied "teams" file. Loaded ONLY so that the
   relationship-validation script can prove, in SQL, that it does not
   relate to FIFA clubs. It is NOT part of the analytical model and has
   no foreign key to any model table. */
CREATE TABLE qrn_olympic_teams_raw (
    team            VARCHAR(10),
    country         VARCHAR(100),
    year            SMALLINT,
    events          INT,
    athletes        INT,
    age             DECIMAL(5,1),
    height          DECIMAL(5,1),
    weight          DECIMAL(5,1),
    medals          INT,
    prev_medals     VARCHAR(20),   -- empty string in source = missing
    prev_3_medals   VARCHAR(20)
) ENGINE=InnoDB;

/* ---------------------------------------------------------------------
   LAYER 2 — ANALYTICAL MODEL (3NF core + bridge tables)
   --------------------------------------------------------------------- */

-- Club dimension: one row per distinct real club name.
-- The source has NO league/country/club-rating columns, so none are invented.
CREATE TABLE dim_club (
    club_id        SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    club_name      VARCHAR(100) NOT NULL,
    is_fictional   TINYINT(1)   NOT NULL DEFAULT 0,   -- AFC Richmond (Ted Lasso licence)
    is_name_unverified TINYINT(1) NOT NULL DEFAULT 0, -- squad pattern of generated names (see 03, step 3.3b)
    CONSTRAINT uq_club_name UNIQUE (club_name)
) ENGINE=InnoDB;

-- Nationality dimension
CREATE TABLE dim_nationality (
    nationality_id    SMALLINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nationality_name  VARCHAR(60) NOT NULL,
    CONSTRAINT uq_nationality UNIQUE (nationality_name)
) ENGINE=InnoDB;

-- Position dimension: the 17 position codes that carry a rating column.
-- position_name / position_group are standard football reference labels
-- for the codes (a lookup, not player data).
CREATE TABLE dim_position (
    position_code   VARCHAR(3)  PRIMARY KEY,
    position_name   VARCHAR(40) NOT NULL,
    position_group  ENUM('Goalkeeper','Defender','Midfielder','Forward') NOT NULL,
    sort_order      TINYINT NOT NULL
) ENGINE=InnoDB;

-- Player fact/entity table: one row per unique player (grain = player)
CREATE TABLE player (
    player_id                    INT UNSIGNED PRIMARY KEY,      -- SoFIFA ID parsed from Image Link
    known_as                     VARCHAR(60)  NOT NULL,
    full_name                    VARCHAR(100) NOT NULL,
    age                          TINYINT UNSIGNED NOT NULL,
    height_cm                    SMALLINT UNSIGNED NOT NULL,
    weight_kg                    SMALLINT UNSIGNED NOT NULL,
    preferred_foot               ENUM('Left','Right') NOT NULL,
    nationality_id               SMALLINT UNSIGNED NOT NULL,
    club_id                      SMALLINT UNSIGNED NULL,        -- NULL = free agent
    best_position                VARCHAR(3) NOT NULL,
    club_position                VARCHAR(3) NULL,               -- includes SUB / RES
    overall                      TINYINT UNSIGNED NOT NULL,
    potential                    TINYINT UNSIGNED NOT NULL,
    value_eur                    INT UNSIGNED NULL,             -- NULL = not valued (source 0)
    wage_eur                     INT UNSIGNED NULL,             -- NULL = free agent (source 0)
    release_clause_eur           INT UNSIGNED NULL,             -- NULL = no clause (source 0)
    contract_until               SMALLINT UNSIGNED NULL,
    joined_on                    SMALLINT UNSIGNED NULL,
    club_jersey_number           TINYINT UNSIGNED NULL,
    is_on_loan                   TINYINT(1) NOT NULL,
    international_reputation     TINYINT UNSIGNED NOT NULL,
    weak_foot_rating             TINYINT UNSIGNED NOT NULL,
    skill_moves                  TINYINT UNSIGNED NOT NULL,
    attacking_work_rate          ENUM('Low','Medium','High') NOT NULL,
    defensive_work_rate          ENUM('Low','Medium','High') NOT NULL,
    is_national_team_player      TINYINT(1) NOT NULL,
    national_team_position       VARCHAR(3) NULL,
    national_team_jersey_number  TINYINT UNSIGNED NULL,
    total_stats                  SMALLINT UNSIGNED NOT NULL,
    base_stats                   SMALLINT UNSIGNED NOT NULL,
    image_link                   VARCHAR(255) NOT NULL,
    CONSTRAINT fk_player_club        FOREIGN KEY (club_id)        REFERENCES dim_club(club_id),
    CONSTRAINT fk_player_nationality FOREIGN KEY (nationality_id) REFERENCES dim_nationality(nationality_id),
    CONSTRAINT fk_player_best_pos    FOREIGN KEY (best_position)  REFERENCES dim_position(position_code),
    CONSTRAINT uq_club_jersey        UNIQUE (club_id, club_jersey_number),
    CONSTRAINT ck_potential          CHECK (potential >= overall),
    CONSTRAINT ck_rating_range       CHECK (overall BETWEEN 1 AND 99 AND potential BETWEEN 1 AND 99),
    CONSTRAINT ck_age                CHECK (age BETWEEN 15 AND 50),
    INDEX ix_player_club (club_id),
    INDEX ix_player_pos_age (best_position, age),
    INDEX ix_player_overall (overall),
    INDEX ix_player_value (value_eur)
) ENGINE=InnoDB;

-- 1:1 extension: detailed attributes (kept separate to keep player narrow)
CREATE TABLE player_attributes (
    player_id              INT UNSIGNED PRIMARY KEY,
    pace_total             TINYINT UNSIGNED, shooting_total   TINYINT UNSIGNED,
    passing_total          TINYINT UNSIGNED, dribbling_total  TINYINT UNSIGNED,
    defending_total        TINYINT UNSIGNED, physicality_total TINYINT UNSIGNED,
    crossing TINYINT UNSIGNED, finishing TINYINT UNSIGNED, heading_accuracy TINYINT UNSIGNED,
    short_passing TINYINT UNSIGNED, volleys TINYINT UNSIGNED, dribbling TINYINT UNSIGNED,
    curve TINYINT UNSIGNED, freekick_accuracy TINYINT UNSIGNED, long_passing TINYINT UNSIGNED,
    ball_control TINYINT UNSIGNED, acceleration TINYINT UNSIGNED, sprint_speed TINYINT UNSIGNED,
    agility TINYINT UNSIGNED, reactions TINYINT UNSIGNED, balance TINYINT UNSIGNED,
    shot_power TINYINT UNSIGNED, jumping TINYINT UNSIGNED, stamina TINYINT UNSIGNED,
    strength TINYINT UNSIGNED, long_shots TINYINT UNSIGNED, aggression TINYINT UNSIGNED,
    interceptions TINYINT UNSIGNED, positioning TINYINT UNSIGNED, vision TINYINT UNSIGNED,
    penalties TINYINT UNSIGNED, composure TINYINT UNSIGNED, marking TINYINT UNSIGNED,
    standing_tackle TINYINT UNSIGNED, sliding_tackle TINYINT UNSIGNED,
    gk_diving TINYINT UNSIGNED, gk_handling TINYINT UNSIGNED, gk_kicking TINYINT UNSIGNED,
    gk_positioning TINYINT UNSIGNED, gk_reflexes TINYINT UNSIGNED,
    CONSTRAINT fk_attr_player FOREIGN KEY (player_id) REFERENCES player(player_id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- M:N bridge: every position a player is listed as playing (from 'Positions Played')
CREATE TABLE player_position (
    player_id       INT UNSIGNED NOT NULL,
    position_code   VARCHAR(3)   NOT NULL,
    listed_order    TINYINT UNSIGNED NOT NULL,      -- 1 = first listed
    PRIMARY KEY (player_id, position_code),
    CONSTRAINT fk_pp_player   FOREIGN KEY (player_id)     REFERENCES player(player_id) ON DELETE CASCADE,
    CONSTRAINT fk_pp_position FOREIGN KEY (position_code) REFERENCES dim_position(position_code)
) ENGINE=InnoDB;

-- 1:N long table: the in-game rating of every player at every one of the 17 positions
CREATE TABLE player_position_rating (
    player_id       INT UNSIGNED NOT NULL,
    position_code   VARCHAR(3)   NOT NULL,
    rating          TINYINT UNSIGNED NOT NULL,
    PRIMARY KEY (player_id, position_code),
    INDEX ix_ppr_pos_rating (position_code, rating),
    CONSTRAINT fk_ppr_player   FOREIGN KEY (player_id)     REFERENCES player(player_id) ON DELETE CASCADE,
    CONSTRAINT fk_ppr_position FOREIGN KEY (position_code) REFERENCES dim_position(position_code)
) ENGINE=InnoDB;
