/* =====================================================================
   10_advanced_sql.sql — views, window functions, recruitment shortlist
   ===================================================================== */
USE fifa23_recruitment;

/* ---------- A1. VIEW: peer benchmarks and within-position percentiles ---------- */
CREATE OR REPLACE VIEW vw_value_benchmark AS
SELECT v.*,
       AVG(value_eur) OVER w_peer                                   AS peer_avg_value,
       COUNT(*)       OVER w_peer                                   AS peer_n,
       value_eur / AVG(value_eur) OVER w_peer                       AS value_vs_peers,
       PERCENT_RANK() OVER (PARTITION BY best_position ORDER BY overall)   AS pr_overall_in_pos,
       PERCENT_RANK() OVER (PARTITION BY best_position ORDER BY potential) AS pr_potential_in_pos
FROM vw_player_profile v
WHERE value_eur IS NOT NULL
WINDOW w_peer AS (PARTITION BY overall, age_band, position_group);

/* ---------- A2. VIEW: composite recruitment score (0-100) ----------
   40% potential percentile within position
 + 30% overall percentile within position
 + 30% price efficiency (1 - percentile of value_vs_peers within position; cheaper vs peers = higher)
   Eligible: age <= 24, potential >= 78, value <= EUR 25m (assumed budget cap),
   excluding clubs flagged name_unverified (identity cannot be confirmed for scouting) */
CREATE OR REPLACE VIEW vw_recruitment_score AS
WITH eligible AS (
    SELECT b.*
    FROM vw_value_benchmark b
    WHERE age <= 24 AND potential >= 78 AND value_eur <= 25000000
      AND name_unverified = 0
), scored AS (
    SELECT e.*,
           1 - PERCENT_RANK() OVER (PARTITION BY best_position ORDER BY value_vs_peers) AS price_efficiency
    FROM eligible e
)
SELECT s.*,
       ROUND(100 * (0.40 * pr_potential_in_pos + 0.30 * pr_overall_in_pos + 0.30 * price_efficiency), 1)
           AS recruitment_score
FROM scored s;

SELECT COUNT(*) AS eligible_players FROM vw_recruitment_score;

/* ---------- A3. SHORTLIST: top 3 per position with ROW_NUMBER ---------- */
WITH ranked AS (
    SELECT r.*,
           ROW_NUMBER() OVER (PARTITION BY best_position
                              ORDER BY recruitment_score DESC, potential DESC,
                                       value_eur ASC, player_id ASC) AS pos_rank   -- deterministic tie-break
    FROM vw_recruitment_score r
)
SELECT best_position, pos_rank, known_as, age, club_name, overall, potential,
       ROUND(value_eur / 1e6, 1) AS value_m, ROUND(value_vs_peers, 2) AS value_vs_peers,
       wage_eur, contract_until, recruitment_score
FROM ranked
WHERE pos_rank <= 3
ORDER BY sort_order, pos_rank;

/* ---------- A4. RANK vs DENSE_RANK: clubs by strength of their best XI ---------- */
WITH xi AS (
    SELECT club_id, club_name, overall,
           ROW_NUMBER() OVER (PARTITION BY club_id ORDER BY overall DESC) AS rn
    FROM vw_player_profile WHERE club_id IS NOT NULL
), club_xi AS (
    SELECT club_name, ROUND(AVG(overall), 1) AS best_xi_avg_overall
    FROM xi WHERE rn <= 11 GROUP BY club_id, club_name
)
SELECT club_name, best_xi_avg_overall,
       RANK()       OVER (ORDER BY best_xi_avg_overall DESC) AS rank_with_gaps,
       DENSE_RANK() OVER (ORDER BY best_xi_avg_overall DESC) AS dense_rank_no_gaps
FROM club_xi
ORDER BY best_xi_avg_overall DESC
LIMIT 15;

/* ---------- A5. NTILE: value quartiles within position — where is potential cheapest? ---------- */
WITH q AS (
    SELECT position_group, potential, age,
           NTILE(4) OVER (PARTITION BY best_position ORDER BY value_eur) AS value_quartile
    FROM vw_player_profile WHERE value_eur IS NOT NULL
)
SELECT value_quartile,
       COUNT(*) AS players,
       SUM(potential >= 80 AND age <= 21) AS hp_u21,
       ROUND(100 * AVG(potential >= 80 AND age <= 21), 2) AS pct_hp_u21
FROM q GROUP BY value_quartile ORDER BY value_quartile;

/* ---------- A6. LAG: marginal cost of one extra Overall point ---------- */
WITH by_rating AS (
    SELECT overall, AVG(value_eur) AS avg_value
    FROM vw_player_profile WHERE value_eur IS NOT NULL AND overall BETWEEN 70 AND 88
    GROUP BY overall
)
SELECT overall,
       ROUND(avg_value / 1e6, 2)                                        AS avg_value_m,
       ROUND((avg_value - LAG(avg_value) OVER (ORDER BY overall)) / 1e6, 2) AS marginal_cost_m,
       ROUND(100 * (avg_value / LAG(avg_value) OVER (ORDER BY overall) - 1), 1) AS pct_increase
FROM by_rating ORDER BY overall;

/* ---------- A7. Hidden wingers: U23s rated 78+ at LW or RW whose best position is elsewhere
              (uses the long player_position_rating table + bridge table) ---------- */
WITH wing AS (
    SELECT r.player_id, MAX(r.rating) AS best_wing_rating
    FROM player_position_rating r
    WHERE r.position_code IN ('LW','RW')
    GROUP BY r.player_id
)
SELECT v.known_as, v.age, v.best_position, v.club_name, v.overall, v.potential,
       w.best_wing_rating,
       EXISTS (SELECT 1 FROM player_position pp
               WHERE pp.player_id = v.player_id AND pp.position_code IN ('LW','RW')) AS listed_as_winger,
       ROUND(v.value_eur / 1e6, 1) AS value_m
FROM vw_player_profile v
JOIN wing w ON w.player_id = v.player_id
WHERE v.age <= 23 AND w.best_wing_rating >= 78 AND v.best_position NOT IN ('LW','RW')
ORDER BY w.best_wing_rating DESC, v.potential DESC, v.player_id
LIMIT 12;

SELECT COUNT(*) AS u23_rated_78_at_wing,
       SUM(v.best_position IN ('LW','RW')) AS best_pos_is_wing
FROM vw_player_profile v
JOIN (SELECT player_id, MAX(rating) AS mx FROM player_position_rating
      WHERE position_code IN ('LW','RW') GROUP BY player_id) w ON w.player_id = v.player_id
WHERE v.age <= 23 AND w.mx >= 78;

/* ---------- A8. Club comparison: squad value share and youth pipeline ranks ---------- */
WITH club AS (
    SELECT club_name,
           SUM(value_eur) AS squad_value,
           AVG(CASE WHEN age <= 23 THEN potential END) AS u23_avg_potential,
           SUM(age <= 23) AS u23_players
    FROM vw_player_profile WHERE club_id IS NOT NULL
    GROUP BY club_id, club_name
)
SELECT club_name,
       ROUND(squad_value / 1e6, 0) AS squad_value_m,
       ROUND(100 * squad_value / SUM(squad_value) OVER (), 2) AS pct_of_market_value,
       RANK() OVER (ORDER BY squad_value DESC) AS value_rank,
       ROUND(u23_avg_potential, 1) AS u23_avg_potential,
       u23_players,
       RANK() OVER (ORDER BY u23_avg_potential DESC) AS pipeline_rank
FROM club
WHERE u23_players >= 5
ORDER BY pipeline_rank
LIMIT 12;

/* ---------- A9. Correlated subquery: standout players at their club (>= 10 above club average)
              — strong candidates whose clubs are likely sellers ---------- */
SELECT v.known_as, v.age, v.best_position, v.club_name, v.overall, v.potential,
       ROUND((SELECT AVG(v2.overall) FROM vw_player_profile v2 WHERE v2.club_id = v.club_id), 1) AS club_avg_overall,
       ROUND(v.value_eur / 1e6, 1) AS value_m
FROM vw_player_profile v
WHERE v.club_id IS NOT NULL AND v.age <= 25 AND v.potential >= 80
  AND v.overall >= 10 + (SELECT AVG(v2.overall) FROM vw_player_profile v2 WHERE v2.club_id = v.club_id)
ORDER BY v.potential DESC, v.overall DESC
LIMIT 12;

/* ---------- A10. Running total: how far does a EUR 60m budget go down the ranked shortlist? ---------- */
WITH best_per_pos AS (
    SELECT r.*, ROW_NUMBER() OVER (PARTITION BY best_position
                                   ORDER BY recruitment_score DESC, potential DESC,
                                            value_eur ASC, player_id ASC) AS rn
    FROM vw_recruitment_score r
), picks AS (
    SELECT known_as, best_position, age, overall, potential, value_eur, recruitment_score
    FROM best_per_pos WHERE rn = 1
)
SELECT known_as, best_position, age, overall, potential,
       ROUND(value_eur / 1e6, 1) AS value_m, recruitment_score,
       ROUND(SUM(value_eur) OVER (ORDER BY recruitment_score DESC, value_eur ASC
             ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) / 1e6, 1) AS cumulative_spend_m,
       CASE WHEN SUM(value_eur) OVER (ORDER BY recruitment_score DESC, value_eur ASC
             ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) <= 60000000
            THEN 'Within EUR 60m' ELSE 'Over budget' END AS budget_status
FROM picks
ORDER BY recruitment_score DESC, value_eur ASC;

/* ---------- A11. Budget-first package: cheapest first choices scoring >= 90 that fit EUR 60m ---------- */
WITH best_per_pos AS (
    SELECT r.*, ROW_NUMBER() OVER (PARTITION BY best_position
                                   ORDER BY recruitment_score DESC, potential DESC,
                                            value_eur ASC, player_id ASC) AS rn
    FROM vw_recruitment_score r
), cheap_first AS (
    SELECT known_as, best_position, age, overall, potential, value_eur, recruitment_score,
           SUM(value_eur) OVER (ORDER BY value_eur ASC, recruitment_score DESC
                                ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS cumulative_spend
    FROM best_per_pos
    WHERE rn = 1 AND recruitment_score >= 90
)
SELECT known_as, best_position, age, overall, potential,
       ROUND(value_eur / 1e6, 1) AS value_m, recruitment_score,
       ROUND(cumulative_spend / 1e6, 1) AS cumulative_spend_m
FROM cheap_first
WHERE cumulative_spend <= 60000000
ORDER BY value_eur;
