/* =====================================================================
   03_clean_and_populate.sql — data-quality profiling, cleaning, and
   population of the analytical model from staging.
   ===================================================================== */
USE fifa23_recruitment;

/* ---------- 3.1 Pre-cleaning profile (evidence for the DQ assessment) ---------- */

-- Exact duplicate rows (all 89 source columns identical)
SELECT COUNT(*) AS total_rows,
       COUNT(DISTINCT image_link) AS distinct_image_links,
       COUNT(*) - COUNT(DISTINCT image_link) AS duplicate_rows
FROM stg_players_raw;

-- Do duplicate image links differ in any other field? (0 = pure duplicates)
SELECT COUNT(*) AS dup_groups_with_differences
FROM (
    SELECT image_link
    FROM stg_players_raw
    GROUP BY image_link
    HAVING COUNT(*) > 1
       AND COUNT(DISTINCT CONCAT_WS('|', known_as, full_name, overall, potential, value_eur,
             club_name, wage_eur, age, contract_until, positions_played, release_clause)) > 1
) d;

-- Every image link follows the SoFIFA pattern, so player_id can be derived from it
SELECT SUM(image_link REGEXP '^https://cdn\\.sofifa\\.net/players/[0-9]{3}/[0-9]{3}/23_60\\.png$') AS valid_pattern,
       COUNT(*) AS total
FROM stg_players_raw;

-- Placeholder and zero counts on the de-duplicated population
WITH d AS (SELECT DISTINCT * FROM (SELECT image_link, club_name, value_eur, wage_eur, release_clause,
                  on_loan, national_team_name, contract_until FROM stg_players_raw) x)
SELECT SUM(club_name = 'Free agent')            AS free_agents,
       SUM(value_eur = '0')                     AS value_zero,
       SUM(value_eur = '0' AND club_name <> 'Free agent') AS value_zero_contracted,
       SUM(wage_eur = '0')                      AS wage_zero,
       SUM(release_clause = '0')                AS release_clause_zero,
       SUM(on_loan = 'TRUE')                    AS on_loan,
       SUM(national_team_name = '-')            AS no_national_team,
       SUM(contract_until = '2022')             AS contract_ends_2022
FROM d;

/* ---------- 3.2 Dimensions ---------- */

INSERT INTO dim_position (position_code, position_name, position_group, sort_order) VALUES
 ('GK','Goalkeeper','Goalkeeper',1),
 ('RB','Right Back','Defender',2),('RWB','Right Wing-Back','Defender',3),
 ('CB','Centre Back','Defender',4),
 ('LB','Left Back','Defender',5),('LWB','Left Wing-Back','Defender',6),
 ('CDM','Defensive Midfielder','Midfielder',7),('CM','Central Midfielder','Midfielder',8),
 ('CAM','Attacking Midfielder','Midfielder',9),
 ('RM','Right Midfielder','Midfielder',10),('LM','Left Midfielder','Midfielder',11),
 ('RW','Right Winger','Forward',12),('LW','Left Winger','Forward',13),
 ('RF','Right Forward','Forward',14),('LF','Left Forward','Forward',15),
 ('CF','Centre Forward','Forward',16),('ST','Striker','Forward',17);

-- Free agent is a status, not a club, so it is excluded from dim_club
INSERT INTO dim_club (club_name, is_fictional)
SELECT DISTINCT TRIM(club_name), (TRIM(club_name) = 'AFC Richmond')
FROM stg_players_raw
WHERE TRIM(club_name) <> 'Free agent'
ORDER BY 1;

INSERT INTO dim_nationality (nationality_name)
SELECT DISTINCT TRIM(nationality) FROM stg_players_raw ORDER BY 1;

/* ---------- 3.3 Player (dedupe via PK + INSERT IGNORE; placeholders -> NULL) ---------- */

INSERT IGNORE INTO player
SELECT
    CAST(REGEXP_REPLACE(REGEXP_SUBSTR(s.image_link, 'players/[0-9]{3}/[0-9]{3}'), '[^0-9]', '') AS UNSIGNED) AS player_id,
    TRIM(s.known_as), TRIM(s.full_name),
    CAST(s.age AS UNSIGNED), CAST(s.height_cm AS UNSIGNED), CAST(s.weight_kg AS UNSIGNED),
    s.preferred_foot,
    n.nationality_id,
    c.club_id,                                                   -- NULL for free agents (no match)
    s.best_position,
    NULLIF(s.club_position, '-'),
    CAST(s.overall AS UNSIGNED), CAST(s.potential AS UNSIGNED),
    NULLIF(CAST(s.value_eur AS UNSIGNED), 0),
    NULLIF(CAST(s.wage_eur AS UNSIGNED), 0),
    NULLIF(CAST(s.release_clause AS UNSIGNED), 0),
    CAST(NULLIF(s.contract_until, '-') AS UNSIGNED),
    CASE WHEN s.club_name = 'Free agent' THEN NULL ELSE CAST(s.joined_on AS UNSIGNED) END,
    CAST(NULLIF(s.club_jersey_number, '-') AS UNSIGNED),
    (s.on_loan = 'TRUE'),
    CAST(s.international_reputation AS UNSIGNED),
    CAST(s.weak_foot_rating AS UNSIGNED), CAST(s.skill_moves AS UNSIGNED),
    s.attacking_work_rate, s.defensive_work_rate,
    (s.national_team_name <> '-'),
    NULLIF(s.national_team_position, '-'),
    CAST(NULLIF(s.national_team_jersey_number, '-') AS UNSIGNED),
    CAST(s.total_stats AS UNSIGNED), CAST(s.base_stats AS UNSIGNED),
    s.image_link
FROM stg_players_raw s
JOIN dim_nationality n ON n.nationality_name = TRIM(s.nationality)
LEFT JOIN dim_club c   ON c.club_name = TRIM(s.club_name)
ORDER BY s.stg_row_id;

/* ---------- 3.3b Flag clubs whose squads match the generated-name pattern ----------
   FIFA 23 is widely reported to use generated player names for unlicensed Brazilian squads.
   Data rule: exactly 20 players, 100% Brazilian nationality. 15 clubs qualify; the next
   closest club in the data is 41% Brazilian, so the rule separates cleanly. */
UPDATE dim_club c
JOIN (
    SELECT p.club_id
    FROM player p JOIN dim_nationality n ON n.nationality_id = p.nationality_id
    GROUP BY p.club_id
    HAVING COUNT(*) = 20 AND SUM(n.nationality_name = 'Brazil') = 20
) g ON g.club_id = c.club_id
SET c.is_name_unverified = 1;

SELECT COUNT(*) AS clubs_flagged_name_unverified FROM dim_club WHERE is_name_unverified = 1;

INSERT INTO player_attributes
SELECT DISTINCT
    p.player_id,
    s.pace_total, s.shooting_total, s.passing_total, s.dribbling_total, s.defending_total, s.physicality_total,
    s.crossing, s.finishing, s.heading_accuracy, s.short_passing, s.volleys, s.dribbling, s.curve,
    s.freekick_accuracy, s.long_passing, s.ball_control, s.acceleration, s.sprint_speed, s.agility,
    s.reactions, s.balance, s.shot_power, s.jumping, s.stamina, s.strength, s.long_shots, s.aggression,
    s.interceptions, s.positioning, s.vision, s.penalties, s.composure, s.marking, s.standing_tackle,
    s.sliding_tackle, s.goalkeeper_diving, s.goalkeeper_handling, s.goalkeeper_kicking,
    s.goalkeeper_positioning, s.goalkeeper_reflexes
FROM stg_players_raw s
JOIN player p ON p.image_link = s.image_link;

/* ---------- 3.4 Bridge: split the multi-valued 'Positions Played' field ---------- */
INSERT INTO player_position (player_id, position_code, listed_order)
WITH RECURSIVE dedup AS (
    SELECT DISTINCT p.player_id, s.positions_played
    FROM stg_players_raw s JOIN player p ON p.image_link = s.image_link
), split AS (
    SELECT player_id, 1 AS n,
           TRIM(SUBSTRING_INDEX(positions_played, ',', 1)) AS pos,
           positions_played AS full_list
    FROM dedup
    UNION ALL
    SELECT player_id, n + 1,
           TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(full_list, ',', n + 1), ',', -1)),
           full_list
    FROM split
    WHERE n < 1 + LENGTH(full_list) - LENGTH(REPLACE(full_list, ',', ''))
)
SELECT player_id, pos, n FROM split;

/* ---------- 3.5 Long table: unpivot the 17 position-rating columns ----------
   Plain UNION ALL is used deliberately: an earlier CROSS JOIN LATERAL version returned
   correct rows when filtered to one player but stored wrong ratings in the full INSERT
   on MySQL 8.0.46. The reconciliation query in 3.6 proves the long table matches source. */
INSERT INTO player_position_rating (player_id, position_code, rating)
WITH d AS (
    SELECT DISTINCT p.player_id,
           s.st_rating, s.lw_rating, s.lf_rating, s.cf_rating, s.rf_rating, s.rw_rating,
           s.cam_rating, s.lm_rating, s.cm_rating, s.rm_rating, s.lwb_rating, s.cdm_rating,
           s.rwb_rating, s.lb_rating, s.cb_rating, s.rb_rating, s.gk_rating
    FROM stg_players_raw s JOIN player p ON p.image_link = s.image_link
)
    SELECT player_id, 'ST', CAST(st_rating AS UNSIGNED) FROM d
    UNION ALL SELECT player_id, 'LW', CAST(lw_rating AS UNSIGNED) FROM d
    UNION ALL SELECT player_id, 'LF', CAST(lf_rating AS UNSIGNED) FROM d
    UNION ALL SELECT player_id, 'CF', CAST(cf_rating AS UNSIGNED) FROM d
    UNION ALL SELECT player_id, 'RF', CAST(rf_rating AS UNSIGNED) FROM d
    UNION ALL SELECT player_id, 'RW', CAST(rw_rating AS UNSIGNED) FROM d
    UNION ALL SELECT player_id, 'CAM', CAST(cam_rating AS UNSIGNED) FROM d
    UNION ALL SELECT player_id, 'LM', CAST(lm_rating AS UNSIGNED) FROM d
    UNION ALL SELECT player_id, 'CM', CAST(cm_rating AS UNSIGNED) FROM d
    UNION ALL SELECT player_id, 'RM', CAST(rm_rating AS UNSIGNED) FROM d
    UNION ALL SELECT player_id, 'LWB', CAST(lwb_rating AS UNSIGNED) FROM d
    UNION ALL SELECT player_id, 'CDM', CAST(cdm_rating AS UNSIGNED) FROM d
    UNION ALL SELECT player_id, 'RWB', CAST(rwb_rating AS UNSIGNED) FROM d
    UNION ALL SELECT player_id, 'LB', CAST(lb_rating AS UNSIGNED) FROM d
    UNION ALL SELECT player_id, 'CB', CAST(cb_rating AS UNSIGNED) FROM d
    UNION ALL SELECT player_id, 'RB', CAST(rb_rating AS UNSIGNED) FROM d
    UNION ALL SELECT player_id, 'GK', CAST(gk_rating AS UNSIGNED) FROM d;

/* ---------- 3.6 Post-load reconciliation ---------- */
SELECT 'dim_club' AS tbl, COUNT(*) AS row_count FROM dim_club
UNION ALL SELECT 'dim_nationality', COUNT(*) FROM dim_nationality
UNION ALL SELECT 'dim_position', COUNT(*) FROM dim_position
UNION ALL SELECT 'player', COUNT(*) FROM player
UNION ALL SELECT 'player_attributes', COUNT(*) FROM player_attributes
UNION ALL SELECT 'player_position', COUNT(*) FROM player_position
UNION ALL SELECT 'player_position_rating', COUNT(*) FROM player_position_rating;

-- Reconciliation: every unpivoted rating must equal its source column (expect 0 mismatches)
SELECT COUNT(*) AS rating_mismatches
FROM player_position_rating r
JOIN player p ON p.player_id = r.player_id
JOIN stg_players_raw s ON s.image_link = p.image_link
WHERE r.rating <> CAST(CASE r.position_code
        WHEN 'ST' THEN s.st_rating WHEN 'LW' THEN s.lw_rating WHEN 'LF' THEN s.lf_rating
        WHEN 'CF' THEN s.cf_rating WHEN 'RF' THEN s.rf_rating WHEN 'RW' THEN s.rw_rating
        WHEN 'CAM' THEN s.cam_rating WHEN 'LM' THEN s.lm_rating WHEN 'CM' THEN s.cm_rating
        WHEN 'RM' THEN s.rm_rating WHEN 'LWB' THEN s.lwb_rating WHEN 'CDM' THEN s.cdm_rating
        WHEN 'RWB' THEN s.rwb_rating WHEN 'LB' THEN s.lb_rating WHEN 'CB' THEN s.cb_rating
        WHEN 'RB' THEN s.rb_rating WHEN 'GK' THEN s.gk_rating END AS UNSIGNED);

-- Spot check against a known source row (Mbappe: ST 92, LW 90, GK 21 in the CSV)
SELECT p.known_as, r.position_code, r.rating
FROM player_position_rating r JOIN player p USING (player_id)
WHERE p.player_id = 231747 AND r.position_code IN ('ST','LW','GK');
