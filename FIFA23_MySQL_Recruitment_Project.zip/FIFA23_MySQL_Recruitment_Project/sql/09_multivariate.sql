/* =====================================================================
   09_multivariate.sql — Phase 4: 10 multivariate analyses
   ===================================================================== */
USE fifa23_recruitment;

-- M1: Young (<=21), high-potential (>=80), affordable (<= EUR 10m) players by position group
SELECT position_group,
       COUNT(*)                         AS candidates,
       ROUND(AVG(potential), 1)         AS avg_potential,
       ROUND(AVG(overall), 1)           AS avg_overall,
       ROUND(AVG(value_eur) / 1e6, 2)   AS avg_value_m
FROM vw_player_profile
WHERE age <= 21 AND potential >= 80 AND value_eur <= 10000000
GROUP BY position_group
ORDER BY FIELD(position_group, 'Goalkeeper','Defender','Midfielder','Forward');

-- M2: Undervalued — value vs like-for-like peers (same Overall, age band AND position group).
--     Position group is essential: goalkeepers are priced well below outfielders of equal Overall.
WITH peer AS (
    SELECT v.*,
           AVG(value_eur) OVER (PARTITION BY overall, age_band, position_group) AS peer_avg_value,
           COUNT(*)       OVER (PARTITION BY overall, age_band, position_group) AS peer_n
    FROM vw_player_profile v
    WHERE value_eur IS NOT NULL
)
SELECT known_as, age, best_position, club_name, overall, potential,
       ROUND(value_eur / 1e6, 2)       AS value_m,
       ROUND(peer_avg_value / 1e6, 2)  AS peer_avg_m,
       ROUND(value_eur / peer_avg_value, 2) AS value_vs_peers,
       contract_until
FROM peer
WHERE overall >= 75 AND age <= 29 AND peer_n >= 5
ORDER BY value_vs_peers ASC, overall DESC
LIMIT 15;

-- M2b: what drives the discount? peer-relative value by contract expiry year (Overall >= 75)
WITH peer AS (
    SELECT v.*, AVG(value_eur) OVER (PARTITION BY overall, age_band, position_group) AS peer_avg_value
    FROM vw_player_profile v WHERE value_eur IS NOT NULL
)
SELECT contract_until, COUNT(*) AS players,
       ROUND(AVG(value_eur / peer_avg_value), 2) AS avg_value_vs_peers
FROM peer WHERE overall >= 75
GROUP BY contract_until ORDER BY contract_until;

-- M3: Wage value — players earning least relative to peers of the same Overall and position group
--     (Overall >= 78, age <= 29 so the list is recruitable rather than retiring veterans)
WITH w AS (
    SELECT v.*,
           AVG(wage_eur) OVER (PARTITION BY overall, position_group) AS peer_avg_wage
    FROM vw_player_profile v WHERE wage_eur IS NOT NULL
)
SELECT known_as, age, best_position, club_name, overall, potential,
       wage_eur, ROUND(peer_avg_wage, 0) AS peer_avg_wage,
       ROUND(wage_eur / peer_avg_wage, 2) AS wage_vs_peers,
       ROUND(value_eur / 1e6, 2) AS value_m
FROM w
WHERE overall >= 78 AND age <= 29
ORDER BY wage_vs_peers ASC
LIMIT 15;

-- M4: Clubs with the greatest concentration of high-potential players (age <= 23, potential >= 80)
SELECT club_name,
       COUNT(*)                                        AS squad,
       SUM(age <= 23 AND potential >= 80)              AS hp_u23,
       ROUND(100 * AVG(age <= 23 AND potential >= 80), 1) AS pct_of_squad,
       ROUND(AVG(CASE WHEN age <= 23 AND potential >= 80 THEN potential END), 1) AS avg_hp_potential
FROM vw_player_profile WHERE club_id IS NOT NULL
GROUP BY club_id, club_name
ORDER BY hp_u23 DESC, avg_hp_potential DESC
LIMIT 12;

-- M5: Current ability + future potential: Overall >= 78, Potential >= 85, age <= 23
SELECT known_as, age, best_position, club_name, overall, potential, growth_headroom,
       ROUND(value_eur / 1e6, 1) AS value_m, wage_eur, contract_until
FROM vw_player_profile
WHERE overall >= 78 AND potential >= 85 AND age <= 23
ORDER BY potential DESC, overall DESC
LIMIT 15;

SELECT COUNT(*) AS m5_pool, ROUND(AVG(value_eur)/1e6,1) AS avg_value_m,
       SUM(value_eur <= 40000000) AS priced_40m_or_less
FROM vw_player_profile WHERE overall >= 78 AND potential >= 85 AND age <= 23;

-- M6: Position group x age band — ability and price matrix
SELECT position_group, age_band, COUNT(*) AS players,
       ROUND(AVG(overall), 1) AS avg_overall, ROUND(AVG(potential), 1) AS avg_potential,
       ROUND(AVG(value_eur) / 1e6, 2) AS avg_value_m
FROM vw_player_profile
GROUP BY position_group, age_band
ORDER BY FIELD(position_group, 'Goalkeeper','Defender','Midfielder','Forward'), age_band;

-- M7: Affordable position upgrades. Two tiers, age <= 27:
--     tier A = Overall >= 75 and value <= EUR 5m (the ideal), tier B = Overall >= 72 and value <= EUR 3m.
--     ROW_NUMBER picks the highest-rated tier-B option per position.
WITH pool AS (
    SELECT v.*,
           ROW_NUMBER() OVER (PARTITION BY best_position ORDER BY overall DESC, potential DESC, value_eur ASC) AS rn
    FROM vw_player_profile v
    WHERE age <= 27 AND overall >= 72 AND value_eur <= 3000000
)
SELECT p.best_position,
       (SELECT COUNT(*) FROM vw_player_profile t
         WHERE t.best_position = p.best_position AND t.age <= 27
           AND t.overall >= 75 AND t.value_eur <= 5000000)               AS tier_a_75plus_le5m,
       COUNT(*)                                                          AS tier_b_72plus_le3m,
       ROUND(AVG(p.overall), 1)                                          AS tier_b_avg_overall,
       ROUND(AVG(p.value_eur) / 1e6, 2)                                  AS tier_b_avg_value_m,
       MAX(CASE WHEN p.rn = 1 THEN CONCAT(p.known_as, ' (', p.overall, '/', p.potential, ', ',
                ROUND(p.value_eur / 1e6, 1), 'm, ', p.club_name, ')') END) AS top_option
FROM pool p
GROUP BY p.best_position, p.sort_order
ORDER BY p.sort_order;

-- M8: Low-cost acquisition routes — expiring contracts (<=2023, not on loan) and free agents, Overall >= 76, age <= 29
SELECT CASE WHEN is_free_agent = 1 THEN 'Free agent' ELSE 'Expiring <= 2023' END AS route,
       known_as, age, best_position, club_name, overall, potential,
       ROUND(value_eur / 1e6, 2) AS value_m, contract_until
FROM vw_player_profile
WHERE overall >= 76 AND age <= 29 AND is_on_loan = 0
  AND (is_free_agent = 1 OR contract_until <= 2023)
ORDER BY overall DESC, potential DESC
LIMIT 15;

SELECT SUM(is_free_agent = 0) AS expiring_candidates, SUM(is_free_agent = 1) AS free_agent_candidates
FROM vw_player_profile
WHERE overall >= 76 AND age <= 29 AND is_on_loan = 0 AND (is_free_agent = 1 OR contract_until <= 2023);

-- M9: Nationality x position group — top talent pipelines (U23, Potential >= 80)
SELECT nationality,
       COUNT(*) AS hp_u23,
       SUM(position_group = 'Goalkeeper') AS gk,
       SUM(position_group = 'Defender')   AS def,
       SUM(position_group = 'Midfielder') AS mid,
       SUM(position_group = 'Forward')    AS fwd,
       ROUND(AVG(potential), 1) AS avg_potential
FROM vw_player_profile
WHERE age <= 23 AND potential >= 80
GROUP BY nationality
ORDER BY hp_u23 DESC LIMIT 10;

-- M10: What separates elite (Overall >= 80) from the rest, by position group (face-stat deltas)
SELECT position_group,
       SUM(overall >= 80) AS elite_n,
       ROUND(AVG(CASE WHEN overall >= 80 THEN pace_total END)        - AVG(CASE WHEN overall < 80 THEN pace_total END), 1)        AS d_pace,
       ROUND(AVG(CASE WHEN overall >= 80 THEN shooting_total END)    - AVG(CASE WHEN overall < 80 THEN shooting_total END), 1)    AS d_shooting,
       ROUND(AVG(CASE WHEN overall >= 80 THEN passing_total END)     - AVG(CASE WHEN overall < 80 THEN passing_total END), 1)     AS d_passing,
       ROUND(AVG(CASE WHEN overall >= 80 THEN dribbling_total END)   - AVG(CASE WHEN overall < 80 THEN dribbling_total END), 1)   AS d_dribbling,
       ROUND(AVG(CASE WHEN overall >= 80 THEN defending_total END)   - AVG(CASE WHEN overall < 80 THEN defending_total END), 1)   AS d_defending,
       ROUND(AVG(CASE WHEN overall >= 80 THEN physicality_total END) - AVG(CASE WHEN overall < 80 THEN physicality_total END), 1) AS d_physical
FROM vw_player_profile
WHERE position_group <> 'Goalkeeper'
GROUP BY position_group
ORDER BY FIELD(position_group, 'Defender','Midfielder','Forward');
