/* =====================================================================
   02_load_staging.sql — bulk-load raw CSVs into staging (no transformation)
   Run with:  mysql --local-infile=1 -u <user> -p < 02_load_staging.sql
   Edit the two file paths to where the CSVs live on your machine.
   ===================================================================== */
USE fifa23_recruitment;
SET GLOBAL local_infile = 1;

TRUNCATE TABLE stg_players_raw;
LOAD DATA LOCAL INFILE 'dataset/players_fifa23.csv'
INTO TABLE stg_players_raw
CHARACTER SET utf8mb4
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\r\n'          -- players file uses Windows (CRLF) line endings
IGNORE 1 LINES
(known_as,full_name,overall,potential,value_eur,positions_played,best_position,nationality,image_link,age,height_cm,weight_kg,total_stats,base_stats,club_name,wage_eur,release_clause,club_position,contract_until,club_jersey_number,joined_on,on_loan,preferred_foot,weak_foot_rating,skill_moves,international_reputation,national_team_name,national_team_image_link,national_team_position,national_team_jersey_number,attacking_work_rate,defensive_work_rate,pace_total,shooting_total,passing_total,dribbling_total,defending_total,physicality_total,crossing,finishing,heading_accuracy,short_passing,volleys,dribbling,curve,freekick_accuracy,long_passing,ball_control,acceleration,sprint_speed,agility,reactions,balance,shot_power,jumping,stamina,strength,long_shots,aggression,interceptions,positioning,vision,penalties,composure,marking,standing_tackle,sliding_tackle,goalkeeper_diving,goalkeeper_handling,goalkeeper_kicking,goalkeeper_positioning,goalkeeper_reflexes,st_rating,lw_rating,lf_rating,cf_rating,rf_rating,rw_rating,cam_rating,lm_rating,cm_rating,rm_rating,lwb_rating,cdm_rating,rwb_rating,lb_rating,cb_rating,rb_rating,gk_rating);

TRUNCATE TABLE qrn_olympic_teams_raw;
LOAD DATA LOCAL INFILE 'dataset/teams_INCOMPATIBLE_NOT_FIFA.csv'
INTO TABLE qrn_olympic_teams_raw
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'            -- teams file uses Unix (LF) line endings
IGNORE 1 LINES
(team, country, year, events, athletes, age, height, weight, medals, prev_medals, prev_3_medals);

-- Load reconciliation: expect 18,539 and 2,144 (= CSV line counts minus header),
-- and no stray carriage returns left in the last column
SELECT SUM(gk_rating LIKE CONCAT('%', CHAR(13), '%')) AS rows_with_carriage_return FROM stg_players_raw;
SELECT 'stg_players_raw' AS table_name, COUNT(*) AS rows_loaded FROM stg_players_raw
UNION ALL
SELECT 'qrn_olympic_teams_raw', COUNT(*) FROM qrn_olympic_teams_raw;
