/* =====================================================================
   05_analysis_views.sql — reusable analytical layer
   Analysis population: all real players (AFC Richmond is fictional and excluded).
   ===================================================================== */
USE fifa23_recruitment;

CREATE OR REPLACE VIEW vw_player_profile AS
SELECT
    p.player_id, p.known_as, p.full_name, p.age,
    CASE WHEN p.age <= 21 THEN '1. U21 (<=21)'
         WHEN p.age <= 25 THEN '2. 22-25'
         WHEN p.age <= 29 THEN '3. 26-29'
         WHEN p.age <= 32 THEN '4. 30-32'
         ELSE                  '5. 33+' END                       AS age_band,
    n.nationality_name                                            AS nationality,
    c.club_id, COALESCE(c.club_name, 'Free agent')                AS club_name,
    (p.club_id IS NULL)                                           AS is_free_agent,
    COALESCE(c.is_name_unverified, 0)                             AS name_unverified,
    p.best_position, d.position_name, d.position_group, d.sort_order,
    p.overall, p.potential, p.potential - p.overall               AS growth_headroom,
    p.value_eur, p.wage_eur, p.release_clause_eur,
    p.contract_until, p.is_on_loan, p.international_reputation,
    p.is_national_team_player, p.preferred_foot, p.height_cm, p.skill_moves, p.weak_foot_rating,
    a.pace_total, a.shooting_total, a.passing_total, a.dribbling_total,
    a.defending_total, a.physicality_total
FROM player p
JOIN dim_nationality n   ON n.nationality_id = p.nationality_id
JOIN dim_position d      ON d.position_code  = p.best_position
JOIN player_attributes a ON a.player_id      = p.player_id
LEFT JOIN dim_club c     ON c.club_id        = p.club_id        -- LEFT keeps free agents
WHERE COALESCE(c.is_fictional, 0) = 0;

SELECT COUNT(*) AS analysis_population FROM vw_player_profile;
