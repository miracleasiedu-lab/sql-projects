/* =====================================================================
   06_kpis.sql — Phase 1: 10 recruitment KPIs (population: vw_player_profile)
   ===================================================================== */
USE fifa23_recruitment;

-- KPI 1: Size of the scouting universe
SELECT COUNT(*)                         AS players,
       COUNT(DISTINCT club_id)          AS clubs,
       COUNT(DISTINCT nationality)      AS nationalities,
       SUM(is_free_agent)               AS free_agents,
       SUM(is_on_loan)                  AS on_loan
FROM vw_player_profile;

-- KPI 2: Average current ability vs ceiling
SELECT ROUND(AVG(overall), 2)          AS avg_overall,
       ROUND(AVG(potential), 2)        AS avg_potential,
       ROUND(AVG(growth_headroom), 2)  AS avg_growth_headroom
FROM vw_player_profile;

-- KPI 3: Age profile
SELECT ROUND(AVG(age), 2)                              AS avg_age,
       ROUND(100 * AVG(age <= 21), 1)                  AS pct_u21,
       ROUND(100 * AVG(age >= 30), 1)                  AS pct_30_plus
FROM vw_player_profile;

-- KPI 4: Market value — total, mean and true median (window-function median)
WITH v AS (
    SELECT value_eur,
           ROW_NUMBER() OVER (ORDER BY value_eur) AS rn,
           COUNT(*)     OVER ()                   AS n
    FROM vw_player_profile WHERE value_eur IS NOT NULL
)
SELECT ROUND(SUM(value_eur) / 1e9, 2)  AS total_value_bn_eur,
       ROUND(AVG(value_eur) / 1e6, 2)  AS mean_value_m_eur,
       ROUND(AVG(CASE WHEN rn IN (FLOOR((n + 1) / 2), CEIL((n + 1) / 2)) THEN value_eur END) / 1e6, 2)
                                       AS median_value_m_eur,
       MAX(n)                          AS valued_players
FROM v;

-- KPI 5: Wage bill (Wage(in Euro) as recorded; FIFA convention is a weekly wage)
SELECT ROUND(SUM(wage_eur) / 1e6, 2)   AS total_wages_m_eur,
       ROUND(AVG(wage_eur), 0)         AS mean_wage_eur,
       MAX(wage_eur)                   AS max_wage_eur
FROM vw_player_profile WHERE wage_eur IS NOT NULL;

-- KPI 6: Elite ability share (Overall >= 80)
SELECT SUM(overall >= 80)                    AS elite_players,
       ROUND(100 * AVG(overall >= 80), 2)    AS pct_elite,
       ROUND(100 * SUM(CASE WHEN overall >= 80 THEN value_eur END) / SUM(value_eur), 1)
                                             AS pct_of_total_value
FROM vw_player_profile;

-- KPI 7: High-potential youth pool (age <= 21, potential >= 80)
SELECT SUM(age <= 21 AND potential >= 80)                  AS hp_youth,
       ROUND(100 * SUM(age <= 21 AND potential >= 80) / SUM(age <= 21), 1) AS pct_of_u21,
       ROUND(AVG(CASE WHEN age <= 21 AND potential >= 80 THEN value_eur END) / 1e6, 2) AS avg_value_m_eur
FROM vw_player_profile;

-- KPI 8: Contract-expiry exposure (contracts ending 2022 or 2023 = cheaper to acquire)
SELECT SUM(contract_until <= 2023)                            AS expiring_by_2023,
       ROUND(100 * SUM(contract_until <= 2023) / COUNT(contract_until), 1) AS pct_of_contracted,
       SUM(contract_until <= 2023 AND overall >= 75)          AS expiring_and_75_plus
FROM vw_player_profile;

-- KPI 9: Release-clause coverage and price premium over market value
SELECT COUNT(release_clause_eur)                                         AS players_with_clause,
       ROUND(100 * COUNT(release_clause_eur) / COUNT(*), 1)              AS pct_with_clause,
       ROUND(AVG(release_clause_eur / value_eur), 2)                     AS avg_clause_to_value_multiple
FROM vw_player_profile;

-- KPI 10: Value per rating point (EUR of market value per Overall point), by tier
SELECT CASE WHEN overall >= 80 THEN '80+' WHEN overall >= 70 THEN '70-79'
            WHEN overall >= 60 THEN '60-69' ELSE '<60' END              AS overall_tier,
       COUNT(*)                                                         AS players,
       ROUND(AVG(value_eur / overall), 0)                               AS eur_per_overall_point
FROM vw_player_profile WHERE value_eur IS NOT NULL
GROUP BY overall_tier
ORDER BY MIN(overall) DESC;
