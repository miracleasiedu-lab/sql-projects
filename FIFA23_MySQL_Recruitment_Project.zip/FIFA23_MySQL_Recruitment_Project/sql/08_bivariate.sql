/* =====================================================================
   08_bivariate.sql — Phase 3: 10 bivariate analyses
   Pearson r is computed in SQL: (E[xy]-E[x]E[y]) / (sd_x * sd_y)
   ===================================================================== */
USE fifa23_recruitment;

-- B1: Age vs market value (and ability) by age
SELECT age, COUNT(*) AS players,
       ROUND(AVG(overall), 1)          AS avg_overall,
       ROUND(AVG(potential), 1)        AS avg_potential,
       ROUND(AVG(value_eur) / 1e6, 2)  AS avg_value_m
FROM vw_player_profile
WHERE value_eur IS NOT NULL AND age BETWEEN 17 AND 36
GROUP BY age ORDER BY age;

-- B2: Overall vs market value — correlation on raw and log scale
SELECT ROUND((AVG(overall * value_eur) - AVG(overall) * AVG(value_eur))
             / (STDDEV_POP(overall) * STDDEV_POP(value_eur)), 3)            AS r_overall_value,
       ROUND((AVG(overall * LN(value_eur)) - AVG(overall) * AVG(LN(value_eur)))
             / (STDDEV_POP(overall) * STDDEV_POP(LN(value_eur))), 3)        AS r_overall_log_value
FROM vw_player_profile WHERE value_eur IS NOT NULL;

-- B2b: average value at each Overall rating from 70 upward
SELECT overall, COUNT(*) AS players, ROUND(AVG(value_eur) / 1e6, 2) AS avg_value_m
FROM vw_player_profile WHERE value_eur IS NOT NULL AND overall >= 70
GROUP BY overall ORDER BY overall;

-- B3: Potential vs market value — correlation and by potential band
SELECT ROUND((AVG(potential * LN(value_eur)) - AVG(potential) * AVG(LN(value_eur)))
             / (STDDEV_POP(potential) * STDDEV_POP(LN(value_eur))), 3)      AS r_potential_log_value
FROM vw_player_profile WHERE value_eur IS NOT NULL;

SELECT CASE WHEN potential >= 85 THEN '85+' WHEN potential >= 80 THEN '80-84'
            WHEN potential >= 75 THEN '75-79' WHEN potential >= 70 THEN '70-74' ELSE '<70' END AS potential_band,
       COUNT(*) AS players, ROUND(AVG(value_eur) / 1e6, 2) AS avg_value_m,
       ROUND(AVG(overall), 1) AS avg_overall
FROM vw_player_profile WHERE value_eur IS NOT NULL
GROUP BY potential_band ORDER BY MIN(potential) DESC;

-- B4: Club vs player value — top 15 clubs by squad value
SELECT club_name, COUNT(*) AS squad,
       ROUND(SUM(value_eur) / 1e6, 1) AS squad_value_m,
       ROUND(AVG(value_eur) / 1e6, 2) AS avg_value_m,
       ROUND(AVG(overall), 1)         AS avg_overall
FROM vw_player_profile WHERE club_id IS NOT NULL
GROUP BY club_id, club_name
ORDER BY squad_value_m DESC LIMIT 15;

-- B5: Position vs overall rating (and value)
SELECT best_position, COUNT(*) AS players,
       ROUND(AVG(overall), 2) AS avg_overall,
       MAX(overall)           AS max_overall,
       ROUND(AVG(value_eur) / 1e6, 2) AS avg_value_m
FROM vw_player_profile
GROUP BY best_position, sort_order ORDER BY sort_order;

-- B6: Overall vs wage — correlation and wage by tier
SELECT ROUND((AVG(overall * LN(wage_eur)) - AVG(overall) * AVG(LN(wage_eur)))
             / (STDDEV_POP(overall) * STDDEV_POP(LN(wage_eur))), 3) AS r_overall_log_wage
FROM vw_player_profile WHERE wage_eur IS NOT NULL;

SELECT CASE WHEN overall >= 85 THEN '85+' WHEN overall >= 80 THEN '80-84' WHEN overall >= 75 THEN '75-79'
            WHEN overall >= 70 THEN '70-74' WHEN overall >= 65 THEN '65-69' ELSE '<65' END AS overall_tier,
       COUNT(*) AS players, ROUND(AVG(wage_eur), 0) AS avg_wage_eur
FROM vw_player_profile WHERE wage_eur IS NOT NULL
GROUP BY overall_tier ORDER BY MIN(overall) DESC;

-- B7: Nationality vs quality — nations with 100+ players, ranked by average overall
SELECT nationality, COUNT(*) AS players, ROUND(AVG(overall), 2) AS avg_overall,
       SUM(overall >= 80) AS players_80_plus
FROM vw_player_profile
GROUP BY nationality HAVING COUNT(*) >= 100
ORDER BY avg_overall DESC LIMIT 12;

-- B8: Age vs growth headroom
SELECT age, COUNT(*) AS players, ROUND(AVG(growth_headroom), 2) AS avg_headroom,
       ROUND(100 * AVG(growth_headroom = 0), 1) AS pct_at_ceiling
FROM vw_player_profile WHERE age BETWEEN 17 AND 31
GROUP BY age ORDER BY age;

-- B9: International reputation vs value
SELECT international_reputation, COUNT(*) AS players,
       ROUND(AVG(overall), 1) AS avg_overall,
       ROUND(AVG(value_eur) / 1e6, 2) AS avg_value_m
FROM vw_player_profile WHERE value_eur IS NOT NULL
GROUP BY international_reputation ORDER BY international_reputation;

-- B10: Loan status vs age/ability profile
SELECT CASE WHEN is_on_loan = 1 THEN 'On loan' ELSE 'Not on loan' END AS loan_status,
       COUNT(*) AS players, ROUND(AVG(age), 1) AS avg_age,
       ROUND(AVG(overall), 1) AS avg_overall, ROUND(AVG(potential), 1) AS avg_potential,
       ROUND(AVG(growth_headroom), 1) AS avg_headroom
FROM vw_player_profile WHERE is_free_agent = 0
GROUP BY loan_status;
