-- =====================================================================
--  STUDENT PERFORMANCE & EDUCATIONAL EQUITY ANALYSIS
--  40 SQL Queries across 4 Phases: KPI | Univariate | Bivariate | Multivariate
--
--  Table:   student_performance  (1,000 rows)
--  Dataset: StudentsPerformance.csv  ("Students Performance in Exams", Kaggle)
--
--  Written for MySQL 8.0+ (uses CTEs and window functions). The report's
--  results were produced on SQLite, where every query also runs unmodified.
-- =====================================================================

-- ---------------------------------------------------------------------
-- SETUP: create the table and load the CSV
-- The CSV's column names contain spaces and slashes, so they are renamed
-- to snake_case, and a surrogate student_id key is added (used by NTILE).
-- ---------------------------------------------------------------------
CREATE TABLE student_performance (
  student_id          INT AUTO_INCREMENT PRIMARY KEY,
  gender              VARCHAR(10),
  race_ethnicity      VARCHAR(20),
  parental_education  VARCHAR(40),
  lunch               VARCHAR(20),
  test_prep           VARCHAR(20),
  math_score          INT,
  reading_score       INT,
  writing_score       INT
);

LOAD DATA LOCAL INFILE 'StudentsPerformance.csv'
INTO TABLE student_performance
FIELDS TERMINATED BY ',' ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES
(gender, race_ethnicity, parental_education, lunch, test_prep,
 math_score, reading_score, writing_score);

-- #####################################################################
-- PHASE 1: KEY PERFORMANCE INDICATORS  (10 queries)
-- #####################################################################

-- KPI 1: Overall Composite Average Score
-- Business question: What is the baseline academic performance of the entire school?
SELECT ROUND(AVG((math_score + reading_score + writing_score)/3.0), 2) AS overall_avg_composite_score
FROM student_performance;

-- KPI 2: Average Math Score
-- Business question: How is the student body performing specifically in Mathematics?
SELECT ROUND(AVG(math_score), 2) AS avg_math_score
FROM student_performance;

-- KPI 3: Average Reading Score
-- Business question: How is the student body performing in Reading?
SELECT ROUND(AVG(reading_score), 2) AS avg_reading_score
FROM student_performance;

-- KPI 4: Average Writing Score
-- Business question: How is the student body performing in Writing?
SELECT ROUND(AVG(writing_score), 2) AS avg_writing_score
FROM student_performance;

-- KPI 5: Overall Pass Rate (composite score >= 60)
-- Business question: What percentage of students are meeting the minimum competency bar?
SELECT ROUND(100.0 * SUM(CASE
                             WHEN (math_score+reading_score+writing_score)/3.0 >= 60 THEN 1
                             ELSE 0
                         END) / COUNT(*), 2) AS pass_rate_pct
FROM student_performance;

-- KPI 6: Top Performer Rate (composite score >= 90)
-- Business question: What share of students are performing at an elite level?
SELECT ROUND(100.0 * SUM(CASE
                             WHEN (math_score+reading_score+writing_score)/3.0 >= 90 THEN 1
                             ELSE 0
                         END) / COUNT(*), 2) AS top_performer_rate_pct
FROM student_performance;

-- KPI 7: Test Preparation Completion Rate
-- Business question: How many students are taking advantage of the test-preparation course?
SELECT ROUND(100.0 * SUM(CASE
                             WHEN test_prep = 'completed' THEN 1
                             ELSE 0
                         END) / COUNT(*), 2) AS test_prep_completion_rate_pct
FROM student_performance;

-- KPI 8: Free/Reduced Lunch Rate (Socio-Economic Indicator)
-- Business question: What proportion of the student body is economically disadvantaged?
SELECT ROUND(100.0 * SUM(CASE
                             WHEN lunch = 'free/reduced' THEN 1
                             ELSE 0
                         END) / COUNT(*), 2) AS free_reduced_lunch_rate_pct
FROM student_performance;

-- KPI 9: Test-Prep Score Gap (Completed vs None)
-- Business question: How much does completing the test-prep course actually move the needle?
SELECT ROUND(AVG(CASE
                     WHEN test_prep = 'completed' THEN (math_score+reading_score+writing_score)/3.0
                 END), 2) AS avg_score_completed,
       ROUND(AVG(CASE
                     WHEN test_prep = 'none' THEN (math_score+reading_score+writing_score)/3.0
                 END), 2) AS avg_score_none,
       ROUND(AVG(CASE
                     WHEN test_prep = 'completed' THEN (math_score+reading_score+writing_score)/3.0
                 END) - AVG(CASE
                                WHEN test_prep = 'none' THEN (math_score+reading_score+writing_score)/3.0
                            END), 2) AS score_gap
FROM student_performance;

-- KPI 10: Socio-Economic Score Gap (Standard vs Free/Reduced Lunch)
-- Business question: How large is the achievement gap tied to socio-economic status?
SELECT ROUND(AVG(CASE
                     WHEN lunch = 'standard' THEN (math_score+reading_score+writing_score)/3.0
                 END), 2) AS avg_score_standard_lunch,
       ROUND(AVG(CASE
                     WHEN lunch = 'free/reduced' THEN (math_score+reading_score+writing_score)/3.0
                 END), 2) AS avg_score_free_reduced_lunch,
       ROUND(AVG(CASE
                     WHEN lunch = 'standard' THEN (math_score+reading_score+writing_score)/3.0
                 END) - AVG(CASE
                                WHEN lunch = 'free/reduced' THEN (math_score+reading_score+writing_score)/3.0
                            END), 2) AS score_gap
FROM student_performance;


-- #####################################################################
-- PHASE 2: UNIVARIATE ANALYSIS  (10 queries)
-- #####################################################################

-- Univariate 1: Gender Distribution
-- Business question: Is the dataset balanced across male and female students?
SELECT gender,
       COUNT(*) AS student_count,
       ROUND(100.0*COUNT(*)/
               (SELECT COUNT(*)
                FROM student_performance), 2) AS pct
FROM student_performance
GROUP BY gender
ORDER BY student_count DESC;

-- Univariate 2: Race/Ethnicity Group Distribution
-- Business question: How are students distributed across the five recorded ethnicity groups?
SELECT race_ethnicity,
       COUNT(*) AS student_count,
       ROUND(100.0*COUNT(*)/
               (SELECT COUNT(*)
                FROM student_performance), 2) AS pct
FROM student_performance
GROUP BY race_ethnicity
ORDER BY student_count DESC;

-- Univariate 3: Parental Level of Education Distribution
-- Business question: What is the educational background of students' households?
SELECT parental_education,
       COUNT(*) AS student_count,
       ROUND(100.0*COUNT(*)/
               (SELECT COUNT(*)
                FROM student_performance), 2) AS pct
FROM student_performance
GROUP BY parental_education
ORDER BY student_count DESC;

-- Univariate 4: Lunch Type Distribution
-- Business question: What is the baseline socio-economic split of the school?
SELECT lunch,
       COUNT(*) AS student_count,
       ROUND(100.0*COUNT(*)/
               (SELECT COUNT(*)
                FROM student_performance), 2) AS pct
FROM student_performance
GROUP BY lunch
ORDER BY student_count DESC;

-- Univariate 5: Test Preparation Course Distribution
-- Business question: What share of students have engaged with the prep course versus not?
SELECT test_prep,
       COUNT(*) AS student_count,
       ROUND(100.0*COUNT(*)/
               (SELECT COUNT(*)
                FROM student_performance), 2) AS pct
FROM student_performance
GROUP BY test_prep
ORDER BY student_count DESC;

-- Univariate 6: Math Score Statistics
-- Business question: What is the full spread of Math performance, not just the average?
SELECT ROUND(MIN(math_score), 2) AS min_math,
       ROUND(MAX(math_score), 2) AS max_math,
       ROUND(AVG(math_score), 2) AS avg_math
FROM student_performance;

-- Univariate 7: Reading Score Statistics
-- Business question: What is the full spread of Reading performance?
SELECT ROUND(MIN(reading_score), 2) AS min_reading,
       ROUND(MAX(reading_score), 2) AS max_reading,
       ROUND(AVG(reading_score), 2) AS avg_reading
FROM student_performance;

-- Univariate 8: Writing Score Statistics
-- Business question: What is the full spread of Writing performance?
SELECT ROUND(MIN(writing_score), 2) AS min_writing,
       ROUND(MAX(writing_score), 2) AS max_writing,
       ROUND(AVG(writing_score), 2) AS avg_writing
FROM student_performance;

-- Univariate 9: Overall Performance Band Distribution
-- Business question: How many students fall into each broad performance tier?
SELECT CASE
           WHEN (math_score+reading_score+writing_score)/3.0 >= 80 THEN 'Excellent'
           WHEN (math_score+reading_score+writing_score)/3.0 >= 60 THEN 'Good'
           WHEN (math_score+reading_score+writing_score)/3.0 >= 40 THEN 'Average'
           ELSE 'Poor'
       END AS performance_band,
       COUNT(*) AS student_count
FROM student_performance
GROUP BY performance_band
ORDER BY student_count DESC;

-- Univariate 10: Composite Score Quartile Segmentation
-- Business question: Who are the bottom 25% and top 25% of students by composite score?
SELECT composite_quartile,
       COUNT(*) AS student_count
FROM
  (SELECT student_id,
          NTILE(4) OVER (
                         ORDER BY (math_score+reading_score+writing_score)/3.0) AS composite_quartile
   FROM student_performance) q
GROUP BY composite_quartile
ORDER BY composite_quartile;


-- #####################################################################
-- PHASE 3: BIVARIATE ANALYSIS  (10 queries)
-- #####################################################################

-- Bivariate 1: Gender vs Average Scores (by subject)
-- Business question: Do male and female students show different subject strengths?
SELECT gender,
       ROUND(AVG(math_score), 2) AS avg_math,
       ROUND(AVG(reading_score), 2) AS avg_reading,
       ROUND(AVG(writing_score), 2) AS avg_writing
FROM student_performance
GROUP BY gender;

-- Bivariate 2: Race/Ethnicity vs Average Composite Score
-- Business question: Does average performance differ meaningfully across ethnicity groups?
SELECT race_ethnicity,
       ROUND(AVG((math_score+reading_score+writing_score)/3.0), 2) AS avg_composite
FROM student_performance
GROUP BY race_ethnicity
ORDER BY avg_composite DESC;

-- Bivariate 3: Parental Education vs Average Composite Score
-- Business question: Does a student's home educational environment track with academic performance?
SELECT parental_education,
       ROUND(AVG((math_score+reading_score+writing_score)/3.0), 2) AS avg_composite
FROM student_performance
GROUP BY parental_education
ORDER BY avg_composite DESC;

-- Bivariate 4: Lunch Type vs Average Composite Score
-- Business question: Do students from lower-income households score differently on average?
SELECT lunch,
       ROUND(AVG((math_score+reading_score+writing_score)/3.0), 2) AS avg_composite
FROM student_performance
GROUP BY lunch
ORDER BY avg_composite DESC;

-- Bivariate 5: Test Prep vs Average Composite Score
-- Business question: Does completing the prep course actually correlate with higher scores?
SELECT test_prep,
       ROUND(AVG((math_score+reading_score+writing_score)/3.0), 2) AS avg_composite
FROM student_performance
GROUP BY test_prep
ORDER BY avg_composite DESC;

-- Bivariate 6: Test Prep vs Pass Rate
-- Business question: Does the prep course change whether a student passes at all, not just their score?
SELECT test_prep,
       ROUND(100.0*SUM(CASE
                           WHEN (math_score+reading_score+writing_score)/3.0>=60 THEN 1
                           ELSE 0
                       END)/COUNT(*), 2) AS pass_rate_pct
FROM student_performance
GROUP BY test_prep;

-- Bivariate 7: Lunch vs Performance Band Distribution
-- Business question: Are economically disadvantaged students clustered in the lower performance bands?
SELECT lunch,
       CASE
           WHEN (math_score+reading_score+writing_score)/3.0 >= 80 THEN 'Excellent'
           WHEN (math_score+reading_score+writing_score)/3.0 >= 60 THEN 'Good'
           WHEN (math_score+reading_score+writing_score)/3.0 >= 40 THEN 'Average'
           ELSE 'Poor'
       END AS performance_band,
       COUNT(*) AS student_count
FROM student_performance
GROUP BY lunch,
         performance_band
ORDER BY lunch,
         student_count DESC;

-- Bivariate 8: Race/Ethnicity vs Test Prep Completion Rate
-- Business question: Do all ethnicity groups have equal access to (or uptake of) the prep course?
SELECT race_ethnicity,
       ROUND(100.0*SUM(CASE
                           WHEN test_prep='completed' THEN 1
                           ELSE 0
                       END)/COUNT(*), 2) AS test_prep_completion_pct
FROM student_performance
GROUP BY race_ethnicity
ORDER BY test_prep_completion_pct DESC;

-- Bivariate 9: Parental Education vs Test Prep Completion Rate
-- Business question: Do families with different education levels enroll their children in the prep course at different rates?
SELECT parental_education,
       ROUND(100.0*SUM(CASE
                           WHEN test_prep='completed' THEN 1
                           ELSE 0
                       END)/COUNT(*), 2) AS test_prep_completion_pct
FROM student_performance
GROUP BY parental_education
ORDER BY test_prep_completion_pct DESC;

-- Bivariate 10: Gender vs Subject Strength Comparison (Math vs Reading/Writing Gap)
-- Business question: How large is the within-student subject imbalance for each gender?
SELECT gender,
       ROUND(AVG(math_score), 2) AS avg_math,
       ROUND(AVG(reading_score), 2) AS avg_reading,
       ROUND(AVG(writing_score), 2) AS avg_writing,
       ROUND(AVG(reading_score) - AVG(math_score), 2) AS reading_minus_math_gap
FROM student_performance
GROUP BY gender;


-- #####################################################################
-- PHASE 4: MULTIVARIATE ANALYSIS  (10 queries)
-- #####################################################################

-- Multivariate 1: Gender + Test Prep + Avg Score
-- Business question: Does the test-prep benefit apply equally to both genders?
SELECT gender,
       test_prep,
       ROUND(AVG((math_score+reading_score+writing_score)/3.0), 2) AS avg_score
FROM student_performance
GROUP BY gender,
         test_prep
ORDER BY avg_score DESC;

-- Multivariate 2: Lunch + Test Prep + Avg Score
-- Business question: Which combination of SES and prep status produces the widest performance spread?
SELECT lunch,
       test_prep,
       ROUND(AVG((math_score+reading_score+writing_score)/3.0), 2) AS avg_score
FROM student_performance
GROUP BY lunch,
         test_prep
ORDER BY avg_score DESC;

-- Multivariate 3: Race/Ethnicity + Parental Education (top-tier) + Avg Score
SELECT race_ethnicity,
       parental_education,
       ROUND(AVG((math_score+reading_score+writing_score)/3.0), 2) AS avg_score,
       COUNT(*) AS student_count
FROM student_performance
GROUP BY race_ethnicity,
         parental_education
ORDER BY avg_score DESC
LIMIT 15;

-- Multivariate 4: Gender + Lunch + Avg Score
-- Business question: Does the SES gap look the same for boys and girls?
SELECT gender,
       lunch,
       ROUND(AVG((math_score+reading_score+writing_score)/3.0), 2) AS avg_score
FROM student_performance
GROUP BY gender,
         lunch
ORDER BY avg_score DESC;

-- Multivariate 5: Test Prep + Parental Education + Avg Score
-- Business question: Can the prep course help offset a less-advantaged home education background?
SELECT test_prep,
       parental_education,
       ROUND(AVG((math_score+reading_score+writing_score)/3.0), 2) AS avg_score
FROM student_performance
GROUP BY test_prep,
         parental_education
ORDER BY avg_score DESC;

-- Multivariate 6: Race/Ethnicity + Test Prep + Performance Band
-- Business question: How does prep-course completion shift the performance-band mix within each ethnicity group?
SELECT race_ethnicity,
       test_prep,
       CASE
           WHEN (math_score+reading_score+writing_score)/3.0 >= 80 THEN 'Excellent'
           WHEN (math_score+reading_score+writing_score)/3.0 >= 60 THEN 'Good'
           WHEN (math_score+reading_score+writing_score)/3.0 >= 40 THEN 'Average'
           ELSE 'Poor'
       END AS performance_band,
       COUNT(*) AS student_count
FROM student_performance
GROUP BY race_ethnicity,
         test_prep,
         performance_band
ORDER BY race_ethnicity,
         student_count DESC;

-- Multivariate 7: Lunch + Race/Ethnicity + Avg Score
-- Business question: Which lunch/ethnicity combination represents the true highest-need segment?
SELECT lunch,
       race_ethnicity,
       ROUND(AVG((math_score+reading_score+writing_score)/3.0), 2) AS avg_score
FROM student_performance
GROUP BY lunch,
         race_ethnicity
ORDER BY avg_score DESC
LIMIT 15;

-- Multivariate 8: Gender + Race/Ethnicity + Test Prep + Avg Score
-- Business question: What does the single best-performing student profile look like?
SELECT gender,
       race_ethnicity,
       test_prep,
       ROUND(AVG((math_score+reading_score+writing_score)/3.0), 2) AS avg_score
FROM student_performance
GROUP BY gender,
         race_ethnicity,
         test_prep
ORDER BY avg_score DESC
LIMIT 15;

-- Multivariate 9: Comprehensive Equity Model: Parental Education + Lunch + Test Prep
-- Business question: What happens when three advantage factors stack together (or don't)?
SELECT parental_education,
       lunch,
       test_prep,
       ROUND(AVG((math_score+reading_score+writing_score)/3.0), 2) AS avg_score,
       COUNT(*) AS student_count
FROM student_performance
GROUP BY parental_education,
         lunch,
         test_prep
ORDER BY avg_score DESC
LIMIT 15;

-- Multivariate 10: Full Segmentation Model: Gender + Lunch + Test Prep + Performance Band -> Ranked
-- Business question: Across the entire cross-tabulation, where exactly do the best and worst outcomes concentrate?
SELECT gender,
       lunch,
       test_prep,
       CASE
           WHEN (math_score+reading_score+writing_score)/3.0 >= 80 THEN 'Excellent'
           WHEN (math_score+reading_score+writing_score)/3.0 >= 60 THEN 'Good'
           WHEN (math_score+reading_score+writing_score)/3.0 >= 40 THEN 'Average'
           ELSE 'Poor'
       END AS performance_band,
       ROUND(AVG((math_score+reading_score+writing_score)/3.0), 2) AS avg_score,
       COUNT(*) AS student_count
FROM student_performance
GROUP BY gender,
         lunch,
         test_prep,
         performance_band
ORDER BY avg_score DESC;

-- =====================================================================
--  END OF FILE — 40 queries total
-- =====================================================================
