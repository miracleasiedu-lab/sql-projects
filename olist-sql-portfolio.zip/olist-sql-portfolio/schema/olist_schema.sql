-- Olist relational schema (MySQL 8.0) — generated with mysqldump --no-data --routines
-- Tables, enforced PK/FK/UNIQUE/CHECK constraints, views and fn_std_city().
-- Build order and data loading: see sql/01..05 and run_all.sh.


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category_translation` (
  `product_category_name` varchar(80) NOT NULL,
  `product_category_name_english` varchar(80) NOT NULL,
  `is_supplemented` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`product_category_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `customer_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `customer_unique_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `customer_zip_code_prefix` char(5) NOT NULL,
  `customer_city` varchar(100) NOT NULL,
  `customer_state` char(2) NOT NULL,
  PRIMARY KEY (`customer_id`),
  KEY `ix_customers_unique` (`customer_unique_id`),
  KEY `ix_customers_state` (`customer_state`),
  KEY `fk_customers_zip` (`customer_zip_code_prefix`),
  CONSTRAINT `fk_customers_zip` FOREIGN KEY (`customer_zip_code_prefix`) REFERENCES `zip_code` (`zip_code_prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fact_order` (
  `order_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `customer_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `customer_unique_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `customer_city` varchar(100) NOT NULL,
  `customer_state` char(2) NOT NULL,
  `order_status` enum('created','approved','invoiced','processing','shipped','delivered','canceled','unavailable') NOT NULL,
  `order_purchase_timestamp` datetime NOT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_month` varchar(7) DEFAULT NULL,
  `order_approved_at` datetime DEFAULT NULL,
  `order_delivered_carrier_date` datetime DEFAULT NULL,
  `order_delivered_customer_date` datetime DEFAULT NULL,
  `order_estimated_delivery_date` datetime NOT NULL,
  `items` bigint NOT NULL DEFAULT '0',
  `distinct_products` bigint DEFAULT NULL,
  `distinct_sellers` bigint DEFAULT NULL,
  `item_revenue` decimal(32,2) NOT NULL DEFAULT '0.00',
  `freight` decimal(32,2) NOT NULL DEFAULT '0.00',
  `payment_value` decimal(32,2) DEFAULT NULL,
  `payment_rows` bigint DEFAULT NULL,
  `max_installments` tinyint unsigned,
  `main_payment_type` text,
  `review_score` tinyint unsigned,
  `delivery_days` decimal(23,2) DEFAULT NULL,
  `delay_days` int DEFAULT NULL,
  `is_late` int DEFAULT NULL,
  `valid_delivery_chain` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`),
  KEY `ix_fo_unique` (`customer_unique_id`),
  KEY `ix_fo_month` (`purchase_month`),
  KEY `ix_fo_status` (`order_status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `order_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `order_item_id` tinyint unsigned NOT NULL,
  `product_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `seller_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `shipping_limit_date` datetime NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `freight_value` decimal(10,2) NOT NULL,
  PRIMARY KEY (`order_id`,`order_item_id`),
  KEY `ix_items_product` (`product_id`),
  KEY `ix_items_seller` (`seller_id`),
  CONSTRAINT `fk_items_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  CONSTRAINT `fk_items_product` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`),
  CONSTRAINT `fk_items_seller` FOREIGN KEY (`seller_id`) REFERENCES `sellers` (`seller_id`),
  CONSTRAINT `ck_items_freight` CHECK ((`freight_value` >= 0)),
  CONSTRAINT `ck_items_price` CHECK ((`price` > 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_payments` (
  `order_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `payment_sequential` tinyint unsigned NOT NULL,
  `payment_type` enum('credit_card','boleto','voucher','debit_card','not_defined') NOT NULL,
  `payment_installments` tinyint unsigned NOT NULL,
  `payment_value` decimal(10,2) NOT NULL,
  `installments_recoded` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`,`payment_sequential`),
  CONSTRAINT `fk_payments_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  CONSTRAINT `ck_payments_value` CHECK ((`payment_value` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_reviews` (
  `review_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `order_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `review_score` tinyint unsigned NOT NULL,
  `review_comment_title` varchar(255) DEFAULT NULL,
  `review_comment_message` text,
  `review_creation_date` datetime NOT NULL,
  `review_answer_timestamp` datetime NOT NULL,
  PRIMARY KEY (`review_id`,`order_id`),
  KEY `ix_reviews_order` (`order_id`),
  CONSTRAINT `fk_reviews_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  CONSTRAINT `ck_reviews_score` CHECK ((`review_score` between 1 and 5))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `order_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `customer_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `order_status` enum('created','approved','invoiced','processing','shipped','delivered','canceled','unavailable') NOT NULL,
  `order_purchase_timestamp` datetime NOT NULL,
  `order_approved_at` datetime DEFAULT NULL,
  `order_delivered_carrier_date` datetime DEFAULT NULL,
  `order_delivered_customer_date` datetime DEFAULT NULL,
  `order_estimated_delivery_date` datetime NOT NULL,
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `uq_orders_customer` (`customer_id`),
  KEY `ix_orders_purchase` (`order_purchase_timestamp`),
  KEY `ix_orders_status` (`order_status`),
  CONSTRAINT `fk_orders_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `product_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `product_category_name` varchar(80) DEFAULT NULL,
  `product_name_lenght` smallint unsigned DEFAULT NULL,
  `product_description_lenght` smallint unsigned DEFAULT NULL,
  `product_photos_qty` tinyint unsigned DEFAULT NULL,
  `product_weight_g` int unsigned DEFAULT NULL,
  `product_length_cm` smallint unsigned DEFAULT NULL,
  `product_height_cm` smallint unsigned DEFAULT NULL,
  `product_width_cm` smallint unsigned DEFAULT NULL,
  `weight_was_zero` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`product_id`),
  KEY `ix_products_category` (`product_category_name`),
  CONSTRAINT `fk_products_category` FOREIGN KEY (`product_category_name`) REFERENCES `category_translation` (`product_category_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sellers` (
  `seller_id` char(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `seller_zip_code_prefix` char(5) NOT NULL,
  `seller_city` varchar(100) DEFAULT NULL,
  `seller_state` char(2) NOT NULL,
  PRIMARY KEY (`seller_id`),
  KEY `ix_sellers_state` (`seller_state`),
  KEY `fk_sellers_zip` (`seller_zip_code_prefix`),
  CONSTRAINT `fk_sellers_zip` FOREIGN KEY (`seller_zip_code_prefix`) REFERENCES `zip_code` (`zip_code_prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_item_detail` AS SELECT 
 1 AS `order_id`,
 1 AS `order_item_id`,
 1 AS `product_id`,
 1 AS `seller_id`,
 1 AS `price`,
 1 AS `freight_value`,
 1 AS `shipping_limit_date`,
 1 AS `order_status`,
 1 AS `order_purchase_timestamp`,
 1 AS `purchase_month`,
 1 AS `order_delivered_carrier_date`,
 1 AS `order_delivered_customer_date`,
 1 AS `order_estimated_delivery_date`,
 1 AS `customer_unique_id`,
 1 AS `customer_state`,
 1 AS `category`,
 1 AS `product_weight_g`,
 1 AS `product_photos_qty`,
 1 AS `product_volume_cm3`,
 1 AS `seller_city`,
 1 AS `seller_state`*/;
SET character_set_client = @saved_cs_client;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_order_summary` AS SELECT 
 1 AS `order_id`,
 1 AS `customer_id`,
 1 AS `customer_unique_id`,
 1 AS `customer_city`,
 1 AS `customer_state`,
 1 AS `order_status`,
 1 AS `order_purchase_timestamp`,
 1 AS `purchase_date`,
 1 AS `purchase_month`,
 1 AS `order_approved_at`,
 1 AS `order_delivered_carrier_date`,
 1 AS `order_delivered_customer_date`,
 1 AS `order_estimated_delivery_date`,
 1 AS `items`,
 1 AS `distinct_products`,
 1 AS `distinct_sellers`,
 1 AS `item_revenue`,
 1 AS `freight`,
 1 AS `payment_value`,
 1 AS `payment_rows`,
 1 AS `max_installments`,
 1 AS `main_payment_type`,
 1 AS `review_score`,
 1 AS `delivery_days`,
 1 AS `delay_days`,
 1 AS `is_late`,
 1 AS `valid_delivery_chain`*/;
SET character_set_client = @saved_cs_client;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `v_product` AS SELECT 
 1 AS `product_id`,
 1 AS `product_category_name`,
 1 AS `product_name_lenght`,
 1 AS `product_description_lenght`,
 1 AS `product_photos_qty`,
 1 AS `product_weight_g`,
 1 AS `product_length_cm`,
 1 AS `product_height_cm`,
 1 AS `product_width_cm`,
 1 AS `weight_was_zero`,
 1 AS `category`*/;
SET character_set_client = @saved_cs_client;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `zip_code` (
  `zip_code_prefix` char(5) NOT NULL,
  `latitude` decimal(10,7) DEFAULT NULL,
  `longitude` decimal(10,7) DEFAULT NULL,
  `geo_city` varchar(100) DEFAULT NULL,
  `geo_state` char(2) DEFAULT NULL,
  `geo_points` int NOT NULL DEFAULT '0',
  `has_geolocation` tinyint(1) NOT NULL,
  PRIMARY KEY (`zip_code_prefix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `fn_std_city`(s VARCHAR(200)) RETURNS varchar(200) CHARSET utf8mb4
    NO SQL
    DETERMINISTIC
BEGIN
  DECLARE r VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;
  IF s IS NULL OR TRIM(s) = '' THEN RETURN NULL; END IF;
  SET r = LOWER(TRIM(s));
  SET r = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(r,'á','a'),'à','a'),'â','a'),'ã','a'),'ä','a');
  SET r = REPLACE(REPLACE(REPLACE(REPLACE(r,'é','e'),'ê','e'),'è','e'),'ë','e');
  SET r = REPLACE(REPLACE(REPLACE(REPLACE(r,'í','i'),'î','i'),'ì','i'),'ï','i');
  SET r = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(r,'ó','o'),'ô','o'),'õ','o'),'ò','o'),'ö','o');
  SET r = REPLACE(REPLACE(REPLACE(REPLACE(r,'ú','u'),'û','u'),'ù','u'),'ü','u');
  SET r = REPLACE(REPLACE(r,'ç','c'),'ñ','n');
  SET r = REPLACE(REPLACE(REPLACE(r,'´',''''),'`',''''),'£','');
  WHILE INSTR(r,'  ') > 0 DO SET r = REPLACE(r,'  ',' '); END WHILE;
  RETURN TRIM(r);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50001 DROP VIEW IF EXISTS `v_item_detail`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_item_detail` AS select `i`.`order_id` AS `order_id`,`i`.`order_item_id` AS `order_item_id`,`i`.`product_id` AS `product_id`,`i`.`seller_id` AS `seller_id`,`i`.`price` AS `price`,`i`.`freight_value` AS `freight_value`,`i`.`shipping_limit_date` AS `shipping_limit_date`,`o`.`order_status` AS `order_status`,`o`.`order_purchase_timestamp` AS `order_purchase_timestamp`,date_format(`o`.`order_purchase_timestamp`,'%Y-%m') AS `purchase_month`,`o`.`order_delivered_carrier_date` AS `order_delivered_carrier_date`,`o`.`order_delivered_customer_date` AS `order_delivered_customer_date`,`o`.`order_estimated_delivery_date` AS `order_estimated_delivery_date`,`c`.`customer_unique_id` AS `customer_unique_id`,`c`.`customer_state` AS `customer_state`,`p`.`category` AS `category`,`p`.`product_weight_g` AS `product_weight_g`,`p`.`product_photos_qty` AS `product_photos_qty`,((`p`.`product_length_cm` * `p`.`product_height_cm`) * `p`.`product_width_cm`) AS `product_volume_cm3`,`s`.`seller_city` AS `seller_city`,`s`.`seller_state` AS `seller_state` from ((((`order_items` `i` join `orders` `o` on((`o`.`order_id` = `i`.`order_id`))) join `customers` `c` on((`c`.`customer_id` = `o`.`customer_id`))) join `v_product` `p` on((`p`.`product_id` = `i`.`product_id`))) join `sellers` `s` on((`s`.`seller_id` = `i`.`seller_id`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `v_order_summary`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_order_summary` AS with `item_agg` as (select `order_items`.`order_id` AS `order_id`,count(0) AS `items`,count(distinct `order_items`.`product_id`) AS `distinct_products`,count(distinct `order_items`.`seller_id`) AS `distinct_sellers`,sum(`order_items`.`price`) AS `item_revenue`,sum(`order_items`.`freight_value`) AS `freight` from `order_items` group by `order_items`.`order_id`), `pay_agg` as (select `order_payments`.`order_id` AS `order_id`,sum(`order_payments`.`payment_value`) AS `payment_value`,count(0) AS `payment_rows`,max(`order_payments`.`payment_installments`) AS `max_installments`,substring_index(group_concat(`order_payments`.`payment_type` order by `order_payments`.`payment_value` DESC,`order_payments`.`payment_sequential` ASC separator ','),',',1) AS `main_payment_type` from `order_payments` group by `order_payments`.`order_id`), `review_ranked` as (select `order_reviews`.`order_id` AS `order_id`,`order_reviews`.`review_score` AS `review_score`,row_number() OVER (PARTITION BY `order_reviews`.`order_id` ORDER BY `order_reviews`.`review_answer_timestamp` desc,`order_reviews`.`review_creation_date` desc,`order_reviews`.`review_id` )  AS `rn` from `order_reviews`) select `o`.`order_id` AS `order_id`,`o`.`customer_id` AS `customer_id`,`c`.`customer_unique_id` AS `customer_unique_id`,`c`.`customer_city` AS `customer_city`,`c`.`customer_state` AS `customer_state`,`o`.`order_status` AS `order_status`,`o`.`order_purchase_timestamp` AS `order_purchase_timestamp`,cast(`o`.`order_purchase_timestamp` as date) AS `purchase_date`,date_format(`o`.`order_purchase_timestamp`,'%Y-%m') AS `purchase_month`,`o`.`order_approved_at` AS `order_approved_at`,`o`.`order_delivered_carrier_date` AS `order_delivered_carrier_date`,`o`.`order_delivered_customer_date` AS `order_delivered_customer_date`,`o`.`order_estimated_delivery_date` AS `order_estimated_delivery_date`,coalesce(`ia`.`items`,0) AS `items`,`ia`.`distinct_products` AS `distinct_products`,`ia`.`distinct_sellers` AS `distinct_sellers`,coalesce(`ia`.`item_revenue`,0) AS `item_revenue`,coalesce(`ia`.`freight`,0) AS `freight`,`pa`.`payment_value` AS `payment_value`,`pa`.`payment_rows` AS `payment_rows`,`pa`.`max_installments` AS `max_installments`,`pa`.`main_payment_type` AS `main_payment_type`,`rr`.`review_score` AS `review_score`,round((timestampdiff(MINUTE,`o`.`order_purchase_timestamp`,`o`.`order_delivered_customer_date`) / 1440),2) AS `delivery_days`,(to_days(`o`.`order_delivered_customer_date`) - to_days(`o`.`order_estimated_delivery_date`)) AS `delay_days`,(case when (`o`.`order_delivered_customer_date` is null) then NULL when (cast(`o`.`order_delivered_customer_date` as date) > cast(`o`.`order_estimated_delivery_date` as date)) then 1 else 0 end) AS `is_late`,(case when ((`o`.`order_status` = 'delivered') and (`o`.`order_approved_at` is not null) and (`o`.`order_delivered_carrier_date` is not null) and (`o`.`order_delivered_customer_date` is not null) and (`o`.`order_approved_at` >= `o`.`order_purchase_timestamp`) and (`o`.`order_delivered_carrier_date` >= `o`.`order_approved_at`) and (`o`.`order_delivered_customer_date` >= `o`.`order_delivered_carrier_date`)) then 1 else 0 end) AS `valid_delivery_chain` from ((((`orders` `o` join `customers` `c` on((`c`.`customer_id` = `o`.`customer_id`))) left join `item_agg` `ia` on((`ia`.`order_id` = `o`.`order_id`))) left join `pay_agg` `pa` on((`pa`.`order_id` = `o`.`order_id`))) left join `review_ranked` `rr` on(((`rr`.`order_id` = `o`.`order_id`) and (`rr`.`rn` = 1)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `v_product`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `v_product` AS select `p`.`product_id` AS `product_id`,`p`.`product_category_name` AS `product_category_name`,`p`.`product_name_lenght` AS `product_name_lenght`,`p`.`product_description_lenght` AS `product_description_lenght`,`p`.`product_photos_qty` AS `product_photos_qty`,`p`.`product_weight_g` AS `product_weight_g`,`p`.`product_length_cm` AS `product_length_cm`,`p`.`product_height_cm` AS `product_height_cm`,`p`.`product_width_cm` AS `product_width_cm`,`p`.`weight_was_zero` AS `weight_was_zero`,coalesce(`t`.`product_category_name_english`,'uncategorized') AS `category` from (`products` `p` left join `category_translation` `t` on((`p`.`product_category_name` = `t`.`product_category_name`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

