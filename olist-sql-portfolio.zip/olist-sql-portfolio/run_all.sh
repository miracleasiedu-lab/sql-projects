#!/usr/bin/env bash
# Rebuild the whole project end-to-end.
# Prereqs: MySQL 8.0 (local_infile=1), Python 3 with pymysql,
#          the 9 Olist CSVs in ./data/, run from the project root.
set -euo pipefail
python3 run_sql.py sql/01_staging_load.sql
for f in sql/02_data_quality.sql sql/03_clean_model.sql sql/04_relationship_validation.sql \
         sql/05_views.sql sql/06_kpis.sql sql/07_univariate.sql sql/08_bivariate.sql \
         sql/09_multivariate.sql sql/10_deep_dives.sql; do
  python3 run_sql.py "$f"
done
python3 build_report.py
