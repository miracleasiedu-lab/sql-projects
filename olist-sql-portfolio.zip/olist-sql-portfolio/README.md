# Olist E-Commerce Sales & Customer Performance Analysis

**Domain:** E-commerce / Retail Analytics · **Audience:** Sales Director / E-commerce Manager · **Database:** MySQL 8.0 · **Type:** Multi-table SQL data modelling and advanced business analytics

Every number in this document was produced by executing the SQL in `/sql` against MySQL 8.0.46 loaded with the nine original Olist CSV files. Result tables are inserted programmatically from the query output (`build_report.py`), not typed by hand.

---

## Contents

1. [Executive summary](#1-executive-summary)
2. [Dataset overview](#2-dataset-overview)
3. [Data dictionary](#3-data-dictionary)
4. [Key assessment](#4-key-assessment)
5. [Data quality assessment](#5-data-quality-assessment)
6. [SQL cleaning](#6-sql-cleaning)
7. [ER diagram and relational model](#7-er-diagram-and-relational-model)
8. [Relationship validation and join inflation](#8-relationship-validation-and-join-inflation)
9. [Analytical layer (views)](#9-analytical-layer-views)
10. [10 KPIs](#10-ten-kpis)
11. [10 univariate analyses](#11-ten-univariate-analyses)
12. [10 bivariate analyses](#12-ten-bivariate-analyses)
13. [10 multivariate analyses](#13-ten-multivariate-analyses)
14. [Customer analysis](#14-customer-analysis)
15. [Product analysis](#15-product-analysis)
16. [Seller performance](#16-seller-performance)
17. [Delivery and customer satisfaction](#17-delivery-and-customer-satisfaction)
18. [Time-series analysis](#18-time-series-analysis)
19. [Advanced SQL coverage](#19-advanced-sql-coverage)
20. [Key insights](#20-key-insights)
21. [Business recommendations](#21-business-recommendations)
22. [Limitations](#22-limitations)
23. [Conclusion](#23-conclusion)

---

## 1. Executive summary

Olist delivered **96,478 orders worth R$13.22M in product revenue** (R$15.42M including freight) to **93,358 unique customers** between September 2016 and August 2018. Growth was very strong through 2017 but **plateaued in 2018**: monthly revenue has hovered between roughly R$0.83M and R$0.98M since January 2018, and year-on-year growth fell from +727% in January to +51% in August.

Three findings matter most for management:

- **Delivery reliability is the single strongest correlate of customer satisfaction.** Orders delivered on time average 4.29 stars; late orders average 2.27, and 62.4% of late orders receive a 1–2 star review. The satisfaction dips in Nov 2017 and Feb–Mar 2018 coincide exactly with late-delivery spikes (up to 19% late).
- **Geography drives cost and experience.** 64% of revenue is shipped by São Paulo sellers. Customers in the Northeast wait 20 days on average (vs 8.8 in SP), pay 21.7% of the product value in freight (vs 13.9%), and rate Olist lower.
- **Olist is almost entirely a first-purchase business.** Only 3.0% of customers ordered more than once, and repeat customers generate just 5.5% of revenue. Retention is the largest untapped growth lever.

Revenue is concentrated: 18 of 74 categories produce 80% of revenue, the top 10% of sellers produce 67%, and the top 10% of customers produce 41%.

---

## 2. Dataset overview

Nine CSV files were supplied. Row counts below are records as loaded by MySQL (`01_staging_load.sql`) and reconciled against an independent pandas parse.

| File | Records | Columns | Grain |
|---|---|---|---|
| `olist_orders_dataset.csv` | 99,441 | 8 | one row per order |
| `olist_customers_dataset.csv` | 99,441 | 5 | one row per order-level customer key |
| `olist_order_items_dataset.csv` | 112,650 | 7 | one row per item line in an order |
| `olist_order_payments_dataset.csv` | 103,886 | 5 | one row per payment record of an order |
| `olist_order_reviews_dataset.csv` | **99,224** | 7 | one row per (review, order) pair |
| `olist_products_dataset.csv` | 32,951 | 9 | one row per product |
| `olist_sellers_dataset.csv` | 3,095 | 4 | one row per seller |
| `olist_geolocation_dataset.csv` | 1,000,163 | 5 | one row per raw geocoded point (not unique per ZIP) |
| `product_category_name_translation.csv` | 71 | 2 | one row per Portuguese category |

Load reconciliation (`01_staging_load.sql`):

| tbl | rows_loaded |
|---|---|
| stg_orders | 99,441 |
| stg_customers | 99,441 |
| stg_order_items | 112,650 |
| stg_order_payments | 103,886 |
| stg_order_reviews | 99,224 |
| stg_products | 32,951 |
| stg_sellers | 3,095 |
| stg_geolocation | 1,000,163 |
| stg_category_translation | 71 |

**Correction to the brief — reviews row count.** The reviews file has 104,720 physical lines but only **99,224 records**: free-text comments contain line breaks inside quoted fields. "104,719 rows" is a line count, not a record count.

**Load issue found and fixed.** One review comment ends with a literal backslash (`…não chegou nada :\"`). With MySQL's default `ESCAPED BY '\\'`, the sequence `\"` is read as an escaped quote and two reviews merge into one (99,223 loaded). Every load therefore uses `ESCAPED BY ''`, because the files do not use backslash escaping.

**Column-name note.** The products file genuinely uses the misspelled names `product_name_lenght` and `product_description_lenght`; the project keeps them verbatim so every query matches the source.

**Time coverage.** Purchases run from 2016-09-04 to 2018-10-17, but volumes are sparse at both ends (4 orders in Sep 2016, none in Nov 2016, 1 in Dec 2016, 16 in Sep 2018 and 4 in Oct 2018). Trend analyses therefore use the **20 complete trading months Jan 2017 – Aug 2018**.

| purchase_month | orders |
|---|---|
| 2016-09 | 4 |
| 2016-10 | 324 |
| 2016-12 | 1 |
| 2017-01 | 800 |
| 2017-02 | 1,780 |
| 2017-03 | 2,682 |
| 2017-04 | 2,404 |
| 2017-05 | 3,700 |
| 2017-06 | 3,245 |
| 2017-07 | 4,026 |
| 2017-08 | 4,331 |
| 2017-09 | 4,285 |
| 2017-10 | 4,631 |
| 2017-11 | 7,544 |
| 2017-12 | 5,673 |
| 2018-01 | 7,269 |
| 2018-02 | 6,728 |
| 2018-03 | 7,211 |
| 2018-04 | 6,939 |
| 2018-05 | 6,873 |
| 2018-06 | 6,167 |
| 2018-07 | 6,292 |
| 2018-08 | 6,512 |
| 2018-09 | 16 |
| 2018-10 | 4 |

### Project files

| File | Purpose |
|---|---|
| `sql/01_staging_load.sql` | Raw staging tables (all text) and `LOAD DATA` |
| `sql/02_data_quality.sql` | 23 profiling checks on the raw layer |
| `sql/03_clean_model.sql` | Cleaning rules and the constrained relational schema |
| `sql/04_relationship_validation.sql` | Relationship checks and join-inflation proof |
| `sql/05_views.sql` | Analytical views and `fact_order` |
| `sql/06_kpis.sql` | 10 KPIs |
| `sql/07_univariate.sql` / `08_bivariate.sql` / `09_multivariate.sql` | 10 + 10 + 10 analyses |
| `sql/10_deep_dives.sql` | Customer, product, seller, delivery, time-series deep dives |
| `schema/olist_schema.sql` | `mysqldump --no-data` of the final schema |
| `results/*.md` | Raw query outputs |
| `run_all.sh` | Rebuilds everything end-to-end |

---

## 3. Data dictionary

Generated from `information_schema` of the cleaned `olist` database.

#### `orders` — 99,441 rows

| Column | MySQL type | Null | Key | Description |
|---|---|---|---|---|
| `order_id` | char(32) | NO | PRI | Order identifier (one row per order) |
| `customer_id` | char(32) | NO | UNI | Order-level customer key; UNIQUE, so customers→orders is 1:1 |
| `order_status` | enum(…) | NO | MUL | Lifecycle status (8 observed values) |
| `order_purchase_timestamp` | datetime | NO | MUL | Purchase time; basis of all time-series analysis |
| `order_approved_at` | datetime | YES |  | Payment approval time (NULL for 160 orders) |
| `order_delivered_carrier_date` | datetime | YES |  | Hand-over to carrier (NULL for 1,783 orders) |
| `order_delivered_customer_date` | datetime | YES |  | Delivery to customer (NULL for 2,965 orders) |
| `order_estimated_delivery_date` | datetime | NO |  | Delivery date promised at purchase |

#### `customers` — 99,441 rows

| Column | MySQL type | Null | Key | Description |
|---|---|---|---|---|
| `customer_id` | char(32) | NO | PRI | PK; one per order (not a persistent person ID) |
| `customer_unique_id` | char(32) | NO | MUL | Persistent person ID; repeats across orders — use for customer counts |
| `customer_zip_code_prefix` | char(5) | NO | MUL | First 5 digits of ZIP; FK → zip_code |
| `customer_city` | varchar(100) | NO |  | Standardised city name (lower case, no diacritics) |
| `customer_state` | char(2) | NO | MUL | Brazilian state code (UF) |

#### `order_items` — 112,650 rows

| Column | MySQL type | Null | Key | Description |
|---|---|---|---|---|
| `order_id` | char(32) | NO | PRI | FK → orders; part of composite PK |
| `order_item_id` | tinyint unsigned | NO | PRI | Line sequence 1..n inside the order; part of composite PK |
| `product_id` | char(32) | NO | MUL | FK → products |
| `seller_id` | char(32) | NO | MUL | FK → sellers |
| `shipping_limit_date` | datetime | NO |  | Deadline for seller to hand item to carrier |
| `price` | decimal(10,2) | NO |  | Item price, BRL (CHECK > 0) — revenue base |
| `freight_value` | decimal(10,2) | NO |  | Freight charged for the item, BRL (CHECK ≥ 0) |

#### `order_payments` — 103,886 rows

| Column | MySQL type | Null | Key | Description |
|---|---|---|---|---|
| `order_id` | char(32) | NO | PRI | FK → orders; part of composite PK |
| `payment_sequential` | tinyint unsigned | NO | PRI | Payment sequence within order; part of composite PK |
| `payment_type` | enum(…) | NO |  | credit_card / boleto / voucher / debit_card / not_defined |
| `payment_installments` | tinyint unsigned | NO |  | Number of instalments (0 recoded to 1 for 2 rows) |
| `payment_value` | decimal(10,2) | NO |  | Amount paid in this payment record, BRL |
| `installments_recoded` | tinyint(1) | NO |  | Cleaning flag: 1 if instalments was 0 in source |

#### `order_reviews` — 99,224 rows

| Column | MySQL type | Null | Key | Description |
|---|---|---|---|---|
| `review_id` | char(32) | NO | PRI | Review identifier — NOT unique alone; part of composite PK |
| `order_id` | char(32) | NO | PRI | FK → orders; part of composite PK |
| `review_score` | tinyint unsigned | NO |  | 1–5 stars (CHECK 1..5) |
| `review_comment_title` | varchar(255) | YES |  | Optional title (NULL in 88% of reviews) |
| `review_comment_message` | text | YES |  | Optional free text (NULL in 59%) |
| `review_creation_date` | datetime | NO |  | Date the survey was sent |
| `review_answer_timestamp` | datetime | NO |  | Time the customer answered; used to pick latest review |

#### `products` — 32,951 rows

| Column | MySQL type | Null | Key | Description |
|---|---|---|---|---|
| `product_id` | char(32) | NO | PRI | Product identifier |
| `product_category_name` | varchar(80) | YES | MUL | Portuguese category; FK → category_translation (NULL for 610) |
| `product_name_lenght` | smallint unsigned | YES |  | Characters in product name (source spelling kept) |
| `product_description_lenght` | smallint unsigned | YES |  | Characters in description (source spelling kept) |
| `product_photos_qty` | tinyint unsigned | YES |  | Number of listing photos |
| `product_weight_g` | int unsigned | YES |  | Weight in grams (0 g → NULL for 4 products) |
| `product_length_cm` | smallint unsigned | YES |  | Package length, cm |
| `product_height_cm` | smallint unsigned | YES |  | Package height, cm |
| `product_width_cm` | smallint unsigned | YES |  | Package width, cm |
| `weight_was_zero` | tinyint(1) | NO |  | Cleaning flag: 1 if source weight was 0 g |

#### `sellers` — 3,095 rows

| Column | MySQL type | Null | Key | Description |
|---|---|---|---|---|
| `seller_id` | char(32) | NO | PRI | Seller identifier |
| `seller_zip_code_prefix` | char(5) | NO | MUL | FK → zip_code |
| `seller_city` | varchar(100) | YES |  | Cleaned city (free text repaired; 2 invalid values → NULL) |
| `seller_state` | char(2) | NO | MUL | Brazilian state code (UF) |

#### `category_translation` — 73 rows

| Column | MySQL type | Null | Key | Description |
|---|---|---|---|---|
| `product_category_name` | varchar(80) | NO | PRI | Portuguese category name |
| `product_category_name_english` | varchar(80) | NO |  | English category name |
| `is_supplemented` | tinyint(1) | NO |  | 1 for the 2 rows added because the source file lacked them |

#### `zip_code` — 19,177 rows

| Column | MySQL type | Null | Key | Description |
|---|---|---|---|---|
| `zip_code_prefix` | char(5) | NO | PRI | 5-digit ZIP prefix (unique after aggregation) |
| `latitude` | decimal(10,7) | YES |  | Centroid of de-duplicated, in-Brazil points |
| `longitude` | decimal(10,7) | YES |  | Centroid of de-duplicated, in-Brazil points |
| `geo_city` | varchar(100) | YES |  | Most frequent standardised city for the prefix |
| `geo_state` | char(2) | YES |  | Most frequent state for the prefix |
| `geo_points` | int | NO |  | Distinct valid raw points behind the centroid |
| `has_geolocation` | tinyint(1) | NO |  | 0 = prefix used by customers/sellers but absent from source geolocation |


---

## 4. Key assessment

### Candidate-key tests

A column (or column set) is a valid key only if `COUNT(DISTINCT key) = COUNT(*)`.

```sql
SELECT 'orders.order_id' AS candidate_key, COUNT(*) AS total_rows, COUNT(DISTINCT order_id) AS distinct_values FROM stg_orders
UNION ALL SELECT 'orders.customer_id', COUNT(*), COUNT(DISTINCT customer_id) FROM stg_orders
UNION ALL SELECT 'customers.customer_id', COUNT(*), COUNT(DISTINCT customer_id) FROM stg_customers
UNION ALL SELECT 'customers.customer_unique_id', COUNT(*), COUNT(DISTINCT customer_unique_id) FROM stg_customers
UNION ALL SELECT 'order_items.order_id', COUNT(*), COUNT(DISTINCT order_id) FROM stg_order_items
UNION ALL SELECT 'order_items.(order_id, order_item_id)', COUNT(*), COUNT(DISTINCT order_id, order_item_id) FROM stg_order_items
UNION ALL SELECT 'order_payments.order_id', COUNT(*), COUNT(DISTINCT order_id) FROM stg_order_payments
UNION ALL SELECT 'order_payments.(order_id, payment_sequential)', COUNT(*), COUNT(DISTINCT order_id, payment_sequential) FROM stg_order_payments
UNION ALL SELECT 'order_reviews.review_id', COUNT(*), COUNT(DISTINCT review_id) FROM stg_order_reviews
UNION ALL SELECT 'order_reviews.order_id', COUNT(*), COUNT(DISTINCT order_id) FROM stg_order_reviews
UNION ALL SELECT 'order_reviews.(review_id, order_id)', COUNT(*), COUNT(DISTINCT review_id, order_id) FROM stg_order_reviews
UNION ALL SELECT 'products.product_id', COUNT(*), COUNT(DISTINCT product_id) FROM stg_products
UNION ALL SELECT 'sellers.seller_id', COUNT(*), COUNT(DISTINCT seller_id) FROM stg_sellers
UNION ALL SELECT 'geolocation.zip_code_prefix', COUNT(*), COUNT(DISTINCT geolocation_zip_code_prefix) FROM stg_geolocation
UNION ALL SELECT 'category_translation.product_category_name', COUNT(*), COUNT(DISTINCT product_category_name) FROM stg_category_translation;
```

| candidate_key | total_rows | distinct_values |
|---|---|---|
| orders.order_id | 99,441 | 99,441 |
| orders.customer_id | 99,441 | 99,441 |
| customers.customer_id | 99,441 | 99,441 |
| customers.customer_unique_id | 99,441 | 96,096 |
| order_items.order_id | 112,650 | 98,666 |
| order_items.(order_id, order_item_id) | 112,650 | 112,650 |
| order_payments.order_id | 103,886 | 99,440 |
| order_payments.(order_id, payment_sequential) | 103,886 | 103,886 |
| order_reviews.review_id | 99,224 | 98,410 |
| order_reviews.order_id | 99,224 | 98,673 |
| order_reviews.(review_id, order_id) | 99,224 | 99,224 |
| products.product_id | 32,951 | 32,951 |
| sellers.seller_id | 3,095 | 3,095 |
| geolocation.zip_code_prefix | 1,000,163 | 19,015 |
| category_translation.product_category_name | 71 | 71 |

### Conclusions

| Table | Grain | Primary key | Why |
|---|---|---|---|
| orders | order | `order_id` | unique |
| customers | order-level customer | `customer_id` | unique; `customer_unique_id` repeats (96,096 distinct) |
| order_items | item line | (`order_id`, `order_item_id`) | `order_item_id` is a 1..n sequence per order, unique only with `order_id` |
| order_payments | payment record | (`order_id`, `payment_sequential`) | 2,961 orders have several payments |
| order_reviews | review–order pair | (`review_id`, `order_id`) | `review_id` alone repeats (98,410 distinct of 99,224) |
| products | product | `product_id` | unique |
| sellers | seller | `seller_id` | unique |
| category_translation | category | `product_category_name` | unique |
| geolocation | raw point | **none as supplied** | 1,000,163 rows, 19,015 ZIP prefixes; aggregated into `zip_code` |

**`customer_id` vs `customer_unique_id`.** `orders.customer_id` is also unique (99,441 distinct), so every `customer_id` belongs to exactly one order: Olist issues a new `customer_id` per order. The person is `customer_unique_id`. Counting `customer_id` overstates delivered customers by 3,120.

| orders_per_unique_customer | unique_customers |
|---|---|
| 1 | 93,099 |
| 2 | 2,745 |
| 3 | 203 |
| 4 | 30 |
| 5 | 8 |
| 6 | 6 |
| 7 | 3 |
| 9 | 1 |
| 17 | 1 |

### Relationship specification

```
customers (customer_unique_id = person)
   │ 1:1 on customer_id
orders ──1:M── order_items ──M:1── products ──M:1── category_translation
   │                 └──────M:1── sellers
   ├──1:M── order_payments
   └──1:M── order_reviews        (≈1:1 in practice; 547 orders have 2–3)

customers ──M:1── zip_code ──1:M── sellers      (geography dimension)
```

| Relationship | Cardinality | Explanation |
|---|---|---|
| customers → orders | **1 : 1** (on `customer_id`) | each order gets its own `customer_id`; enforced by `UNIQUE(orders.customer_id)` |
| customer_unique_id → orders | 1 : M | the real person can place many orders (max 17 per person) |
| orders → order_items | 1 : 0..M | 775 orders (mostly `unavailable`/`canceled`) have no items |
| order_items → products | M : 1 | every item references a product |
| order_items → sellers | M : 1 | every item references a seller; 1,278 orders involve 2+ sellers |
| orders → order_payments | 1 : 0..M | 1 order has no payment record |
| orders → order_reviews | 1 : 0..M | 768 orders have no review, 547 have more than one |
| products → category_translation | M : 0..1 | 610 products have no category |
| customers / sellers → zip_code | M : 1 | after aggregating geolocation to one row per prefix |

**No many-to-many relationships are forced.** Products ↔ sellers and orders ↔ sellers are genuinely M:M, but both are already resolved by `order_items`, which acts as the associative table.

---

## 5. Data quality assessment

All checks run on the raw staging layer, where missing values are empty strings.

### 5.1 Missing values

```sql
SELECT COUNT(*)                                         AS total_rows,
       SUM(order_id = '')                               AS order_id,
       SUM(customer_id = '')                            AS customer_id,
       SUM(order_status = '')                           AS order_status,
       SUM(order_purchase_timestamp = '')               AS purchase_ts,
       SUM(order_approved_at = '')                      AS approved_at,
       SUM(order_delivered_carrier_date = '')           AS delivered_carrier,
       SUM(order_delivered_customer_date = '')          AS delivered_customer,
       SUM(order_estimated_delivery_date = '')          AS estimated_delivery
FROM stg_orders;
```

| total_rows | order_id | customer_id | order_status | purchase_ts | approved_at | delivered_carrier | delivered_customer | estimated_delivery |
|---|---|---|---|---|---|---|---|---|
| 99,441 | 0 | 0 | 0 | 0 | 160 | 1,783 | 2,965 | 0 |

Missing order timestamps are **structurally expected**, not errors: undelivered orders cannot have a delivery date. The status-by-timestamp matrix confirms this, and isolates the true anomalies: 8 `delivered` orders with no delivery date, 14 `delivered` orders with no approval time, and 6 `canceled` orders that do have a delivery date.

| order_status | orders | no_approval_ts | no_carrier_ts | no_delivery_ts | has_delivery_ts |
|---|---|---|---|---|---|
| delivered | 96,478 | 14 | 2 | 8 | 96,470 |
| shipped | 1,107 | 0 | 0 | 1,107 | 0 |
| canceled | 625 | 141 | 550 | 619 | 6 |
| unavailable | 609 | 0 | 609 | 609 | 0 |
| invoiced | 314 | 0 | 314 | 314 | 0 |
| processing | 301 | 0 | 301 | 301 | 0 |
| created | 5 | 5 | 5 | 5 | 0 |
| approved | 2 | 0 | 2 | 2 | 0 |

| total_rows | category | name_length | description_length | photos_qty | weight_g | length_cm | height_cm | width_cm |
|---|---|---|---|---|---|---|---|---|
| 32,951 | 610 | 610 | 610 | 610 | 2 | 2 | 2 | 2 |

The same 610 products are missing category, name length, description length and photo count — one block of incomplete catalogue records, not random gaps. They are still sold products, so they are kept.

| total_rows | comment_title_missing | pct_title_missing | comment_message_missing | pct_message_missing | score_missing |
|---|---|---|---|---|---|
| 99,224 | 87,656 | 88.34 | 58,247 | 58.7 | 0 |

Comments are optional: 88% of reviews have no title and 59% no message. The score is always present, so every review row is analytically valid.

| tbl | missing_cells |
|---|---|
| customers | 0 |
| order_items | 0 |
| order_payments | 0 |
| sellers | 0 |
| geolocation | 0 |
| category_translation | 0 |

### 5.2 Duplicates

| tbl | duplicate_rows |
|---|---|
| customers | 0 |
| orders | 0 |
| order_items | 0 |
| order_payments | 0 |
| order_reviews | 0 |
| products | 0 |
| sellers | 0 |
| geolocation | 279,667 |

Only geolocation contains exact duplicate rows (279,667). No transactional table has a duplicated row.

| orders_with_multiple_reviews | of_which_conflicting_scores | review_ids_reused_across_orders |
|---|---|---|
| 547 | 202 | 789 |

These are not duplicate rows (every (review_id, order_id) pair is unique) but **grain anomalies**: 547 orders have several reviews and 202 of them have conflicting scores. Joining reviews directly to orders would therefore double-count those orders; the model uses the latest review per order.

| tbl | rows_ | orders | orders_with_gt1_row | max_rows_per_order |
|---|---|---|---|---|
| order_items | 112,650 | 98,666 | 9,803 | 21 |
| order_payments | 103,886 | 99,440 | 2,961 | 29 |
| order_reviews | 99,224 | 98,673 | 547 | 3 |

### 5.3 Data types, dates and numeric validity

All timestamps parse cleanly with `STR_TO_DATE` — there are no malformed dates.

| bad_purchase | bad_approved | bad_carrier | bad_customer | bad_estimated | first_purchase | last_purchase |
|---|---|---|---|---|---|---|
| 0 | 0 | 0 | 0 | 0 | 2016-09-04 21:15:19 | 2018-10-17 17:30:18 |

| approved_before_purchase | carrier_before_approval | carrier_before_purchase | delivered_before_purchase | delivered_before_carrier |
|---|---|---|---|---|
| 0 | 1,359 | 166 | 0 | 23 |

1,359 orders record a carrier hand-over **before** payment approval and 166 before the purchase itself; 23 are delivered before reaching the carrier. These are system-logging inconsistencies. The records are kept, but they are excluded from stage-duration analysis via the `valid_delivery_chain` flag.

| measure | min_val | max_val | zero_or_negative |
|---|---|---|---|
| order_items.price | 0.85 | 6,735 | 0 |
| order_items.freight_value | 0 | 409.68 | 383 |
| payments.payment_value | 0 | 13,664.08 | 9 |
| payments.payment_installments | 0 | 24 | 2 |
| products.product_weight_g | 0 | 40,425 | 4 |
| reviews.review_score | 1 | 5 | 0 |

| payment_type | rows_ | zero_value_rows |
|---|---|---|
| credit_card | 76,795 | 0 |
| boleto | 19,784 | 0 |
| voucher | 5,775 | 6 |
| debit_card | 1,529 | 0 |
| not_defined | 3 | 3 |

Findings: 383 item lines with zero freight (valid — free shipping), 9 zero-value payments (6 vouchers, 3 `not_defined`), 2 credit-card payments with 0 instalments (impossible), and 4 products weighing 0 g (impossible). Prices are all positive.

### 5.4 Category and geographic consistency

| product_category_name | products |
|---|---|
| (blank) | 610 |
| portateis_cozinha_e_preparadores_de_alimentos | 10 |
| pc_gamer | 3 |

| raw_rows | distinct_rows | distinct_zip_prefixes | points_outside_brazil_bbox | zips_in_gt1_state | zips_with_gt1_city_spelling |
|---|---|---|---|---|---|
| 1,000,163 | 720,496 | 19,015 | 42 | 8 | 551 |

The database's default collation (`utf8mb4_0900_ai_ci`) is **accent-insensitive**, so a normal `GROUP BY` silently merges "são paulo" into "sao paulo" and hides the problem. Grouping with a binary collation exposes the real variants, including mojibake:

```sql
SELECT geolocation_city COLLATE utf8mb4_bin AS geolocation_city_exact, COUNT(*) AS rows_
FROM stg_geolocation
WHERE geolocation_zip_code_prefix BETWEEN '01000' AND '05999'      -- São Paulo capital ZIP range
GROUP BY geolocation_city_exact ORDER BY rows_ DESC;
```

| geolocation_city_exact | rows_ |
|---|---|
| sao paulo | 124,780 |
| são paulo | 23,337 |
| sp | 3 |
| sao bernardo do campo | 1 |
| jundiaí | 1 |
| taboão da serra | 1 |
| sãopaulo | 1 |
| sa£o paulo | 1 |
| sao jose dos campos | 1 |

Seller cities contain free-text errors — state suffixes, full addresses, an e-mail address and a number:

| seller_city | seller_state | sellers |
|---|---|---|
| sao paulo - sp | SP | 3 |
| santa barbara d´oeste | SP | 2 |
| 04482255 | RJ | 1 |
| auriflama/sp | SP | 1 |
| barbacena/ minas gerais | MG | 1 |
| carapicuiba / sao paulo | SP | 1 |
| cariacica / es | ES | 1 |
| jacarei / sao paulo | SP | 1 |
| lages - sc | SC | 1 |
| maua/sao paulo | SP | 1 |
| mogi das cruzes / sp | SP | 1 |
| novo hamburgo, rio grande do sul, brasil | RS | 1 |
| pinhais/pr | PR | 1 |
| ribeirao preto / sao paulo | SP | 1 |
| rio de janeiro / rio de janeiro | RJ | 1 |
| rio de janeiro \rio de janeiro | RJ | 1 |
| rio de janeiro, rio de janeiro, brasil | RJ | 1 |
| santo andre/sao paulo | SP | 1 |
| sao paulo / sao paulo | SP | 1 |
| sao sebastiao da grama/sp | SP | 1 |
| sbc/sp | SP | 1 |
| sp / sp | SP | 1 |
| vendas@creditparts.com.br | PR | 1 |

### 5.5 Orphans and referential integrity

```sql
SELECT 'orders.customer_id -> customers' AS relationship,
       SUM(c.customer_id IS NULL) AS orphan_rows FROM stg_orders o LEFT JOIN stg_customers c ON c.customer_id = o.customer_id
UNION ALL SELECT 'order_items.order_id -> orders', SUM(o.order_id IS NULL)
  FROM stg_order_items i LEFT JOIN stg_orders o ON o.order_id = i.order_id
UNION ALL SELECT 'order_items.product_id -> products', SUM(p.product_id IS NULL)
  FROM stg_order_items i LEFT JOIN stg_products p ON p.product_id = i.product_id
UNION ALL SELECT 'order_items.seller_id -> sellers', SUM(s.seller_id IS NULL)
  FROM stg_order_items i LEFT JOIN stg_sellers s ON s.seller_id = i.seller_id
UNION ALL SELECT 'order_payments.order_id -> orders', SUM(o.order_id IS NULL)
  FROM stg_order_payments p LEFT JOIN stg_orders o ON o.order_id = p.order_id
UNION ALL SELECT 'order_reviews.order_id -> orders', SUM(o.order_id IS NULL)
  FROM stg_order_reviews r LEFT JOIN stg_orders o ON o.order_id = r.order_id
UNION ALL SELECT 'products.category -> translation (non-blank)', SUM(t.product_category_name IS NULL)
  FROM stg_products p LEFT JOIN stg_category_translation t ON t.product_category_name = p.product_category_name
  WHERE p.product_category_name <> ''
UNION ALL SELECT 'customers.zip -> geolocation', SUM(NOT EXISTS (SELECT 1 FROM stg_geolocation g
                     WHERE g.geolocation_zip_code_prefix = c.customer_zip_code_prefix))
  FROM stg_customers c
UNION ALL SELECT 'sellers.zip -> geolocation', SUM(NOT EXISTS (SELECT 1 FROM stg_geolocation g
                     WHERE g.geolocation_zip_code_prefix = s.seller_zip_code_prefix))
  FROM stg_sellers s;
```

| relationship | orphan_rows |
|---|---|
| orders.customer_id -> customers | 0 |
| order_items.order_id -> orders | 0 |
| order_items.product_id -> products | 0 |
| order_items.seller_id -> sellers | 0 |
| order_payments.order_id -> orders | 0 |
| order_reviews.order_id -> orders | 0 |
| products.category -> translation (non-blank) | 13 |
| customers.zip -> geolocation | 278 |
| sellers.zip -> geolocation | 7 |

| check_ | rows_ |
|---|---|
| orders without items | 775 |
| orders without payments | 1 |
| orders without reviews | 768 |
| customers without orders | 0 |
| products never sold | 0 |
| sellers with no sales | 0 |

| order_status | orders_without_items |
|---|---|
| unavailable | 603 |
| canceled | 164 |
| created | 5 |
| invoiced | 2 |
| shipped | 1 |

All transactional foreign keys are clean. The only unmatched references are 13 products in two untranslated categories and 285 customer/seller rows whose ZIP prefix does not exist in geolocation.

### 5.6 Cross-table reconciliation

| orders_in_both | match_within_1_centavo | paid_more_than_items | paid_less_than_items | sum_price_plus_freight | sum_payment_value |
|---|---|---|---|---|---|
| 98,665 | 98,285 | 291 | 89 | 15,843,409.78 | 15,846,280.17 |

For 99.6% of orders, payments equal price + freight to the centavo. The 380 mismatches are consistent with instalment interest (overpayment) or vouchers/partial records (underpayment). This is why revenue is measured from `order_items.price`, not from payments.

---

## 6. SQL cleaning

`03_clean_model.sql` builds a typed, constrained database (`olist`) from staging. Principles: **no valid record deleted for containing NULLs; blanks become NULL, never fake values; only true duplicates removed; every rule documented and flagged.**

| # | Issue | Decision | Rows |
|---|---|---|---|
| 1 | All columns loaded as text | Cast to `CHAR(32) ascii_bin` IDs, `DATETIME`, `DECIMAL(10,2)`, `ENUM`, small unsigned ints | all |
| 2 | Blank timestamps (orders) | `NULLIF(...,'')` → NULL; rows kept | 4,908 cells |
| 3 | Chronology anomalies | Kept; flagged in view (`valid_delivery_chain`) | 1,388 delivered orders excluded from stage timing |
| 4 | Products missing category | Kept with NULL FK; labelled `uncategorized` in `v_product` | 610 |
| 5 | Products weighing 0 g | Set to NULL, flagged `weight_was_zero` | 4 |
| 6 | Categories missing from translation file | Added 2 rows with `is_supplemented = 1` | 13 products |
| 7 | 0 instalments | Recoded to 1, flagged `installments_recoded` | 2 |
| 8 | Zero-value payments | Kept (real records, no revenue effect) | 9 |
| 9 | Blank review comments | NULL; rows kept (score valid) | 58,256 messages* |
| 10 | Multiple reviews per order | Rows kept; latest review chosen with `ROW_NUMBER()` in views | 547 orders |
| 11 | Geolocation duplicates / out-of-Brazil points / non-unique ZIP | De-duplicated, filtered, aggregated to one row per prefix | 1,000,163 → 19,015 |
| 12 | ZIPs used by customers/sellers but absent from geolocation | Added to `zip_code` with `has_geolocation = 0` so FKs hold | 162 prefixes |
| 13 | City spelling (accents, mojibake, free text) | `fn_std_city()` + seller-specific parsing | see below |
| 14 | Status/state/category text | `LOWER/UPPER(TRIM())` | all |

\*58,247 raw blanks plus 9 whitespace-only messages that became blank after `TRIM`.

### City standardisation function

```sql
CREATE FUNCTION fn_std_city(s VARCHAR(200)) RETURNS VARCHAR(200)
DETERMINISTIC NO SQL
BEGIN
  DECLARE r VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;
  IF s IS NULL OR TRIM(s) = '' THEN RETURN NULL; END IF;
  SET r = LOWER(TRIM(s));
  SET r = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(r,'á','a'),'à','a'),'â','a'),'ã','a'),'ä','a');
  -- … same for e, i, o, u, ç, ñ …
  SET r = REPLACE(REPLACE(REPLACE(r,'´',''''),'`',''''),'£','');
  WHILE INSTR(r,'  ') > 0 DO SET r = REPLACE(r,'  ',' '); END WHILE;
  RETURN TRIM(r);
END
```

### Geolocation → `zip_code` dimension

```sql
INSERT INTO zip_code
WITH dedup AS (                                  -- (a) exact duplicates removed
  SELECT DISTINCT geolocation_zip_code_prefix AS zip,
         CAST(geolocation_lat AS DECIMAL(18,14)) AS lat,
         CAST(geolocation_lng AS DECIMAL(18,14)) AS lng,
         fn_std_city(geolocation_city)          AS city,
         UPPER(TRIM(geolocation_state))         AS state
  FROM olist_stg.stg_geolocation
),
valid AS (                                       -- (b) inside Brazil only
  SELECT * FROM dedup
  WHERE lat BETWEEN -33.75 AND 5.27 AND lng BETWEEN -73.99 AND -34.79
),
centroid AS (                                    -- (c) one row per prefix
  SELECT zip, AVG(lat) AS lat, AVG(lng) AS lng, COUNT(*) AS pts
  FROM valid GROUP BY zip
),
modal_city AS (
  SELECT zip, city, state,
         ROW_NUMBER() OVER (PARTITION BY zip ORDER BY COUNT(*) DESC, city) AS rn
  FROM dedup GROUP BY zip, city, state
)
SELECT m.zip, c.lat, c.lng, m.city, m.state, COALESCE(c.pts, 0), 1
FROM modal_city m
LEFT JOIN centroid c ON c.zip = m.zip
WHERE m.rn = 1;
```

### Cleaning audit

| table_name | raw_rows | clean_rows |
|---|---|---|
| orders | 99,441 | 99,441 |
| customers | 99,441 | 99,441 |
| order_items | 112,650 | 112,650 |
| order_payments | 103,886 | 103,886 |
| order_reviews | 99,224 | 99,224 |
| products | 32,951 | 32,951 |
| sellers | 3,095 | 3,095 |
| category_translation | 71 | 73 |
| geolocation -> zip_code | 1,000,163 | 19,177 |

Every transactional and master table keeps **100% of its rows**. Only geolocation shrinks, by design (raw points → one row per ZIP prefix).

| has_geolocation | zip_prefixes | without_coordinates | valid_points_used |
|---|---|---|---|
| 1 | 19,015 | 5 | 720,462 |
| 0 | 162 | 162 | 0 |

| source | distinct_city_values |
|---|---|
| geolocation (raw, exact spelling) | 8,010 |
| zip_code.geo_city (standardised) | 5,771 |
| customers (raw) | 4,119 |
| customers (standardised) | 4,119 |
| sellers (raw) | 611 |
| sellers (standardised) | 584 |

Customer cities were already clean (no change); geolocation city variants fell from 8,010 to 5,771 and seller cities from 611 to 584.

| raw_value | cleaned_value | seller_state |
|---|---|---|
| 04482255 | NULL | RJ |
| auriflama/sp | auriflama | SP |
| barbacena/ minas gerais | barbacena | MG |
| carapicuiba / sao paulo | carapicuiba | SP |
| cariacica / es | cariacica | ES |
| jacarei / sao paulo | jacarei | SP |
| lages - sc | lages | SC |
| maua/sao paulo | maua | SP |
| mogi das cruzes / sp | mogi das cruzes | SP |
| novo hamburgo, rio grande do sul, brasil | novo hamburgo | RS |
| pinhais/pr | pinhais | PR |
| ribeirao preto / sao paulo | ribeirao preto | SP |
| rio de janeiro / rio de janeiro | rio de janeiro | RJ |
| rio de janeiro \rio de janeiro | rio de janeiro | RJ |
| rio de janeiro, rio de janeiro, brasil | rio de janeiro | RJ |
| santa barbara d´oeste | santa barbara d'oeste | SP |
| santa barbara d´oeste | santa barbara d'oeste | SP |
| santo andre/sao paulo | santo andre | SP |
| sao paulo - sp | sao paulo | SP |
| sao paulo - sp | sao paulo | SP |
| sao paulo - sp | sao paulo | SP |
| sao paulo / sao paulo | sao paulo | SP |
| sao sebastiao da grama/sp | sao sebastiao da grama | SP |
| sbc | sao bernardo do campo | SP |
| sbc/sp | sao bernardo do campo | SP |
| sp | sao paulo | SP |
| sp | sao paulo | SP |
| sp | sao paulo | SP |
| sp | sao paulo | SP |
| sp / sp | sao paulo | SP |
| vendas@creditparts.com.br | NULL | PR |

| cleaning_rule | rows_affected |
|---|---|
| products.weight_was_zero -> NULL | 4 |
| products.category NULL (kept, labelled uncategorized) | 610 |
| payments.installments 0 -> 1 | 2 |
| reviews.comment_message NULL (kept) | 58,256 |
| category_translation supplemented | 2 |

---

## 7. ER diagram and relational model

```mermaid
erDiagram
    CUSTOMERS ||--|| ORDERS : "places (customer_id, 1:1)"
    ORDERS ||--o{ ORDER_ITEMS : contains
    ORDERS ||--o{ ORDER_PAYMENTS : "paid by"
    ORDERS ||--o{ ORDER_REVIEWS : "reviewed in"
    PRODUCTS ||--o{ ORDER_ITEMS : "sold as"
    SELLERS ||--o{ ORDER_ITEMS : fulfils
    CATEGORY_TRANSLATION |o--o{ PRODUCTS : classifies
    ZIP_CODE ||--o{ CUSTOMERS : locates
    ZIP_CODE ||--o{ SELLERS : locates

    CUSTOMERS {
        char32 customer_id PK
        char32 customer_unique_id "person key, indexed"
        char5 customer_zip_code_prefix FK
        varchar customer_city
        char2 customer_state
    }
    ORDERS {
        char32 order_id PK
        char32 customer_id FK "UNIQUE"
        enum order_status
        datetime order_purchase_timestamp
        datetime order_approved_at
        datetime order_delivered_carrier_date
        datetime order_delivered_customer_date
        datetime order_estimated_delivery_date
    }
    ORDER_ITEMS {
        char32 order_id PK,FK
        tinyint order_item_id PK
        char32 product_id FK
        char32 seller_id FK
        datetime shipping_limit_date
        decimal price
        decimal freight_value
    }
    ORDER_PAYMENTS {
        char32 order_id PK,FK
        tinyint payment_sequential PK
        enum payment_type
        tinyint payment_installments
        decimal payment_value
    }
    ORDER_REVIEWS {
        char32 review_id PK
        char32 order_id PK,FK
        tinyint review_score
        varchar review_comment_title
        text review_comment_message
        datetime review_creation_date
        datetime review_answer_timestamp
    }
    PRODUCTS {
        char32 product_id PK
        varchar product_category_name FK
        smallint product_name_lenght
        smallint product_description_lenght
        tinyint product_photos_qty
        int product_weight_g
        smallint product_length_cm
        smallint product_height_cm
        smallint product_width_cm
    }
    SELLERS {
        char32 seller_id PK
        char5 seller_zip_code_prefix FK
        varchar seller_city
        char2 seller_state
    }
    CATEGORY_TRANSLATION {
        varchar product_category_name PK
        varchar product_category_name_english
    }
    ZIP_CODE {
        char5 zip_code_prefix PK
        decimal latitude
        decimal longitude
        varchar geo_city
        char2 geo_state
    }
```

### Relational model specification

| Table | Primary key | Foreign key(s) | Relationship | Cardinality | Business purpose |
|---|---|---|---|---|---|
| `orders` | `order_id` | `customer_id` → customers (UNIQUE) | order belongs to one order-level customer | 1 : 1 | central fact: status, timeline, promise |
| `customers` | `customer_id` | `customer_zip_code_prefix` → zip_code | customer located in one ZIP | M : 1 | who bought, where; `customer_unique_id` identifies the person |
| `order_items` | (`order_id`, `order_item_id`) | `order_id` → orders; `product_id` → products; `seller_id` → sellers | lines of an order; resolves orders↔products↔sellers M:M | orders 1 : M items; items M : 1 product / seller | revenue, units, freight |
| `order_payments` | (`order_id`, `payment_sequential`) | `order_id` → orders | how an order was paid | orders 1 : M payments | payment mix, instalments |
| `order_reviews` | (`review_id`, `order_id`) | `order_id` → orders | customer feedback on an order | orders 1 : M reviews | satisfaction |
| `products` | `product_id` | `product_category_name` → category_translation (nullable) | product classified in ≤1 category | M : 0..1 | catalogue attributes |
| `sellers` | `seller_id` | `seller_zip_code_prefix` → zip_code | seller located in one ZIP | M : 1 | marketplace supply |
| `category_translation` | `product_category_name` | — | lookup | 1 : M products | English reporting labels |
| `zip_code` | `zip_code_prefix` | — | geography dimension | 1 : M customers / sellers | coordinates, region mapping |

All nine foreign keys are **declared and enforced by InnoDB**. Because the data was inserted after the constraints were created, a successful load is itself proof of referential integrity.

| child_table | fk_column | parent_table | parent_key | CONSTRAINT_NAME |
|---|---|---|---|---|
| customers | customer_zip_code_prefix | zip_code | zip_code_prefix | fk_customers_zip |
| order_items | order_id | orders | order_id | fk_items_order |
| order_items | product_id | products | product_id | fk_items_product |
| order_items | seller_id | sellers | seller_id | fk_items_seller |
| order_payments | order_id | orders | order_id | fk_payments_order |
| order_reviews | order_id | orders | order_id | fk_reviews_order |
| orders | customer_id | customers | customer_id | fk_orders_customer |
| products | product_category_name | category_translation | product_category_name | fk_products_category |
| sellers | seller_zip_code_prefix | zip_code | zip_code_prefix | fk_sellers_zip |

| table_name | primary_key_columns | key_type |
|---|---|---|
| category_translation | product_category_name | single |
| customers | customer_id | single |
| fact_order | order_id | single |
| order_items | order_id,order_item_id | composite |
| order_payments | order_id,payment_sequential | composite |
| order_reviews | review_id,order_id | composite |
| orders | order_id | single |
| products | product_id | single |
| sellers | seller_id | single |
| zip_code | zip_code_prefix | single |

The full DDL is in `schema/olist_schema.sql`.

---

## 8. Relationship validation and join inflation

### 8.1 Validation queries

**Orders → Customers**

```sql
SELECT
  (SELECT COUNT(*) FROM orders)                                                   AS orders,
  (SELECT COUNT(*) FROM orders o LEFT JOIN customers c USING (customer_id)
    WHERE c.customer_id IS NULL)                                                  AS orders_without_customer,
  (SELECT COUNT(*) FROM customers c LEFT JOIN orders o USING (customer_id)
    WHERE o.order_id IS NULL)                                                     AS customers_without_order,
  (SELECT MAX(n) FROM (SELECT customer_id, COUNT(*) n FROM orders GROUP BY customer_id) x)
                                                                                  AS max_orders_per_customer_id,
  (SELECT MAX(n) FROM (SELECT c.customer_unique_id, COUNT(*) n FROM orders o
     JOIN customers c USING (customer_id) GROUP BY c.customer_unique_id) y)       AS max_orders_per_customer_unique_id;
```

| orders | orders_without_customer | customers_without_order | max_orders_per_customer_id | max_orders_per_customer_unique_id |
|---|---|---|---|---|
| 99,441 | 0 | 0 | 1 | 17 |

Every order has a customer and every `customer_id` has exactly one order (confirming 1:1); one person (`customer_unique_id`) has up to 17 orders (confirming 1:M at person level).

**Orders → Order Items**

```sql
SELECT
  (SELECT COUNT(*) FROM order_items i LEFT JOIN orders o USING (order_id) WHERE o.order_id IS NULL) AS items_without_order,
  (SELECT COUNT(*) FROM orders o WHERE NOT EXISTS (SELECT 1 FROM order_items i WHERE i.order_id = o.order_id)) AS orders_without_items,
  (SELECT COUNT(*) FROM orders o WHERE o.order_status = 'delivered'
     AND NOT EXISTS (SELECT 1 FROM order_items i WHERE i.order_id = o.order_id))                      AS delivered_orders_without_items,
  (SELECT ROUND(AVG(n), 3) FROM (SELECT order_id, COUNT(*) n FROM order_items GROUP BY order_id) a)    AS avg_items_per_order,
  (SELECT MAX(n) FROM (SELECT order_id, COUNT(*) n FROM order_items GROUP BY order_id) b)              AS max_items_per_order;
```

| items_without_order | orders_without_items | delivered_orders_without_items | avg_items_per_order | max_items_per_order |
|---|---|---|---|---|
| 0 | 775 | 0 | 1.142 | 21 |

775 orders have no items, but **none of them is delivered** — 767 are unavailable or cancelled and 8 are stuck in created/invoiced/shipped, all with no sales value, so analyses use `LEFT JOIN` from orders where they must be counted (status mix) and an implicit inner join where only sales matter.

**Order Items → Products / Sellers**

| items_without_product | products_never_sold | items_without_seller | sellers_never_sold | multi_seller_orders |
|---|---|---|---|---|
| 0 | 0 | 0 | 0 | 1,278 |

**Orders → Payments**

| payments_without_order | orders_without_payment | which_order | orders_with_multiple_payments |
|---|---|---|---|
| 0 | 1 | bfbd0f9bdef84302105ad712db648a6c (delivered) | 2,961 |

One delivered order (`bfbd0f9b…`) has items but no payment record. It is kept: product revenue comes from items, so it contributes R$134.97 of revenue but nothing to payment totals — one reason total payment value and GMV do not match exactly in KPI 1.

**Orders → Reviews**

| reviews_without_order | orders_without_review | orders_with_multiple_reviews |
|---|---|---|
| 0 | 768 | 547 |

768 orders have no review (treated as NULL, never as zero) and 547 have several (resolved to the latest).

**Products → Category translation**

| products_without_category | products_with_untranslated_category | products_using_supplemented_translation | translations_never_used |
|---|---|---|---|
| 610 | 0 | 13 | 0 |

After supplementing two translations, no product has an untranslated category; 610 have no category at all and are reported as `uncategorized`.

**Geography coverage**

| entity | rows_ | rows_without_coordinates | pct_geocoded |
|---|---|---|---|
| customers | 99,441 | 279 | 99.72 |
| sellers | 3,095 | 7 | 99.77 |

### 8.2 Join inflation — demonstrated and prevented

`order_items`, `order_payments` and `order_reviews` each have **many rows per `order_id`**. Joining them together multiplies rows: an order with 3 items, 2 payments and 2 reviews produces 3 × 2 × 2 = 12 rows, so its price is summed 4 times and its payments 6 times.

The query below calculates delivered revenue both ways.

```sql
WITH naive AS (                      -- the anti-pattern
  SELECT SUM(i.price)          AS revenue,
         SUM(p.payment_value)  AS payments,
         COUNT(*)              AS joined_rows,
         COUNT(DISTINCT o.order_id) AS orders
  FROM orders o
  JOIN order_items i     ON i.order_id = o.order_id
  JOIN order_payments p  ON p.order_id = o.order_id
  LEFT JOIN order_reviews r ON r.order_id = o.order_id
  WHERE o.order_status = 'delivered'
),
item_agg AS (                        -- correct: collapse each child to order grain FIRST
  SELECT order_id, SUM(price) AS revenue FROM order_items GROUP BY order_id
),
pay_agg AS (
  SELECT order_id, SUM(payment_value) AS payments FROM order_payments GROUP BY order_id
),
rev_agg AS (
  SELECT order_id, AVG(review_score) AS score FROM order_reviews GROUP BY order_id
),
correct AS (
  SELECT SUM(ia.revenue) AS revenue, SUM(pa.payments) AS payments,
         COUNT(*) AS joined_rows, COUNT(DISTINCT o.order_id) AS orders
  FROM orders o
  JOIN item_agg ia     ON ia.order_id = o.order_id
  JOIN pay_agg  pa     ON pa.order_id = o.order_id
  LEFT JOIN rev_agg ra ON ra.order_id = o.order_id
  WHERE o.order_status = 'delivered'
)
SELECT 'naive multi-join' AS method, revenue, payments, joined_rows, orders FROM naive
UNION ALL
SELECT 'aggregate-then-join', revenue, payments, joined_rows, orders FROM correct
UNION ALL
SELECT 'overstatement (naive - correct)', n.revenue - c.revenue, n.payments - c.payments,
       n.joined_rows - c.joined_rows, n.orders - c.orders
FROM naive n CROSS JOIN correct c;
```

| method | revenue | payments | joined_rows | orders |
|---|---|---|---|---|
| naive multi-join | 13,876,336.76 | 19,881,945.07 | 115,720 | 96,477 |
| aggregate-then-join | 13,221,363.14 | 15,422,461.77 | 96,477 | 96,477 |
| overstatement (naive - correct) | 654,973.62 | 4,459,483.30 | 19,243 | 0 |

The naive join **overstates revenue by R$654,974 (+5.0%) and payments by R$4,459,483 (+28.9%)**, while `COUNT(DISTINCT order_id)` looks perfectly correct — which is exactly why this error goes unnoticed. The fix is to **aggregate each child table to order grain in its own CTE, then join 1:1**.

Worst individual cases:

| order_id | n_items | n_pay | n_reviews | rows_after_naive_join | true_revenue | naive_revenue |
|---|---|---|---|---|---|---|
| 895ab968e7bb0d5659d16cd74cd1650c | 3 | 21 | 1 | 63 | 109.78 | 2,305.38 |
| fedcd9f7ccdc8cba3a18defedd1a5547 | 2 | 19 | 1 | 38 | 159.98 | 3,039.62 |
| fa65dad1b0e818e3ccc5cb0e39231352 | 1 | 29 | 1 | 29 | 392.55 | 11,383.95 |
| ccf804e764ed5650cd8759557269dc13 | 1 | 26 | 1 | 26 | 49.99 | 1,299.74 |
| 465c2e1bee4561cb39e0db8c5993aafc | 2 | 12 | 1 | 24 | 824 | 9,888 |

One order with 29 payment records would report R$11,383.95 instead of R$392.55.

---

## 9. Analytical layer (views)

`05_views.sql` creates a reusable layer with **two grains that are never mixed**:

- `v_order_summary` — exactly one row per order. Items, payments and reviews are each aggregated in a separate CTE before joining; the latest review per order is chosen with `ROW_NUMBER()`. Also derives delivery days, delay vs estimate, `is_late` and `valid_delivery_chain`.
- `v_item_detail` — exactly one row per item line, enriched only through M:1 joins (order, customer, product, seller), so `SUM(price)` is always safe.
- `v_product` — products with an English category label, never NULL.
- `fact_order` — an indexed table materialised from `v_order_summary` (MySQL has no materialised views) for fast repeated analysis.

### Metric definitions used throughout

| Metric | Definition |
|---|---|
| **Revenue** | `SUM(order_items.price)` on **delivered** orders — product sales value, excluding freight |
| Freight | `SUM(order_items.freight_value)`, reported separately |
| GMV incl. freight | Revenue + freight |
| Payment value | `SUM(order_payments.payment_value)` (includes freight, instalment interest, vouchers) |
| Order review | latest review per order |
| Delivery days | purchase → customer delivery, in days (minute precision) |
| Late | delivered **date** > estimated delivery **date** |
| Customer | `customer_unique_id` |

```sql
CREATE OR REPLACE VIEW v_order_summary AS
WITH item_agg AS (
  SELECT order_id, COUNT(*) AS items, COUNT(DISTINCT product_id) AS distinct_products,
         COUNT(DISTINCT seller_id) AS distinct_sellers,
         SUM(price) AS item_revenue, SUM(freight_value) AS freight
  FROM order_items GROUP BY order_id
),
pay_agg AS (
  SELECT order_id, SUM(payment_value) AS payment_value, COUNT(*) AS payment_rows,
         MAX(payment_installments) AS max_installments,
         SUBSTRING_INDEX(GROUP_CONCAT(payment_type ORDER BY payment_value DESC, payment_sequential), ',', 1)
           AS main_payment_type
  FROM order_payments GROUP BY order_id
),
review_ranked AS (
  SELECT order_id, review_score,
         ROW_NUMBER() OVER (PARTITION BY order_id
                            ORDER BY review_answer_timestamp DESC, review_creation_date DESC, review_id) AS rn
  FROM order_reviews
)
SELECT o.order_id, o.customer_id, c.customer_unique_id, c.customer_city, c.customer_state,
       o.order_status, o.order_purchase_timestamp, /* … timestamps … */
       COALESCE(ia.items, 0) AS items, COALESCE(ia.item_revenue, 0) AS item_revenue,
       COALESCE(ia.freight, 0) AS freight, pa.payment_value, pa.main_payment_type,
       pa.max_installments, rr.review_score,
       ROUND(TIMESTAMPDIFF(MINUTE, o.order_purchase_timestamp, o.order_delivered_customer_date) / 1440, 2) AS delivery_days,
       DATEDIFF(o.order_delivered_customer_date, o.order_estimated_delivery_date) AS delay_days,
       CASE WHEN o.order_delivered_customer_date IS NULL THEN NULL
            WHEN DATE(o.order_delivered_customer_date) > DATE(o.order_estimated_delivery_date) THEN 1
            ELSE 0 END AS is_late
       /* … valid_delivery_chain flag … */
FROM orders o
JOIN customers c           ON c.customer_id = o.customer_id
LEFT JOIN item_agg ia      ON ia.order_id = o.order_id
LEFT JOIN pay_agg pa       ON pa.order_id = o.order_id
LEFT JOIN review_ranked rr ON rr.order_id = o.order_id AND rr.rn = 1;
```

### View validation

| object_ | rows_ | distinct_grain_keys | expected_rows |
|---|---|---|---|
| v_order_summary | 99,441 | 99,441 | 99,441 |
| v_item_detail | 112,650 | 112,650 | 112,650 |
| fact_order | 99,441 | 99,441 | 99,441 |

| revenue_order_grain | revenue_item_grain | revenue_base_tables |
|---|---|---|
| 13,221,498.11 | 13,221,498.11 | 13,221,498.11 |

Revenue ties out to the centavo across the order grain, the item grain and the base tables.

| delivered_orders | with_delivery_timestamp | with_valid_full_chain | excluded_from_stage_analysis |
|---|---|---|---|
| 96,478 | 96,470 | 95,082 | 1,388 |

---

## 10. Ten KPIs

Scope: delivered orders (realised sales) unless stated.

### KPI 1 — Total Revenue
**Definition:** `SUM(price)` on delivered orders; freight, GMV and payments shown alongside. **Business purpose:** headline measure of realised sales.

```sql
SELECT ROUND(SUM(item_revenue), 2)                 AS total_revenue,
       ROUND(SUM(freight), 2)                      AS total_freight,
       ROUND(SUM(item_revenue + freight), 2)       AS gmv_incl_freight,
       ROUND(SUM(payment_value), 2)                AS total_payment_value
FROM fact_order
WHERE order_status = 'delivered';
```

| total_revenue | total_freight | gmv_incl_freight | total_payment_value |
|---|---|---|---|
| 13,221,498.11 | 2,198,275.64 | 15,419,773.75 | 15,422,461.77 |

**Interpretation:** R$13.22M of product revenue plus R$2.20M of freight. Payments exceed GMV by only R$2,688, confirming the two sources reconcile.

### KPI 2 — Total Orders
**Definition:** all orders and delivered orders. **Business purpose:** volume and fulfilment health.

```sql
SELECT COUNT(*)                                            AS all_orders,
       SUM(order_status = 'delivered')                     AS delivered_orders,
       SUM(order_status IN ('canceled', 'unavailable'))    AS canceled_or_unavailable,
       ROUND(100 * AVG(order_status = 'delivered'), 2)     AS pct_delivered,
       ROUND(100 * AVG(order_status IN ('canceled', 'unavailable')), 2) AS pct_canceled_unavailable
FROM fact_order;
```

| all_orders | delivered_orders | canceled_or_unavailable | pct_delivered | pct_canceled_unavailable |
|---|---|---|---|---|
| 99,441 | 96,478 | 1,234 | 97.02 | 1.24 |

**Interpretation:** 97.0% of orders are delivered; 1.2% are cancelled or unavailable. The remaining ~1.7% were still in progress (mostly `shipped`) when the snapshot was taken.

### KPI 3 — Unique Customers
**Definition:** `COUNT(DISTINCT customer_unique_id)` on delivered orders. **Business purpose:** size of the active customer base.

```sql
SELECT COUNT(DISTINCT customer_unique_id)  AS unique_customers_delivered,
       COUNT(DISTINCT customer_id)         AS customer_ids_delivered,
       COUNT(DISTINCT customer_id) - COUNT(DISTINCT customer_unique_id) AS overcount_if_customer_id_used
FROM fact_order WHERE order_status = 'delivered';
```

| unique_customers_delivered | customer_ids_delivered | overcount_if_customer_id_used |
|---|---|---|
| 93,358 | 96,478 | 3,120 |

**Interpretation:** 93,358 real customers. Using `customer_id` would overstate the base by 3,120 (3.3%) and make repeat behaviour invisible.

### KPI 4 — Average Order Value
**Definition:** revenue ÷ delivered orders. **Business purpose:** basket size; lever for revenue growth without more customers.

```sql
SELECT ROUND(AVG(item_revenue), 2)                  AS aov_product_revenue,
       ROUND(AVG(item_revenue + freight), 2)        AS aov_incl_freight,
       ROUND(AVG(payment_value), 2)                 AS avg_amount_paid
FROM fact_order WHERE order_status = 'delivered';
```

| aov_product_revenue | aov_incl_freight | avg_amount_paid |
|---|---|---|
| 137.04 | 159.83 | 159.86 |

**Interpretation:** R$137.04 per order in product value (R$159.83 including freight). The median order is only R$86.57 (U1), so the mean is pulled up by a long tail of expensive orders.

### KPI 5 — Total Items Sold
**Definition:** item lines on delivered orders. **Business purpose:** unit volume and basket depth.

```sql
SELECT SUM(items)                AS items_sold,
       ROUND(AVG(items), 3)      AS avg_items_per_order,
       SUM(items > 1)            AS multi_item_orders,
       ROUND(100 * AVG(items > 1), 2) AS pct_multi_item_orders
FROM fact_order WHERE order_status = 'delivered';
```

| items_sold | avg_items_per_order | multi_item_orders | pct_multi_item_orders |
|---|---|---|---|
| 110,197 | 1.142 | 9,635 | 9.99 |

**Interpretation:** 110,197 items; 90% of orders contain a single item. Cross-selling is almost absent.

### KPI 6 — Average Freight Cost
**Definition:** freight per order, per item, and as % of revenue. **Business purpose:** shipping cost burden on the customer.

```sql
SELECT ROUND(AVG(freight), 2)                              AS avg_freight_per_order,
       ROUND(SUM(freight) / SUM(items), 2)                 AS avg_freight_per_item,
       ROUND(100 * SUM(freight) / SUM(item_revenue), 2)    AS freight_pct_of_revenue
FROM fact_order WHERE order_status = 'delivered';
```

| avg_freight_per_order | avg_freight_per_item | freight_pct_of_revenue |
|---|---|---|
| 22.79 | 19.95 | 16.63 |

**Interpretation:** customers pay R$22.79 per order in freight — **16.6% on top of the product price**, a material conversion barrier.

### KPI 7 — Average Review Score
**Definition:** mean of the latest review per order (all reviewed orders). **Business purpose:** customer satisfaction.

```sql
SELECT COUNT(review_score)                              AS reviewed_orders,
       ROUND(AVG(review_score), 3)                      AS avg_review_score,
       ROUND(100 * AVG(review_score >= 4), 2)           AS pct_positive_4_5,
       ROUND(100 * AVG(review_score <= 2), 2)           AS pct_negative_1_2
FROM fact_order WHERE review_score IS NOT NULL;
```

| reviewed_orders | avg_review_score | pct_positive_4_5 | pct_negative_1_2 |
|---|---|---|---|
| 98,673 | 4.086 | 77.07 | 14.69 |

**Interpretation:** 4.09 / 5, with 77% positive but a sizeable 14.7% negative (1–2 stars).

### KPI 8 — Active Sellers
**Definition:** sellers with ≥1 delivered item. **Business purpose:** marketplace supply breadth.

```sql
SELECT COUNT(DISTINCT i.seller_id)                            AS active_sellers,
       (SELECT COUNT(*) FROM sellers)                         AS registered_sellers,
       ROUND(SUM(i.price) / COUNT(DISTINCT i.seller_id), 2)   AS avg_revenue_per_active_seller
FROM order_items i JOIN orders o USING (order_id)
WHERE o.order_status = 'delivered';
```

| active_sellers | registered_sellers | avg_revenue_per_active_seller |
|---|---|---|
| 2,970 | 3,095 | 4,451.68 |

**Interpretation:** 2,970 of 3,095 registered sellers made at least one delivered sale; average revenue per active seller is R$4,452 over the period — but this average hides heavy concentration (S2).

### KPI 9 — Average Delivery Time
**Definition:** purchase → customer delivery in days; median and 90th percentile via `ROW_NUMBER()`. **Business purpose:** speed of service.

```sql
WITH d AS (
  SELECT delivery_days,
         ROW_NUMBER() OVER (ORDER BY delivery_days) AS rn,
         COUNT(*)     OVER ()                       AS n
  FROM fact_order
  WHERE order_status = 'delivered' AND delivery_days IS NOT NULL
)
SELECT ROUND(AVG(delivery_days), 2)                                     AS avg_delivery_days,
       MAX(CASE WHEN rn = CEIL(n * 0.5) THEN delivery_days END)         AS median_delivery_days,
       MAX(CASE WHEN rn = CEIL(n * 0.9) THEN delivery_days END)         AS p90_delivery_days,
       MAX(n)                                                           AS orders_measured
FROM d;
```

| avg_delivery_days | median_delivery_days | p90_delivery_days | orders_measured |
|---|---|---|---|
| 12.56 | 10.22 | 23.1 | 96,470 |

**Interpretation:** mean 12.6 days, median 10.2; 1 in 10 orders takes more than 23 days.

### KPI 10 — On-Time Delivery Rate
**Definition:** share of delivered orders arriving on or before the estimated date. **Business purpose:** reliability of the delivery promise.

```sql
SELECT COUNT(*)                                  AS delivered_with_date,
       SUM(is_late = 0)                          AS on_time,
       SUM(is_late = 1)                          AS late,
       ROUND(100 * AVG(is_late = 0), 2)          AS on_time_rate_pct,
       ROUND(AVG(delay_days), 2)                 AS avg_days_vs_estimate   -- negative = early
FROM fact_order
WHERE order_status = 'delivered' AND order_delivered_customer_date IS NOT NULL;
```

| delivered_with_date | on_time | late | on_time_rate_pct | avg_days_vs_estimate |
|---|---|---|---|---|
| 96,470 | 89,936 | 6,534 | 93.23 | -11.88 |

**Interpretation:** 93.2% on time, and on average orders arrive 11.9 days **before** the estimate — Olist's promise is very conservative, yet 6,534 orders still missed it.

### Executive scorecard (one query, scalar subqueries)

```sql
SELECT
  (SELECT ROUND(SUM(item_revenue), 0) FROM fact_order WHERE order_status = 'delivered')            AS revenue,
  (SELECT COUNT(*) FROM fact_order WHERE order_status = 'delivered')                               AS delivered_orders,
  (SELECT COUNT(DISTINCT customer_unique_id) FROM fact_order WHERE order_status = 'delivered')     AS unique_customers,
  (SELECT ROUND(AVG(item_revenue), 2) FROM fact_order WHERE order_status = 'delivered')            AS aov,
  (SELECT SUM(items) FROM fact_order WHERE order_status = 'delivered')                             AS items_sold,
  (SELECT ROUND(AVG(freight), 2) FROM fact_order WHERE order_status = 'delivered')                 AS avg_freight,
  (SELECT ROUND(AVG(review_score), 2) FROM fact_order)                                             AS avg_review,
  (SELECT COUNT(DISTINCT seller_id) FROM order_items JOIN orders USING (order_id)
     WHERE order_status = 'delivered')                                                             AS active_sellers,
  (SELECT ROUND(AVG(delivery_days), 1) FROM fact_order WHERE order_status = 'delivered')           AS avg_delivery_days,
  (SELECT ROUND(100 * AVG(is_late = 0), 1) FROM fact_order
     WHERE order_status = 'delivered' AND is_late IS NOT NULL)                                     AS on_time_pct;
```

| revenue | delivered_orders | unique_customers | aov | items_sold | avg_freight | avg_review | active_sellers | avg_delivery_days | on_time_pct |
|---|---|---|---|---|---|---|---|---|---|
| 13,221,498 | 96,478 | 93,358 | 137.04 | 110,197 | 22.79 | 4.09 | 2,970 | 12.6 | 93.2 |

---

## 11. Ten univariate analyses

### U1 — Order value
**Business question:** what does a typical order look like, and where does revenue come from? **Purpose:** pricing, promotions and free-shipping thresholds.

```sql
SELECT CASE
         WHEN item_revenue <   50 THEN '01: < 50'
         WHEN item_revenue <  100 THEN '02: 50-99'
         WHEN item_revenue <  200 THEN '03: 100-199'
         WHEN item_revenue <  500 THEN '04: 200-499'
         WHEN item_revenue < 1000 THEN '05: 500-999'
         ELSE                          '06: 1000+'
       END                                              AS order_value_band_brl,
       COUNT(*)                                         AS orders,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct_orders,
       ROUND(SUM(item_revenue), 0)                      AS revenue,
       ROUND(100 * SUM(item_revenue) / SUM(SUM(item_revenue)) OVER (), 2) AS pct_revenue
FROM fact_order WHERE order_status = 'delivered'
GROUP BY order_value_band_brl ORDER BY order_value_band_brl;
```

| order_value_band_brl | orders | pct_orders | revenue | pct_revenue |
|---|---|---|---|---|
| 01: < 50 | 28,791 | 29.84 | 916,592 | 6.93 |
| 02: 50-99 | 27,726 | 28.74 | 2,091,913 | 15.82 |
| 03: 100-199 | 25,313 | 26.24 | 3,636,981 | 27.51 |
| 04: 200-499 | 11,148 | 11.55 | 3,321,288 | 25.12 |
| 05: 500-999 | 2,592 | 2.69 | 1,787,162 | 13.52 |
| 06: 1000+ | 908 | 0.94 | 1,467,562 | 11.1 |

| min_ | p25 | median | mean | p75 | p99 | max_ | std_dev |
|---|---|---|---|---|---|---|---|
| 0.85 | 45.9 | 86.57 | 137.04 | 149.9 | 990 | 13,440 | 209.05 |

**Interpretation:** 58.6% of orders are under R$100 but generate only 22.8% of revenue; orders of R$500+ are 3.6% of orders but 24.6% of revenue. The distribution is strongly right-skewed (mean 137 vs median 87). **Recommendation:** manage the high-value tail as a distinct segment (service, instalments, fraud checks) and use bundles to lift sub-R$100 baskets.

### U2 — Product categories by items sold
**Business question:** which categories move the most units? **Purpose:** assortment and inventory focus.

```sql
SELECT category,
       COUNT(*)                                          AS items_sold,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2)  AS pct_of_items,
       ROUND(100 * SUM(COUNT(*)) OVER (ORDER BY COUNT(*) DESC, category) / SUM(COUNT(*)) OVER (), 2)
                                                         AS cumulative_pct
FROM v_item_detail WHERE order_status = 'delivered'
GROUP BY category ORDER BY items_sold DESC LIMIT 15;
```

| category | items_sold | pct_of_items | cumulative_pct |
|---|---|---|---|
| bed_bath_table | 10,953 | 9.94 | 9.94 |
| health_beauty | 9,465 | 8.59 | 18.53 |
| sports_leisure | 8,431 | 7.65 | 26.18 |
| furniture_decor | 8,160 | 7.4 | 33.58 |
| computers_accessories | 7,644 | 6.94 | 40.52 |
| housewares | 6,795 | 6.17 | 46.69 |
| watches_gifts | 5,859 | 5.32 | 52 |
| telephony | 4,430 | 4.02 | 56.02 |
| garden_tools | 4,268 | 3.87 | 59.9 |
| auto | 4,140 | 3.76 | 63.65 |
| toys | 4,030 | 3.66 | 67.31 |
| cool_stuff | 3,718 | 3.37 | 70.69 |
| perfumery | 3,340 | 3.03 | 73.72 |
| baby | 2,982 | 2.71 | 76.42 |
| electronics | 2,729 | 2.48 | 78.9 |

| categories_with_sales | uncategorized_items |
|---|---|
| 74 | 1,537 |

**Interpretation:** 74 categories sell, but the top 7 account for over half of all items; bed_bath_table alone is ~10%. **Recommendation:** prioritise seller acquisition and merchandising in these core categories.

### U3 — Order status
**Business question:** how many orders fail or are stuck? **Purpose:** operational health.

```sql
SELECT order_status, COUNT(*) AS orders,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct
FROM orders GROUP BY order_status ORDER BY orders DESC;
```

| order_status | orders | pct |
|---|---|---|
| delivered | 96,478 | 97.02 |
| shipped | 1,107 | 1.11 |
| canceled | 625 | 0.63 |
| unavailable | 609 | 0.61 |
| invoiced | 314 | 0.32 |
| processing | 301 | 0.3 |
| created | 5 | 0.01 |
| approved | 2 | 0 |

**Interpretation:** 97% delivered; 1,234 orders (1.2%) were cancelled or unavailable — 603 "unavailable" orders never even received items, i.e. stock-outs after purchase. **Recommendation:** enforce real-time stock sync for sellers to eliminate "unavailable" orders.

### U4 — Payment methods
**Business question:** how do customers pay? **Purpose:** checkout and payment-partner strategy.

```sql
SELECT payment_type,
       COUNT(DISTINCT order_id)                           AS orders_using,
       COUNT(*)                                           AS payment_records,
       ROUND(SUM(payment_value), 0)                       AS value_paid,
       ROUND(100 * SUM(payment_value) / SUM(SUM(payment_value)) OVER (), 2) AS pct_value
FROM order_payments GROUP BY payment_type ORDER BY value_paid DESC;
```

| payment_type | orders_using | payment_records | value_paid | pct_value |
|---|---|---|---|---|
| credit_card | 76,505 | 76,795 | 12,542,084 | 78.34 |
| boleto | 19,784 | 19,784 | 2,869,361 | 17.92 |
| voucher | 3,866 | 5,775 | 379,437 | 2.37 |
| debit_card | 1,528 | 1,529 | 217,990 | 1.36 |
| not_defined | 3 | 3 | 0 | 0 |

**Interpretation:** credit card carries 78% of value; boleto (bank slip) 18%. Debit card is marginal. **Recommendation:** keep checkout optimised for credit card with instalments, and preserve boleto for unbanked customers.

### U5 — Review scores
**Business question:** how satisfied are customers? **Purpose:** service quality baseline.

```sql
SELECT review_score, COUNT(*) AS orders,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct
FROM fact_order WHERE review_score IS NOT NULL
GROUP BY review_score ORDER BY review_score DESC;
```

| review_score | orders | pct |
|---|---|---|
| 5 | 57,008 | 57.77 |
| 4 | 19,038 | 19.29 |
| 3 | 8,133 | 8.24 |
| 2 | 3,131 | 3.17 |
| 1 | 11,363 | 11.52 |

**Interpretation:** bimodal — 57.8% give 5 stars but 11.5% give 1 star, far more than 2 or 3 stars. Customers are either happy or very unhappy; the drivers of 1-star reviews are investigated in B5 and section 17.

### U6 — Freight per order
**Business question:** how much do customers pay for shipping? **Purpose:** freight policy.

```sql
SELECT CASE WHEN freight = 0  THEN '01: free (0)'
            WHEN freight < 10 THEN '02: 0.01-9.99'
            WHEN freight < 20 THEN '03: 10-19.99'
            WHEN freight < 30 THEN '04: 20-29.99'
            WHEN freight < 50 THEN '05: 30-49.99'
            WHEN freight < 100 THEN '06: 50-99.99'
            ELSE '07: 100+' END                         AS freight_band_brl,
       COUNT(*) AS orders,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct_orders
FROM fact_order WHERE order_status = 'delivered'
GROUP BY freight_band_brl ORDER BY freight_band_brl;
```

| freight_band_brl | orders | pct_orders |
|---|---|---|
| 01: free (0) | 336 | 0.35 |
| 02: 0.01-9.99 | 10,728 | 11.12 |
| 03: 10-19.99 | 52,356 | 54.27 |
| 04: 20-29.99 | 16,349 | 16.95 |
| 05: 30-49.99 | 10,604 | 10.99 |
| 06: 50-99.99 | 5,044 | 5.23 |
| 07: 100+ | 1,061 | 1.1 |

**Interpretation:** 54% of orders pay R$10–20; free shipping is almost non-existent (0.35%). 6.3% pay R$50 or more.

### U7 — Customer geography
**Business question:** where are customers? **Purpose:** regional marketing and logistics planning.

```sql
SELECT customer_state,
       COUNT(DISTINCT customer_unique_id) AS unique_customers,
       ROUND(100 * COUNT(DISTINCT customer_unique_id) / (SELECT COUNT(DISTINCT customer_unique_id) FROM customers), 2) AS pct
FROM customers GROUP BY customer_state ORDER BY unique_customers DESC LIMIT 12;
```

| customer_state | unique_customers | pct |
|---|---|---|
| SP | 40,302 | 41.94 |
| RJ | 12,384 | 12.89 |
| MG | 11,259 | 11.72 |
| RS | 5,277 | 5.49 |
| PR | 4,882 | 5.08 |
| SC | 3,534 | 3.68 |
| BA | 3,277 | 3.41 |
| DF | 2,075 | 2.16 |
| ES | 1,964 | 2.04 |
| GO | 1,952 | 2.03 |
| PE | 1,609 | 1.67 |
| CE | 1,313 | 1.37 |

**Interpretation:** São Paulo state alone holds 42% of unique customers; SP, RJ and MG together hold 67%.

### U8 — Seller geography
**Business question:** where is supply located? **Purpose:** compare supply with demand.

```sql
SELECT seller_state, COUNT(*) AS sellers,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct,
       ROUND(100 * SUM(COUNT(*)) OVER (ORDER BY COUNT(*) DESC, seller_state) / SUM(COUNT(*)) OVER (), 2) AS cumulative_pct
FROM sellers GROUP BY seller_state ORDER BY sellers DESC LIMIT 10;
```

| seller_state | sellers | pct | cumulative_pct |
|---|---|---|---|
| SP | 1,849 | 59.74 | 59.74 |
| PR | 349 | 11.28 | 71.02 |
| MG | 244 | 7.88 | 78.9 |
| SC | 190 | 6.14 | 85.04 |
| RJ | 171 | 5.53 | 90.57 |
| RS | 129 | 4.17 | 94.73 |
| GO | 40 | 1.29 | 96.03 |
| DF | 30 | 0.97 | 97 |
| ES | 23 | 0.74 | 97.74 |
| BA | 19 | 0.61 | 98.35 |

**Interpretation:** 60% of sellers are in SP and 90.6% in five southern/south-eastern states. Supply is far more concentrated than demand — the root of the long cross-state deliveries in M7 and M9.

### U9 — Credit-card instalments
**Business question:** how many instalments do card payers use? **Purpose:** instalment offer design.

```sql
SELECT CASE WHEN payment_installments = 1 THEN '01: 1x'
            WHEN payment_installments <= 3 THEN '02: 2-3x'
            WHEN payment_installments <= 6 THEN '03: 4-6x'
            WHEN payment_installments <= 10 THEN '04: 7-10x'
            ELSE '05: 11-24x' END                          AS installment_band,
       COUNT(*) AS credit_card_payments,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2)    AS pct,
       ROUND(AVG(payment_value), 2)                        AS avg_payment_value
FROM order_payments WHERE payment_type = 'credit_card'
GROUP BY installment_band ORDER BY installment_band;
```

| installment_band | credit_card_payments | pct | avg_payment_value |
|---|---|---|---|
| 01: 1x | 25,457 | 33.15 | 95.87 |
| 02: 2-3x | 22,874 | 29.79 | 134.23 |
| 03: 4-6x | 16,257 | 21.17 | 181.32 |
| 04: 7-10x | 11,866 | 15.45 | 333.83 |
| 05: 11-24x | 341 | 0.44 | 358.34 |

**Interpretation:** two-thirds of card payments use instalments, and value rises steeply with instalment count (R$96 at 1x vs R$334 at 7–10x).

### U10 — Delivery duration
**Business question:** how long do customers wait? **Purpose:** service-level setting.

```sql
SELECT CASE WHEN delivery_days < 3  THEN '01: < 3 days'
            WHEN delivery_days < 7  THEN '02: 3-6 days'
            WHEN delivery_days < 14 THEN '03: 7-13 days'
            WHEN delivery_days < 21 THEN '04: 14-20 days'
            WHEN delivery_days < 30 THEN '05: 21-29 days'
            WHEN delivery_days < 60 THEN '06: 30-59 days'
            ELSE '07: 60+ days' END                         AS delivery_band,
       COUNT(*) AS orders,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2)     AS pct,
       ROUND(100 * SUM(COUNT(*)) OVER (ORDER BY MIN(delivery_days)) / SUM(COUNT(*)) OVER (), 2) AS cumulative_pct
FROM fact_order
WHERE order_status = 'delivered' AND delivery_days IS NOT NULL
GROUP BY delivery_band ORDER BY delivery_band;
```

| delivery_band | orders | pct | cumulative_pct |
|---|---|---|---|
| 01: < 3 days | 4,736 | 4.91 | 4.91 |
| 02: 3-6 days | 21,272 | 22.05 | 26.96 |
| 03: 7-13 days | 40,225 | 41.7 | 68.66 |
| 04: 14-20 days | 17,732 | 18.38 | 87.04 |
| 05: 21-29 days | 7,952 | 8.24 | 95.28 |
| 06: 30-59 days | 4,246 | 4.4 | 99.68 |
| 07: 60+ days | 307 | 0.32 | 100 |

**Interpretation:** only 27% of orders arrive within a week; 13% take three weeks or more.

---

## 12. Ten bivariate analyses

### B1 — Product category × revenue
**Business question:** which categories make the money? **Purpose:** category investment priorities.

```sql
SELECT category,
       ROUND(SUM(price), 0)                                         AS revenue,
       ROUND(100 * SUM(price) / SUM(SUM(price)) OVER (), 2)         AS pct_revenue,
       ROUND(100 * SUM(SUM(price)) OVER (ORDER BY SUM(price) DESC) / SUM(SUM(price)) OVER (), 2) AS cumulative_pct,
       COUNT(DISTINCT order_id)                                     AS orders
FROM v_item_detail WHERE order_status = 'delivered'
GROUP BY category ORDER BY revenue DESC LIMIT 15;
```

| category | revenue | pct_revenue | cumulative_pct | orders |
|---|---|---|---|---|
| health_beauty | 1,233,132 | 9.33 | 9.33 | 8,647 |
| watches_gifts | 1,166,177 | 8.82 | 18.15 | 5,495 |
| bed_bath_table | 1,023,435 | 7.74 | 25.89 | 9,272 |
| sports_leisure | 954,853 | 7.22 | 33.11 | 7,530 |
| computers_accessories | 888,725 | 6.72 | 39.83 | 6,530 |
| furniture_decor | 711,928 | 5.38 | 45.22 | 6,307 |
| housewares | 615,629 | 4.66 | 49.87 | 5,743 |
| cool_stuff | 610,204 | 4.62 | 54.49 | 3,559 |
| auto | 578,967 | 4.38 | 58.87 | 3,810 |
| toys | 471,286 | 3.56 | 62.43 | 3,804 |
| garden_tools | 470,495 | 3.56 | 65.99 | 3,448 |
| baby | 400,422 | 3.03 | 69.02 | 2,809 |
| perfumery | 390,145 | 2.95 | 71.97 | 3,086 |
| telephony | 309,860 | 2.34 | 74.31 | 4,093 |
| office_furniture | 268,154 | 2.03 | 76.34 | 1,254 |

**Interpretation:** health_beauty (9.3%) and watches_gifts (8.8%) lead revenue; watches_gifts ranks 7th in units but 2nd in revenue because of a high average price (B10). **Recommendation:** protect these two categories with seller-quality programmes and featured placement.

### B2 — Customer state × revenue
**Business question:** which states generate revenue, and how valuable is each customer? **Purpose:** regional targeting.

```sql
SELECT customer_state,
       ROUND(SUM(item_revenue), 0)                                    AS revenue,
       ROUND(100 * SUM(item_revenue) / SUM(SUM(item_revenue)) OVER (), 2) AS pct_revenue,
       COUNT(*)                                                       AS orders,
       COUNT(DISTINCT customer_unique_id)                             AS unique_customers,
       ROUND(SUM(item_revenue) / COUNT(DISTINCT customer_unique_id), 2) AS revenue_per_customer
FROM fact_order WHERE order_status = 'delivered'
GROUP BY customer_state ORDER BY revenue DESC LIMIT 12;
```

| customer_state | revenue | pct_revenue | orders | unique_customers | revenue_per_customer |
|---|---|---|---|---|---|
| SP | 5,067,633 | 38.33 | 40,501 | 39,156 | 129.42 |
| RJ | 1,759,651 | 13.31 | 12,350 | 11,917 | 147.66 |
| MG | 1,552,482 | 11.74 | 11,354 | 11,001 | 141.12 |
| RS | 728,897 | 5.51 | 5,345 | 5,168 | 141.04 |
| PR | 666,064 | 5.04 | 4,923 | 4,769 | 139.67 |
| SC | 507,012 | 3.83 | 3,546 | 3,449 | 147 |
| BA | 493,584 | 3.73 | 3,256 | 3,158 | 156.3 |
| DF | 296,498 | 2.24 | 2,080 | 2,019 | 146.85 |
| GO | 282,837 | 2.14 | 1,957 | 1,895 | 149.25 |
| ES | 268,643 | 2.03 | 1,995 | 1,928 | 139.34 |
| PE | 251,889 | 1.91 | 1,593 | 1,551 | 162.4 |
| CE | 219,757 | 1.66 | 1,279 | 1,258 | 174.69 |

**Interpretation:** SP is 38% of revenue but has the **lowest** revenue per customer of the top 12 states (R$129); north-eastern customers (CE R$175, PE R$162, BA R$156) spend more per head.

### B3 — Seller × revenue
**Business question:** who are the biggest sellers? **Purpose:** key-account management.

```sql
SELECT seller_id, seller_state,
       ROUND(SUM(price), 0)                                    AS revenue,
       ROUND(100 * SUM(price) / SUM(SUM(price)) OVER (), 2)    AS pct_marketplace_revenue,
       COUNT(DISTINCT order_id)                                AS orders,
       RANK() OVER (ORDER BY SUM(price) DESC)                  AS revenue_rank
FROM v_item_detail WHERE order_status = 'delivered'
GROUP BY seller_id, seller_state
ORDER BY revenue DESC LIMIT 10;
```

| seller_id | seller_state | revenue | pct_marketplace_revenue | orders | revenue_rank |
|---|---|---|---|---|---|
| 4869f7a5dfa277a7dca6462dcf3b52b2 | SP | 226,988 | 1.72 | 1,124 | 1 |
| 53243585a1d6dc2643021fd1853d8905 | BA | 217,940 | 1.65 | 348 | 2 |
| 4a3ca9315b744ce9f8e9374361493884 | SP | 196,882 | 1.49 | 1,772 | 3 |
| fa1c13f2614d7b5c4749cbc52fecda94 | SP | 190,917 | 1.44 | 578 | 4 |
| 7c67e1448b00f6e969d365cea6b010ab | SP | 186,570 | 1.41 | 973 | 5 |
| 7e93a43ef30c4f03f38b393420bc753a | SP | 165,981 | 1.26 | 319 | 6 |
| da8622b14eb17ae2831f4ac5b9dab84a | SP | 159,817 | 1.21 | 1,311 | 7 |
| 7a67c85e85bb2ce8582c35f2203ad736 | SP | 139,659 | 1.06 | 1,145 | 8 |
| 1025f0e2d44d7041d6cf58b6550e0bfa | SP | 138,209 | 1.05 | 910 | 9 |
| 955fee9216a65b617aa5c0531780ce60 | SP | 131,837 | 1 | 1,261 | 10 |

**Interpretation:** no single seller exceeds 1.8% of revenue — low single-seller risk — but the top 10 together contribute about 13%. Revenue does not equal order volume: seller #2 (BA) earns R$218k from only 348 orders.

### B4 — Product category × review score
**Business question:** which categories disappoint customers? **Purpose:** quality interventions. Grain is (order, category) so multi-item orders are not over-weighted.

```sql
WITH order_cat AS (
  SELECT DISTINCT i.order_id, i.category
  FROM v_item_detail i WHERE i.order_status = 'delivered'
)
SELECT oc.category,
       COUNT(*)                                 AS reviewed_orders,
       ROUND(AVG(f.review_score), 3)            AS avg_review,
       ROUND(100 * AVG(f.review_score <= 2), 2) AS pct_negative_1_2
FROM order_cat oc JOIN fact_order f USING (order_id)
WHERE f.review_score IS NOT NULL
GROUP BY oc.category
HAVING COUNT(*) >= 1000
ORDER BY avg_review ASC;
```

| category | reviewed_orders | avg_review | pct_negative_1_2 |
|---|---|---|---|
| office_furniture | 1,244 | 3.645 | 21.95 |
| bed_bath_table | 9,177 | 3.999 | 16.03 |
| uncategorized | 1,382 | 4.011 | 17.44 |
| telephony | 4,069 | 4.052 | 14.13 |
| furniture_decor | 6,260 | 4.058 | 15.35 |
| computers_accessories | 6,499 | 4.081 | 14.56 |
| baby | 2,787 | 4.103 | 14.28 |
| watches_gifts | 5,454 | 4.121 | 13.7 |
| electronics | 2,498 | 4.124 | 13.21 |
| auto | 3,792 | 4.145 | 13 |
| consoles_games | 1,009 | 4.178 | 11.1 |
| garden_tools | 3,428 | 4.18 | 12.25 |
| housewares | 5,709 | 4.193 | 11.82 |
| cool_stuff | 3,531 | 4.218 | 11.27 |
| sports_leisure | 7,486 | 4.227 | 11.38 |
| health_beauty | 8,601 | 4.229 | 11.45 |
| toys | 3,774 | 4.238 | 11.39 |
| fashion_bags_accessories | 1,811 | 4.242 | 10.16 |
| perfumery | 3,076 | 4.261 | 11.77 |
| pet_shop | 1,680 | 4.274 | 10.65 |
| stationery | 2,251 | 4.295 | 10.04 |
| luggage_accessories | 1,015 | 4.37 | 8.18 |

**Interpretation:** office_furniture is the clear outlier (3.65, 22% negative), followed by bed_bath_table (4.00) — the #3 revenue category. **Recommendation:** audit office_furniture sellers and delivery (heavy, high freight — see B7/M10) and bed_bath_table product-description accuracy.

### B5 — Delivery delay × review score
**Business question:** how does delivery timing relate to satisfaction? **Purpose:** quantify the value of reliability.

```sql
SELECT CASE WHEN delay_days <= -15 THEN '01: 15+ days early'
            WHEN delay_days <= -8  THEN '02: 8-14 days early'
            WHEN delay_days <= -1  THEN '03: 1-7 days early'
            WHEN delay_days =  0   THEN '04: on estimated day'
            WHEN delay_days <=  3  THEN '05: 1-3 days late'
            WHEN delay_days <=  7  THEN '06: 4-7 days late'
            WHEN delay_days <= 14  THEN '07: 8-14 days late'
            ELSE                        '08: 15+ days late' END AS delay_band,
       COUNT(*)                                   AS orders,
       ROUND(AVG(review_score), 3)                AS avg_review,
       ROUND(100 * AVG(review_score = 1), 2)      AS pct_1_star,
       ROUND(100 * AVG(review_score = 5), 2)      AS pct_5_star
FROM fact_order
WHERE order_status = 'delivered' AND delay_days IS NOT NULL AND review_score IS NOT NULL
GROUP BY delay_band ORDER BY delay_band;
```

| delay_band | orders | avg_review | pct_1_star | pct_5_star |
|---|---|---|---|---|
| 01: 15+ days early | 34,771 | 4.323 | 6.54 | 64.28 |
| 02: 8-14 days early | 36,158 | 4.311 | 6.41 | 63.02 |
| 03: 1-7 days early | 17,234 | 4.201 | 7.07 | 57.49 |
| 04: on estimated day | 1,280 | 4.034 | 8.52 | 50.63 |
| 05: 1-3 days late | 1,852 | 3.291 | 25.11 | 33.15 |
| 06: 4-7 days late | 1,748 | 2.103 | 58.58 | 14.07 |
| 07: 8-14 days late | 1,446 | 1.671 | 70.61 | 6.85 |
| 08: 15+ days late | 1,335 | 1.724 | 68.99 | 7.19 |

**Interpretation:** reviews are stable at 4.2–4.3 for early deliveries, fall sharply from the first late day (3.29 at 1–3 days late) and collapse to ~1.7 with 59–71% one-star once orders are 4+ days late. This is the strongest pattern in the dataset (association, not proven causation — see section 17).

### B6 — Payment type × order value
**Business question:** does payment method relate to basket size? **Purpose:** payment promotion strategy.

```sql
SELECT main_payment_type,
       COUNT(*)                        AS orders,
       ROUND(AVG(payment_value), 2)    AS avg_paid,
       ROUND(AVG(item_revenue), 2)     AS avg_product_value,
       ROUND(SUM(payment_value), 0)    AS total_paid,
       ROUND(100 * AVG(payment_rows > 1), 2) AS pct_split_payments
FROM fact_order WHERE order_status = 'delivered' AND main_payment_type IS NOT NULL
GROUP BY main_payment_type ORDER BY orders DESC;
```

| main_payment_type | orders | avg_paid | avg_product_value | total_paid | pct_split_payments |
|---|---|---|---|---|---|
| credit_card | 72,825 | 166.18 | 143.24 | 12,102,206 | 1.35 |
| boleto | 19,191 | 144.33 | 121.4 | 2,769,933 | 0 |
| voucher | 2,977 | 114.86 | 94.8 | 341,952 | 63.55 |
| debit_card | 1,484 | 140.41 | 119.86 | 208,371 | 0.07 |

**Interpretation:** credit-card orders are ~18% larger than boleto orders in product value (R$143 vs R$121); 64% of voucher orders are split with another method.

### B7 — Freight × product category
**Business question:** where is freight disproportionate to product value? **Purpose:** freight subsidy and pricing.

```sql
SELECT category,
       COUNT(*)                                       AS items,
       ROUND(AVG(price), 2)                           AS avg_price,
       ROUND(AVG(freight_value), 2)                   AS avg_freight,
       ROUND(100 * SUM(freight_value) / SUM(price), 1) AS freight_pct_of_price,
       ROUND(AVG(product_weight_g) / 1000, 2)         AS avg_weight_kg
FROM v_item_detail WHERE order_status = 'delivered'
GROUP BY category HAVING COUNT(*) >= 1000
ORDER BY freight_pct_of_price DESC;
```

| category | items | avg_price | avg_freight | freight_pct_of_price | avg_weight_kg |
|---|---|---|---|---|---|
| electronics | 2,729 | 56.81 | 16.74 | 29.5 | 0.77 |
| office_furniture | 1,668 | 160.76 | 40.2 | 25 | 11.34 |
| furniture_decor | 8,160 | 87.25 | 20.64 | 23.7 | 2.64 |
| housewares | 6,795 | 90.6 | 21.01 | 23.2 | 3.22 |
| telephony | 4,430 | 69.95 | 15.65 | 22.4 | 0.26 |
| luggage_accessories | 1,077 | 128.79 | 27.93 | 21.7 | 5.8 |
| stationery | 2,466 | 90.75 | 18.57 | 20.5 | 2.74 |
| fashion_bags_accessories | 1,985 | 75.23 | 15.39 | 20.5 | 0.38 |
| garden_tools | 4,268 | 110.24 | 22.65 | 20.5 | 2.81 |
| bed_bath_table | 10,953 | 93.44 | 18.42 | 19.7 | 2.12 |
| pet_shop | 1,924 | 110.03 | 20.23 | 18.4 | 2.91 |
| sports_leisure | 8,431 | 113.25 | 19.38 | 17.1 | 1.71 |
| baby | 2,982 | 134.28 | 22.24 | 16.6 | 3.26 |
| computers_accessories | 7,644 | 116.26 | 18.84 | 16.2 | 0.9 |
| toys | 4,030 | 116.94 | 18.8 | 16.1 | 1.85 |
| uncategorized | 1,537 | 111.08 | 17.55 | 15.8 | 1.66 |
| auto | 4,140 | 139.85 | 21.86 | 15.6 | 2.6 |
| health_beauty | 9,465 | 130.28 | 18.91 | 14.5 | 1.05 |
| perfumery | 3,340 | 116.81 | 15.88 | 13.6 | 0.48 |
| cool_stuff | 3,718 | 164.12 | 21.91 | 13.4 | 2.54 |
| consoles_games | 1,089 | 135.91 | 17.53 | 12.9 | 0.45 |
| watches_gifts | 5,859 | 199.04 | 16.75 | 8.4 | 0.58 |

**Interpretation:** electronics pays 29.5% of the price in freight (cheap, light items), office_furniture 25% (heavy items); watches_gifts only 8.4%. **Recommendation:** target freight subsidies or minimum-basket offers at low-price, high-freight-ratio categories.

### B8 — Seller state × sales
**Business question:** where is revenue shipped from? **Purpose:** supply-side regional strategy.

```sql
SELECT seller_state,
       COUNT(DISTINCT seller_id)                              AS active_sellers,
       ROUND(SUM(price), 0)                                   AS revenue,
       ROUND(100 * SUM(price) / SUM(SUM(price)) OVER (), 2)   AS pct_revenue,
       ROUND(SUM(price) / COUNT(DISTINCT seller_id), 0)       AS revenue_per_seller
FROM v_item_detail WHERE order_status = 'delivered'
GROUP BY seller_state ORDER BY revenue DESC LIMIT 10;
```

| seller_state | active_sellers | revenue | pct_revenue | revenue_per_seller |
|---|---|---|---|---|
| SP | 1,769 | 8,509,511 | 64.36 | 4,810 |
| PR | 335 | 1,232,097 | 9.32 | 3,678 |
| MG | 236 | 977,866 | 7.4 | 4,144 |
| RJ | 163 | 820,612 | 6.21 | 5,034 |
| SC | 184 | 613,592 | 4.64 | 3,335 |
| RS | 125 | 373,412 | 2.82 | 2,987 |
| BA | 18 | 277,926 | 2.1 | 15,440 |
| DF | 30 | 94,840 | 0.72 | 3,161 |
| PE | 9 | 91,164 | 0.69 | 10,129 |
| GO | 39 | 64,807 | 0.49 | 1,662 |

**Interpretation:** SP sellers ship 64% of revenue. BA and PE have few sellers but very high revenue per seller (R$15.4k and R$10.1k) — a sign that capable sellers exist outside the South-East.

### B9 — Customer state × average order value
**Business question:** do order values differ by state? **Purpose:** regional assortment and freight policy.

```sql
SELECT customer_state,
       COUNT(*)                         AS orders,
       ROUND(AVG(item_revenue), 2)      AS aov,
       ROUND(AVG(freight), 2)           AS avg_freight,
       ROUND(100 * SUM(freight) / SUM(item_revenue), 1) AS freight_pct
FROM fact_order WHERE order_status = 'delivered'
GROUP BY customer_state HAVING COUNT(*) >= 500
ORDER BY aov DESC;
```

| customer_state | orders | aov | avg_freight | freight_pct |
|---|---|---|---|---|
| PB | 517 | 217.77 | 48.84 | 22.4 |
| PA | 946 | 184.43 | 39.7 | 21.5 |
| CE | 1,279 | 171.82 | 36.5 | 21.2 |
| MT | 886 | 171.77 | 32.77 | 19.1 |
| MS | 701 | 164.66 | 27.02 | 16.4 |
| MA | 717 | 163.19 | 42.95 | 26.3 |
| PE | 1,593 | 158.12 | 35.83 | 22.7 |
| BA | 3,256 | 151.59 | 29.96 | 19.8 |
| GO | 1,957 | 144.53 | 26.25 | 18.2 |
| SC | 3,546 | 142.98 | 24.85 | 17.4 |
| DF | 2,080 | 142.55 | 23.86 | 16.7 |
| RJ | 12,350 | 142.48 | 23.95 | 16.8 |
| MG | 11,354 | 136.73 | 23.46 | 17.2 |
| RS | 5,345 | 136.37 | 24.8 | 18.2 |
| PR | 4,923 | 135.3 | 23.49 | 17.4 |
| ES | 1,995 | 134.66 | 24.57 | 18.2 |
| SP | 40,501 | 125.12 | 17.33 | 13.9 |

**Interpretation:** AOV rises with distance from SP (PB R$218 vs SP R$125), as does the freight burden (MA 26.3% vs SP 13.9%). High freight plausibly suppresses small orders in remote states, leaving larger baskets.

### B10 — Product category × units sold
**Business question:** are high-volume categories also high-value? **Purpose:** distinguish traffic drivers from revenue drivers.

```sql
SELECT category,
       COUNT(*)                                 AS units_sold,
       DENSE_RANK() OVER (ORDER BY COUNT(*) DESC)  AS units_rank,
       ROUND(SUM(price), 0)                     AS revenue,
       DENSE_RANK() OVER (ORDER BY SUM(price) DESC) AS revenue_rank,
       ROUND(AVG(price), 2)                     AS avg_unit_price,
       COUNT(DISTINCT product_id)               AS distinct_products
FROM v_item_detail WHERE order_status = 'delivered'
GROUP BY category ORDER BY units_sold DESC LIMIT 15;
```

| category | units_sold | units_rank | revenue | revenue_rank | avg_unit_price | distinct_products |
|---|---|---|---|---|---|---|
| bed_bath_table | 10,953 | 1 | 1,023,435 | 3 | 93.44 | 2,991 |
| health_beauty | 9,465 | 2 | 1,233,132 | 1 | 130.28 | 2,397 |
| sports_leisure | 8,431 | 3 | 954,853 | 4 | 113.25 | 2,822 |
| furniture_decor | 8,160 | 4 | 711,928 | 6 | 87.25 | 2,593 |
| computers_accessories | 7,644 | 5 | 888,725 | 5 | 116.26 | 1,600 |
| housewares | 6,795 | 6 | 615,629 | 7 | 90.6 | 2,282 |
| watches_gifts | 5,859 | 7 | 1,166,177 | 2 | 199.04 | 1,300 |
| telephony | 4,430 | 8 | 309,860 | 14 | 69.95 | 1,112 |
| garden_tools | 4,268 | 9 | 470,495 | 11 | 110.24 | 725 |
| auto | 4,140 | 10 | 578,967 | 9 | 139.85 | 1,853 |
| toys | 4,030 | 11 | 471,286 | 10 | 116.94 | 1,373 |
| cool_stuff | 3,718 | 12 | 610,204 | 8 | 164.12 | 770 |
| perfumery | 3,340 | 13 | 390,145 | 13 | 116.81 | 857 |
| baby | 2,982 | 14 | 400,422 | 12 | 134.28 | 890 |
| electronics | 2,729 | 15 | 155,044 | 22 | 56.81 | 507 |

**Interpretation:** volume and value diverge: telephony is 8th in units but 14th in revenue (R$70 avg price); electronics is 15th in units but 22nd in revenue. bed_bath_table and furniture_decor are traffic drivers; watches_gifts and cool_stuff are value drivers.

---

## 13. Ten multivariate analyses

### M1 — Category × customer state × revenue
**Business question:** what are the top two categories in each major state? **Purpose:** regionalised merchandising. Uses `RANK() OVER (PARTITION BY state)`.

```sql
WITH state_cat AS (
  SELECT customer_state, category, SUM(price) AS revenue
  FROM v_item_detail WHERE order_status = 'delivered'
  GROUP BY customer_state, category
),
ranked AS (
  SELECT sc.*,
         RANK() OVER (PARTITION BY customer_state ORDER BY revenue DESC) AS rnk,
         100 * revenue / SUM(revenue) OVER (PARTITION BY customer_state) AS pct_of_state
  FROM state_cat sc
),
big_states AS (
  SELECT customer_state FROM state_cat GROUP BY customer_state
  ORDER BY SUM(revenue) DESC LIMIT 8
)
SELECT r.customer_state, r.rnk, r.category, ROUND(r.revenue, 0) AS revenue, ROUND(r.pct_of_state, 2) AS pct_of_state
FROM ranked r JOIN big_states b USING (customer_state)
WHERE r.rnk <= 2
ORDER BY (SELECT SUM(revenue) FROM state_cat s WHERE s.customer_state = r.customer_state) DESC, r.rnk;
```

| customer_state | rnk | category | revenue | pct_of_state |
|---|---|---|---|---|
| SP | 1 | bed_bath_table | 472,238 | 9.32 |
| SP | 2 | health_beauty | 453,916 | 8.96 |
| RJ | 1 | watches_gifts | 174,895 | 9.94 |
| RJ | 2 | bed_bath_table | 144,252 | 8.2 |
| MG | 1 | health_beauty | 154,324 | 9.94 |
| MG | 2 | bed_bath_table | 128,760 | 8.29 |
| RS | 1 | bed_bath_table | 60,041 | 8.24 |
| RS | 2 | furniture_decor | 53,775 | 7.38 |
| PR | 1 | sports_leisure | 57,653 | 8.66 |
| PR | 2 | watches_gifts | 57,287 | 8.6 |
| SC | 1 | sports_leisure | 41,579 | 8.2 |
| SC | 2 | health_beauty | 39,261 | 7.74 |
| BA | 1 | health_beauty | 49,955 | 10.12 |
| BA | 2 | watches_gifts | 45,632 | 9.24 |
| DF | 1 | watches_gifts | 32,292 | 10.89 |
| DF | 2 | health_beauty | 29,543 | 9.96 |

**Interpretation:** category leadership differs by region: bed_bath_table leads SP and RS, watches_gifts leads RJ and DF, health_beauty leads MG and BA, sports_leisure leads PR and SC. **Recommendation:** tailor home-page and campaign categories by state.

### M2 — Seller × category × revenue
**Business question:** are top sellers specialists or generalists? **Purpose:** seller-development strategy.

```sql
WITH seller_cat AS (
  SELECT seller_id, category, SUM(price) AS revenue
  FROM v_item_detail WHERE order_status = 'delivered'
  GROUP BY seller_id, category
),
seller_tot AS (
  SELECT seller_id, SUM(revenue) AS seller_revenue, COUNT(*) AS categories,
         RANK() OVER (ORDER BY SUM(revenue) DESC) AS seller_rank
  FROM seller_cat GROUP BY seller_id
),
main_cat AS (
  SELECT seller_id, category, revenue,
         ROW_NUMBER() OVER (PARTITION BY seller_id ORDER BY revenue DESC) AS rn
  FROM seller_cat
)
SELECT t.seller_rank, LEFT(t.seller_id, 8) AS seller, ROUND(t.seller_revenue, 0) AS seller_revenue,
       t.categories, m.category AS main_category,
       ROUND(100 * m.revenue / t.seller_revenue, 1) AS main_category_pct
FROM seller_tot t JOIN main_cat m ON m.seller_id = t.seller_id AND m.rn = 1
WHERE t.seller_rank <= 10 ORDER BY t.seller_rank;
```

| seller_rank | seller | seller_revenue | categories | main_category | main_category_pct |
|---|---|---|---|---|---|
| 1 | 4869f7a5 | 226,988 | 10 | watches_gifts | 87.6 |
| 2 | 53243585 | 217,940 | 2 | computers | 74.9 |
| 3 | 4a3ca931 | 196,882 | 7 | bed_bath_table | 82.4 |
| 4 | fa1c13f2 | 190,917 | 5 | watches_gifts | 99 |
| 5 | 7c67e144 | 186,570 | 6 | office_furniture | 92 |
| 6 | 7e93a43e | 165,981 | 7 | watches_gifts | 96.4 |
| 7 | da8622b1 | 159,817 | 4 | bed_bath_table | 95 |
| 8 | 7a67c85e | 139,659 | 2 | cool_stuff | 95.5 |
| 9 | 1025f0e2 | 138,209 | 4 | furniture_decor | 80.1 |
| 10 | 955fee92 | 131,837 | 23 | furniture_decor | 29.1 |

**Interpretation:** 9 of the top 10 sellers earn 75–99% of revenue from one category; only #10 is a generalist (23 categories). Scale on Olist is built through category specialisation.

### M3 — Delivery performance × review × customer state
**Business question:** are regional satisfaction gaps explained by delivery? **Purpose:** prioritise logistics fixes by state.

```sql
SELECT customer_state,
       COUNT(*)                                                    AS orders,
       ROUND(AVG(delivery_days), 1)                                AS avg_delivery_days,
       ROUND(100 * AVG(is_late), 1)                                AS late_pct,
       ROUND(AVG(review_score), 2)                                 AS avg_review_all,
       ROUND(AVG(CASE WHEN is_late = 0 THEN review_score END), 2)  AS avg_review_on_time,
       ROUND(AVG(CASE WHEN is_late = 1 THEN review_score END), 2)  AS avg_review_late
FROM fact_order
WHERE order_status = 'delivered' AND is_late IS NOT NULL
GROUP BY customer_state HAVING COUNT(*) >= 1000
ORDER BY late_pct DESC;
```

| customer_state | orders | avg_delivery_days | late_pct | avg_review_all | avg_review_on_time | avg_review_late |
|---|---|---|---|---|---|---|
| CE | 1,279 | 21.3 | 13.8 | 3.94 | 4.25 | 2.04 |
| BA | 3,256 | 19.3 | 12.2 | 3.93 | 4.14 | 2.35 |
| RJ | 12,350 | 15.3 | 12.1 | 3.97 | 4.24 | 1.91 |
| ES | 1,995 | 15.8 | 10.7 | 4.08 | 4.26 | 2.51 |
| PE | 1,593 | 18.4 | 9.6 | 4.08 | 4.3 | 2.03 |
| SC | 3,546 | 15 | 8.2 | 4.13 | 4.29 | 2.35 |
| GO | 1,957 | 15.6 | 6.5 | 4.11 | 4.24 | 2.2 |
| RS | 5,344 | 15.3 | 6.1 | 4.18 | 4.31 | 2.21 |
| DF | 2,080 | 13 | 5.7 | 4.13 | 4.26 | 1.97 |
| MG | 11,354 | 12 | 4.6 | 4.19 | 4.28 | 2.36 |
| SP | 40,494 | 8.8 | 4.5 | 4.25 | 4.32 | 2.55 |
| PR | 4,923 | 12 | 4 | 4.24 | 4.3 | 2.68 |

**Interpretation:** states with the highest late rates (CE, BA, RJ: 12–14%) have the lowest average reviews (3.93–3.97), while on-time reviews are similar everywhere (4.14–4.32). The regional gap in satisfaction is largely a gap in lateness. RJ stands out: it is close to SP yet 12.1% late. **Recommendation:** investigate carrier performance into RJ as a priority — it is the #2 revenue state.

### M4 — Payment type × instalments × order value
**Business question:** do instalments enable bigger baskets? **Purpose:** instalment policy.

```sql
SELECT main_payment_type,
       CASE WHEN max_installments = 1 THEN '1x'
            WHEN max_installments <= 3 THEN '2-3x'
            WHEN max_installments <= 6 THEN '4-6x'
            ELSE '7x+' END                       AS installment_band,
       COUNT(*)                                  AS orders,
       ROUND(AVG(payment_value), 2)              AS avg_order_paid,
       ROUND(SUM(payment_value), 0)              AS total_paid,
       ROUND(AVG(review_score), 2)               AS avg_review
FROM fact_order
WHERE order_status = 'delivered' AND main_payment_type IN ('credit_card', 'boleto', 'debit_card', 'voucher')
GROUP BY main_payment_type, installment_band
HAVING COUNT(*) >= 100
ORDER BY main_payment_type, installment_band;
```

| main_payment_type | installment_band | orders | avg_order_paid | total_paid | avg_review |
|---|---|---|---|---|---|
| boleto | 1x | 19,191 | 144.33 | 2,769,933 | 4.16 |
| credit_card | 1x | 23,358 | 100.62 | 2,350,193 | 4.22 |
| credit_card | 2-3x | 22,020 | 134.96 | 2,971,882 | 4.15 |
| credit_card | 4-6x | 15,696 | 181.72 | 2,852,287 | 4.13 |
| credit_card | 7x+ | 11,751 | 334.26 | 3,927,844 | 4.08 |
| debit_card | 1x | 1,484 | 140.41 | 208,371 | 4.24 |
| voucher | 1x | 2,783 | 107.5 | 299,169 | 4.12 |
| voucher | 2-3x | 139 | 206.23 | 28,666 | 4.13 |

**Interpretation:** credit-card orders paid in 7+ instalments average R$334 versus R$101 at 1x, and this band is the single largest pool of payment value (R$3.93M). Instalments are central to high-ticket sales.

### M5 — Quarter × category × revenue
**Business question:** which leading categories are growing or stalling? **Purpose:** category momentum. Complete quarters 2017-Q1 to 2018-Q2; categories are the top 5 from B1.

```sql
WITH top5 AS (
  SELECT category FROM v_item_detail WHERE order_status = 'delivered'
  GROUP BY category ORDER BY SUM(price) DESC LIMIT 5
)
SELECT CONCAT(YEAR(order_purchase_timestamp), '-Q', QUARTER(order_purchase_timestamp)) AS yr_qtr,
       ROUND(SUM(CASE WHEN category = 'health_beauty'         THEN price END), 0) AS health_beauty,
       ROUND(SUM(CASE WHEN category = 'watches_gifts'         THEN price END), 0) AS watches_gifts,
       ROUND(SUM(CASE WHEN category = 'bed_bath_table'        THEN price END), 0) AS bed_bath_table,
       ROUND(SUM(CASE WHEN category = 'sports_leisure'        THEN price END), 0) AS sports_leisure,
       ROUND(SUM(CASE WHEN category = 'computers_accessories' THEN price END), 0) AS computers_accessories
FROM v_item_detail
WHERE order_status = 'delivered'
  AND category IN (SELECT category FROM top5)
  AND order_purchase_timestamp >= '2017-01-01' AND order_purchase_timestamp < '2018-07-01'
GROUP BY yr_qtr ORDER BY yr_qtr;
```

| yr_qtr | health_beauty | watches_gifts | bed_bath_table | sports_leisure | computers_accessories |
|---|---|---|---|---|---|
| 2017-Q1 | 60,079 | 43,971 | 44,497 | 50,315 | 43,322 |
| 2017-Q2 | 100,173 | 87,293 | 90,581 | 89,166 | 99,307 |
| 2017-Q3 | 133,919 | 114,622 | 171,473 | 126,216 | 100,043 |
| 2017-Q4 | 179,662 | 229,724 | 184,046 | 169,978 | 149,114 |
| 2018-Q1 | 240,471 | 229,908 | 203,561 | 242,371 | 265,344 |
| 2018-Q2 | 292,339 | 293,016 | 213,502 | 169,919 | 149,809 |

**Interpretation:** health_beauty and watches_gifts kept growing into 2018-Q2 (+22% and +27% vs Q1), while computers_accessories fell 44% and sports_leisure 30% from Q1 to Q2 2018. **Recommendation:** investigate the Q2-2018 drop in these two categories (seller churn, stock, pricing).

### M6 — Seller × revenue × review × delivery performance
**Business question:** how is revenue distributed across seller quality tiers? **Purpose:** seller-management programme. Sellers with ≥30 delivered orders; seller-order grain to avoid item over-counting.

```sql
WITH seller_order AS (            -- seller-order grain: avoids counting an order once per item
  SELECT i.seller_id, i.order_id, SUM(i.price) AS revenue,
         MAX(i.order_delivered_carrier_date > i.shipping_limit_date) AS shipped_late
  FROM v_item_detail i WHERE i.order_status = 'delivered'
  GROUP BY i.seller_id, i.order_id
),
seller_perf AS (
  SELECT so.seller_id,
         COUNT(*)                   AS orders,
         SUM(so.revenue)            AS revenue,
         AVG(f.review_score)        AS avg_review,
         AVG(f.is_late)             AS late_rate,
         AVG(so.shipped_late)       AS handover_late_rate
  FROM seller_order so JOIN fact_order f USING (order_id)
  GROUP BY so.seller_id HAVING COUNT(*) >= 30
)
SELECT CASE WHEN avg_review >= 4.2 AND late_rate <= 0.06 THEN '1: Stars (review>=4.2, late<=6%)'
            WHEN avg_review >= 4.0                         THEN '2: Solid (review 4.0-4.2 or late>6%)'
            WHEN avg_review >= 3.5                         THEN '3: At risk (review 3.5-4.0)'
            ELSE                                                '4: Problem (review<3.5)' END AS segment,
       COUNT(*)                              AS sellers,
       ROUND(SUM(revenue), 0)                AS revenue,
       ROUND(100 * SUM(revenue) / SUM(SUM(revenue)) OVER (), 1) AS pct_revenue,
       ROUND(AVG(avg_review), 2)             AS avg_review,
       ROUND(100 * AVG(late_rate), 1)        AS avg_late_pct,
       ROUND(100 * AVG(handover_late_rate), 1) AS avg_carrier_handover_late_pct
FROM seller_perf GROUP BY segment ORDER BY segment;
```

| segment | sellers | revenue | pct_revenue | avg_review | avg_late_pct | avg_carrier_handover_late_pct |
|---|---|---|---|---|---|---|
| 1: Stars (review>=4.2, late<=6%) | 213 | 2,833,636 | 27.8 | 4.4 | 2.8 | 4.4 |
| 2: Solid (review 4.0-4.2 or late>6%) | 261 | 5,087,319 | 49.9 | 4.19 | 7.5 | 9 |
| 3: At risk (review 3.5-4.0) | 130 | 1,812,686 | 17.8 | 3.85 | 9.1 | 12.7 |
| 4: Problem (review<3.5) | 23 | 465,051 | 4.6 | 3.26 | 15.5 | 34.5 |

**Interpretation:** 23 "problem" sellers miss the carrier hand-over deadline on 34.5% of orders (vs 4.4% for stars) and average 15.5% late deliveries. "At-risk" and "problem" sellers together carry 22.4% of the revenue of established sellers — revenue exposed to poor experience. **Recommendation:** put the 153 at-risk/problem sellers on improvement plans with hand-over SLAs.

### M7 — Region × freight × delivery time × review
**Business question:** do remote customers pay more, wait longer and rate lower? **Purpose:** regional logistics investment.

```sql
SELECT CASE WHEN customer_state IN ('SP') THEN '1: SP'
            WHEN customer_state IN ('RJ','MG','ES') THEN '2: Southeast ex-SP'
            WHEN customer_state IN ('PR','SC','RS') THEN '3: South'
            WHEN customer_state IN ('DF','GO','MT','MS') THEN '4: Centre-West'
            WHEN customer_state IN ('BA','SE','AL','PE','PB','RN','CE','PI','MA') THEN '5: Northeast'
            ELSE '6: North' END                        AS region,
       COUNT(*)                                         AS orders,
       ROUND(AVG(item_revenue), 2)                      AS aov,
       ROUND(100 * SUM(freight) / SUM(item_revenue), 1) AS freight_pct,
       ROUND(AVG(delivery_days), 1)                     AS avg_delivery_days,
       ROUND(100 * AVG(is_late), 1)                     AS late_pct,
       ROUND(AVG(review_score), 2)                      AS avg_review
FROM fact_order
WHERE order_status = 'delivered' AND delivery_days IS NOT NULL
GROUP BY region ORDER BY region;
```

| region | orders | aov | freight_pct | avg_delivery_days | late_pct | avg_review |
|---|---|---|---|---|---|---|
| 1: SP | 40,494 | 125.12 | 13.9 | 8.8 | 4.5 | 4.25 |
| 2: Southeast ex-SP | 25,699 | 139.34 | 17.1 | 13.9 | 8.7 | 4.07 |
| 3: South | 13,813 | 137.68 | 17.7 | 14 | 5.9 | 4.19 |
| 4: Centre-West | 5,624 | 150.6 | 17.6 | 15 | 6.5 | 4.13 |
| 5: Northeast | 9,044 | 165.53 | 21.7 | 20 | 12.7 | 3.97 |
| 6: North | 1,796 | 182.11 | 22.7 | 22.6 | 8.6 | 4.03 |

**Interpretation:** a clear gradient: SP customers wait 8.8 days and pay 13.9% freight; Northeast customers wait 20.0 days, pay 21.7% and are late 12.7% of the time, with the lowest review (3.97). Yet remote regions have the highest AOV. **Recommendation:** remote regions are valuable but under-served — target them with regional fulfilment and freight offers.

### M8 — Day of week × time of day × orders × revenue
**Business question:** when do customers buy? **Purpose:** campaign and customer-service timing.

```sql
SELECT DAYOFWEEK(order_purchase_timestamp)                       AS dow_num,
       DAYNAME(order_purchase_timestamp)                         AS weekday,
       SUM(HOUR(order_purchase_timestamp) BETWEEN 0 AND 5)       AS h00_05,
       SUM(HOUR(order_purchase_timestamp) BETWEEN 6 AND 11)      AS h06_11,
       SUM(HOUR(order_purchase_timestamp) BETWEEN 12 AND 17)     AS h12_17,
       SUM(HOUR(order_purchase_timestamp) BETWEEN 18 AND 23)     AS h18_23,
       COUNT(*)                                                  AS orders,
       ROUND(SUM(item_revenue), 0)                               AS revenue,
       ROUND(AVG(item_revenue), 2)                               AS aov
FROM fact_order WHERE order_status = 'delivered'
GROUP BY dow_num, weekday ORDER BY dow_num;
```

| dow_num | weekday | h00_05 | h06_11 | h12_17 | h18_23 | orders | revenue | aov |
|---|---|---|---|---|---|---|---|---|
| 1 | Sunday | 555 | 1,893 | 4,175 | 5,012 | 11,635 | 1,545,648 | 132.84 |
| 2 | Monday | 587 | 3,495 | 6,068 | 5,551 | 15,701 | 2,168,906 | 138.14 |
| 3 | Tuesday | 610 | 3,603 | 5,987 | 5,303 | 15,503 | 2,122,265 | 136.89 |
| 4 | Wednesday | 725 | 3,631 | 5,817 | 4,903 | 15,076 | 2,051,534 | 136.08 |
| 5 | Thursday | 680 | 3,408 | 5,668 | 4,567 | 14,323 | 1,958,600 | 136.75 |
| 6 | Friday | 808 | 3,423 | 5,415 | 4,039 | 13,685 | 1,910,496 | 139.61 |
| 7 | Saturday | 629 | 2,141 | 4,053 | 3,732 | 10,555 | 1,464,050 | 138.71 |

**Interpretation:** Monday and Tuesday are the busiest days, Saturday the quietest. Afternoons (12–17h) dominate on weekdays, but on Sunday the evening (18–23h) is the peak. **Recommendation:** schedule campaigns for Sunday evening and Monday, and staff service desks early in the week.

### M9 — Seller–customer geography × delivery × lateness × review
**Business question:** what does cross-state shipping cost in speed and satisfaction? **Purpose:** quantify the case for regional fulfilment. Single-seller orders only.

```sql
WITH single_seller AS (
  SELECT order_id, MIN(seller_state) AS seller_state
  FROM v_item_detail WHERE order_status = 'delivered'
  GROUP BY order_id HAVING COUNT(DISTINCT seller_id) = 1
)
SELECT CASE WHEN s.seller_state = f.customer_state THEN 'same state' ELSE 'cross-state' END AS route,
       CASE WHEN s.seller_state = 'SP' THEN 'seller in SP' ELSE 'seller outside SP' END   AS origin,
       COUNT(*)                                       AS orders,
       ROUND(AVG(f.delivery_days), 1)                 AS avg_delivery_days,
       ROUND(AVG(f.freight), 2)                       AS avg_freight,
       ROUND(100 * AVG(f.is_late), 1)                 AS late_pct,
       ROUND(AVG(f.review_score), 2)                  AS avg_review
FROM single_seller s JOIN fact_order f USING (order_id)
WHERE f.delivery_days IS NOT NULL
GROUP BY route, origin ORDER BY route DESC, origin;
```

| route | origin | orders | avg_delivery_days | avg_freight | late_pct | avg_review |
|---|---|---|---|---|---|---|
| same state | seller in SP | 30,313 | 8 | 14.94 | 4.7 | 4.26 |
| same state | seller outside SP | 3,921 | 8 | 17.07 | 3.4 | 4.41 |
| cross-state | seller in SP | 37,182 | 16 | 25.63 | 9.6 | 4.05 |
| cross-state | seller outside SP | 23,779 | 13.9 | 28 | 5.8 | 4.21 |

**Interpretation:** same-state orders arrive in 8 days; cross-state orders from SP take 16 days, cost 72% more freight (R$25.63 vs R$14.94), are twice as likely to be late (9.6% vs 4.7%) and are rated lower (4.05 vs 4.26). 64% of these orders are cross-state.

### M10 — Product weight × freight × delivery × review
**Business question:** are heavy items a logistics and satisfaction problem? **Purpose:** category logistics policy.

```sql
WITH line AS (
  SELECT i.order_id, i.price, i.freight_value, i.product_weight_g,
         CASE WHEN i.product_weight_g IS NULL  THEN '0: unknown'
              WHEN i.product_weight_g < 500    THEN '1: < 0.5 kg'
              WHEN i.product_weight_g < 2000   THEN '2: 0.5-2 kg'
              WHEN i.product_weight_g < 5000   THEN '3: 2-5 kg'
              WHEN i.product_weight_g < 15000  THEN '4: 5-15 kg'
              ELSE '5: 15 kg+' END AS weight_band
  FROM v_item_detail i WHERE i.order_status = 'delivered'
)
SELECT l.weight_band,
       COUNT(*)                                           AS items,
       ROUND(AVG(l.price), 2)                             AS avg_price,
       ROUND(AVG(l.freight_value), 2)                     AS avg_freight,
       ROUND(100 * SUM(l.freight_value) / SUM(l.price), 1) AS freight_pct_of_price,
       ROUND(AVG(f.delivery_days), 1)                     AS avg_delivery_days,
       ROUND(100 * AVG(f.is_late), 1)                     AS late_pct,
       ROUND(AVG(f.review_score), 2)                      AS avg_review
FROM line l JOIN fact_order f USING (order_id)
GROUP BY l.weight_band ORDER BY l.weight_band;
```

| weight_band | items | avg_price | avg_freight | freight_pct_of_price | avg_delivery_days | late_pct | avg_review |
|---|---|---|---|---|---|---|---|
| 0: unknown | 26 | 132.56 | 17.39 | 13.1 | 12.2 | 0 | 4.23 |
| 1: < 0.5 kg | 43,821 | 75.02 | 15.17 | 20.2 | 11.8 | 6.3 | 4.1 |
| 2: 0.5-2 kg | 41,234 | 111.96 | 17.78 | 15.9 | 12.5 | 6.4 | 4.08 |
| 3: 2-5 kg | 11,436 | 178.41 | 22.62 | 12.7 | 12.9 | 7.2 | 4.1 |
| 4: 5-15 kg | 11,388 | 202.42 | 33.65 | 16.6 | 14 | 7.2 | 4.02 |
| 5: 15 kg+ | 2,292 | 422.62 | 68.91 | 16.3 | 15.5 | 10 | 3.91 |

**Interpretation:** items over 15 kg take 15.5 days, are late 10% of the time and score 3.91, versus 11.8 days, 6.3% and 4.10 for items under 0.5 kg. Light items have the highest freight-to-price ratio (20.2%). **Recommendation:** dedicated heavy-goods carriers for furniture/appliance categories. *(Item-grain metrics: a multi-item order contributes once per item.)*

---

## 14. Customer analysis

All customer metrics use `customer_unique_id`.

### C1 — Customer base and repeat rate
**Business question:** how many real customers do we have and how many return? **Purpose:** retention baseline.

```sql
WITH cust AS (
  SELECT customer_unique_id, COUNT(*) AS orders, SUM(item_revenue) AS spend
  FROM fact_order WHERE order_status = 'delivered'
  GROUP BY customer_unique_id
)
SELECT COUNT(*)                                     AS unique_customers,
       SUM(orders >= 2)                             AS repeat_customers,
       ROUND(100 * AVG(orders >= 2), 2)             AS repeat_rate_pct,
       ROUND(AVG(orders), 4)                        AS avg_orders_per_customer,
       ROUND(AVG(spend), 2)                         AS avg_lifetime_spend,
       ROUND(100 * SUM(CASE WHEN orders >= 2 THEN spend END) / SUM(spend), 2) AS pct_revenue_from_repeaters
FROM cust;
```

| unique_customers | repeat_customers | repeat_rate_pct | avg_orders_per_customer | avg_lifetime_spend | pct_revenue_from_repeaters |
|---|---|---|---|---|---|
| 93,358 | 2,801 | 3 | 1.0334 | 141.62 | 5.51 |

**Interpretation:** only **2,801 of 93,358 customers (3.0%)** placed more than one delivered order, and they contribute just 5.5% of revenue. Average orders per customer is 1.03.

### C2 — Order frequency
```sql
SELECT orders AS delivered_orders_per_customer,
       COUNT(*) AS customers,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 3) AS pct_customers,
       ROUND(AVG(spend), 2) AS avg_lifetime_spend
FROM (SELECT customer_unique_id, COUNT(*) AS orders, SUM(item_revenue) AS spend
      FROM fact_order WHERE order_status = 'delivered' GROUP BY customer_unique_id) c
GROUP BY orders ORDER BY orders;
```

| delivered_orders_per_customer | customers | pct_customers | avg_lifetime_spend |
|---|---|---|---|
| 1 | 90,557 | 97 | 137.96 |
| 2 | 2,573 | 2.756 | 245.35 |
| 3 | 181 | 0.194 | 364.5 |
| 4 | 28 | 0.03 | 676.67 |
| 5 | 9 | 0.01 | 624.06 |
| 6 | 5 | 0.005 | 520.13 |
| 7 | 3 | 0.003 | 760.01 |
| 9 | 1 | 0.001 | 1,000.85 |
| 15 | 1 | 0.001 | 714.63 |

**Interpretation:** 97% of customers bought once. Lifetime spend rises with each order (R$138 → R$245 → R$365), so every converted repeat customer is worth roughly double.

### C3 — Customer spending deciles (`NTILE`)
**Business question:** how concentrated is customer value? **Purpose:** high-value customer programme sizing.

```sql
WITH cust AS (
  SELECT customer_unique_id, SUM(item_revenue) AS spend
  FROM fact_order WHERE order_status = 'delivered' GROUP BY customer_unique_id
),
deciles AS (SELECT spend, NTILE(10) OVER (ORDER BY spend DESC) AS decile FROM cust)
SELECT decile,
       COUNT(*)                                          AS customers,
       ROUND(MIN(spend), 2)                              AS min_spend,
       ROUND(MAX(spend), 2)                              AS max_spend,
       ROUND(SUM(spend), 0)                              AS revenue,
       ROUND(100 * SUM(spend) / SUM(SUM(spend)) OVER (), 2) AS pct_revenue,
       ROUND(100 * SUM(SUM(spend)) OVER (ORDER BY decile) / SUM(SUM(spend)) OVER (), 2) AS cumulative_pct
FROM deciles GROUP BY decile ORDER BY decile;
```

| decile | customers | min_spend | max_spend | revenue | pct_revenue | cumulative_pct |
|---|---|---|---|---|---|---|
| 1 | 9,336 | 279.99 | 13,440 | 5,434,025 | 41.1 | 41.1 |
| 2 | 9,336 | 179.9 | 279.99 | 2,052,212 | 15.52 | 56.62 |
| 3 | 9,336 | 139 | 179.9 | 1,462,923 | 11.06 | 67.69 |
| 4 | 9,336 | 109.9 | 139 | 1,145,910 | 8.67 | 76.35 |
| 5 | 9,336 | 89.7 | 109.9 | 920,254 | 6.96 | 83.31 |
| 6 | 9,336 | 69.9 | 89.7 | 730,177 | 5.52 | 88.84 |
| 7 | 9,336 | 52.98 | 69.9 | 564,366 | 4.27 | 93.1 |
| 8 | 9,336 | 39.9 | 52.98 | 433,902 | 3.28 | 96.39 |
| 9 | 9,335 | 25.98 | 39.9 | 303,650 | 2.3 | 98.68 |
| 10 | 9,335 | 0.85 | 25.98 | 174,078 | 1.32 | 100 |

**Interpretation:** the top 10% of customers (lifetime spend ≥ R$280) generate **41.1% of revenue**; the bottom 50% generate 16.7%.

### C4 — High-value customers
```sql
SELECT RANK() OVER (ORDER BY SUM(item_revenue) DESC) AS spend_rank,
       CONCAT(LEFT(customer_unique_id, 8), '...')    AS customer,
       MIN(customer_state)                           AS state,
       COUNT(*)                                      AS orders,
       ROUND(SUM(item_revenue), 2)                   AS lifetime_spend,
       ROUND(AVG(item_revenue), 2)                   AS avg_order_value,
       ROUND(AVG(review_score), 1)                   AS avg_review
FROM fact_order WHERE order_status = 'delivered'
GROUP BY customer_unique_id
ORDER BY lifetime_spend DESC LIMIT 10;
```

| spend_rank | customer | state | orders | lifetime_spend | avg_order_value | avg_review |
|---|---|---|---|---|---|---|
| 1 | 0a0a9211... | RJ | 1 | 13,440 | 13,440 | 1 |
| 2 | da122df9... | RJ | 2 | 7,388 | 3,694 | 5 |
| 3 | 763c8b1c... | ES | 1 | 7,160 | 7,160 | 1 |
| 4 | dc4802a7... | MS | 1 | 6,735 | 6,735 | 5 |
| 5 | 459bef48... | ES | 1 | 6,729 | 6,729 | NULL |
| 6 | ff4159b9... | SP | 1 | 6,499 | 6,499 | 5 |
| 7 | 4007669d... | MG | 1 | 5,934.60 | 5,934.60 | 1 |
| 8 | eebb5dda... | SP | 1 | 4,690 | 4,690 | 4 |
| 9 | 48e1ac10... | PB | 1 | 4,590 | 4,590 | 5 |
| 10 | a229eba7... | RJ | 1 | 4,400 | 4,400 | 5 |

**Interpretation:** the highest-value customers are almost all one-off buyers of expensive items, and three of the top seven left a 1-star review — including the single largest order (R$13,440). **Recommendation:** white-glove service (proactive tracking, priority support) for orders above roughly R$1,000.

### C5 — Repeat rate and value by state
```sql
SELECT customer_state,
       COUNT(*)                          AS unique_customers,
       ROUND(100 * AVG(orders >= 2), 2)  AS repeat_rate_pct,
       ROUND(AVG(spend), 2)              AS avg_lifetime_spend
FROM (SELECT customer_unique_id, MIN(customer_state) AS customer_state,
             COUNT(*) AS orders, SUM(item_revenue) AS spend
      FROM fact_order WHERE order_status = 'delivered'
      GROUP BY customer_unique_id) c
GROUP BY customer_state HAVING COUNT(*) >= 2000
ORDER BY repeat_rate_pct DESC;
```

| customer_state | unique_customers | repeat_rate_pct | avg_lifetime_spend |
|---|---|---|---|
| RJ | 11,914 | 3.28 | 147.69 |
| SP | 39,139 | 3.1 | 129.44 |
| RS | 5,167 | 3.06 | 141.07 |
| DF | 2,019 | 3.02 | 146.99 |
| PR | 4,769 | 2.98 | 139.76 |
| MG | 10,999 | 2.95 | 141.18 |
| BA | 3,158 | 2.85 | 156.38 |
| SC | 3,445 | 2.7 | 147.09 |

**Interpretation:** repeat rates are uniformly low (2.7%–3.3%) across states — low retention is a platform-wide issue, not a regional one.

### C6 — Time to next order (`LAG`)
**Business question:** when do repeat customers come back? **Purpose:** timing of retention campaigns.

```sql
WITH seq AS (
  SELECT customer_unique_id, order_purchase_timestamp,
         LAG(order_purchase_timestamp) OVER (PARTITION BY customer_unique_id
                                             ORDER BY order_purchase_timestamp) AS prev_ts
  FROM fact_order WHERE order_status = 'delivered'
)
SELECT CASE WHEN DATEDIFF(order_purchase_timestamp, prev_ts) = 0  THEN '1: same day'
            WHEN DATEDIFF(order_purchase_timestamp, prev_ts) <= 30 THEN '2: 1-30 days'
            WHEN DATEDIFF(order_purchase_timestamp, prev_ts) <= 90 THEN '3: 31-90 days'
            WHEN DATEDIFF(order_purchase_timestamp, prev_ts) <= 180 THEN '4: 91-180 days'
            ELSE '5: 181+ days' END AS gap_band,
       COUNT(*) AS repeat_orders,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct
FROM seq WHERE prev_ts IS NOT NULL
GROUP BY gap_band ORDER BY gap_band;
```

| gap_band | repeat_orders | pct |
|---|---|---|
| 1: same day | 890 | 28.53 |
| 2: 1-30 days | 678 | 21.73 |
| 3: 31-90 days | 581 | 18.62 |
| 4: 91-180 days | 462 | 14.81 |
| 5: 181+ days | 509 | 16.31 |

**Interpretation:** 28.5% of "repeat" orders are placed the **same day** as the previous one — split baskets rather than genuine loyalty — so true repeat behaviour is even lower than 3%. Among genuine (not same-day) returns, 56% come back within 90 days. **Recommendation:** trigger re-engagement campaigns in the 30–90-day window.

### C7 — First-order experience × repeat rate
**Business question:** do customers whose first order went badly come back less? **Purpose:** test whether satisfaction drives retention.

```sql
WITH ranked AS (
  SELECT customer_unique_id, review_score, is_late,
         ROW_NUMBER() OVER (PARTITION BY customer_unique_id ORDER BY order_purchase_timestamp) AS order_no,
         COUNT(*)     OVER (PARTITION BY customer_unique_id)                                    AS total_orders
  FROM fact_order WHERE order_status = 'delivered'
)
SELECT CASE WHEN review_score >= 4 THEN '1: first order rated 4-5'
            WHEN review_score = 3  THEN '2: first order rated 3'
            WHEN review_score <= 2 THEN '3: first order rated 1-2'
            ELSE '4: first order not reviewed' END AS first_experience,
       COUNT(*)                                    AS customers,
       ROUND(100 * AVG(total_orders >= 2), 2)      AS repeat_rate_pct
FROM ranked WHERE order_no = 1
GROUP BY first_experience ORDER BY first_experience;
```

| first_experience | customers | repeat_rate_pct |
|---|---|---|
| 1: first order rated 4-5 | 73,161 | 3.03 |
| 2: first order rated 3 | 7,665 | 2.91 |
| 3: first order rated 1-2 | 11,917 | 2.84 |
| 4: first order not reviewed | 615 | 3.41 |

**Interpretation:** the difference is small (3.03% after a 4–5 star first order vs 2.84% after 1–2 stars). On this data, a good first experience alone does not create loyalty; low retention appears structural (marketplace model, no loyalty mechanism) rather than purely a service issue.

---

## 15. Product analysis

### P1 — Category league table (`RANK`, `DENSE_RANK`, running share)
```sql
WITH cat AS (
  SELECT category, SUM(price) AS revenue, COUNT(*) AS units, AVG(price) AS avg_price,
         AVG(freight_value) AS avg_freight
  FROM v_item_detail WHERE order_status = 'delivered' GROUP BY category
),
cat_rev AS (                   -- review at (order, category) grain
  SELECT oc.category, AVG(f.review_score) AS avg_review
  FROM (SELECT DISTINCT order_id, category FROM v_item_detail WHERE order_status = 'delivered') oc
  JOIN fact_order f USING (order_id) GROUP BY oc.category
)
SELECT RANK()       OVER (ORDER BY c.revenue DESC)          AS revenue_rank,
       c.category,
       ROUND(c.revenue, 0)                                  AS revenue,
       c.units,
       ROUND(c.avg_price, 2)                                AS avg_price,
       ROUND(c.avg_freight, 2)                              AS avg_freight,
       ROUND(r.avg_review, 2)                               AS avg_review,
       DENSE_RANK() OVER (ORDER BY ROUND(r.avg_review, 2) DESC) AS review_rank,
       ROUND(100 * SUM(c.revenue) OVER (ORDER BY c.revenue DESC) / SUM(c.revenue) OVER (), 1) AS cumulative_revenue_pct
FROM cat c JOIN cat_rev r USING (category)
ORDER BY revenue_rank LIMIT 20;
```

| revenue_rank | category | revenue | units | avg_price | avg_freight | avg_review | review_rank | cumulative_revenue_pct |
|---|---|---|---|---|---|---|---|---|
| 1 | health_beauty | 1,233,132 | 9,465 | 130.28 | 18.91 | 4.23 | 15 | 9.3 |
| 2 | watches_gifts | 1,166,177 | 5,859 | 199.04 | 16.75 | 4.12 | 25 | 18.1 |
| 3 | bed_bath_table | 1,023,435 | 10,953 | 93.44 | 18.42 | 4 | 34 | 25.9 |
| 4 | sports_leisure | 954,853 | 8,431 | 113.25 | 19.38 | 4.23 | 15 | 33.1 |
| 5 | computers_accessories | 888,725 | 7,644 | 116.26 | 18.84 | 4.08 | 29 | 39.8 |
| 6 | furniture_decor | 711,928 | 8,160 | 87.25 | 20.64 | 4.06 | 31 | 45.2 |
| 7 | housewares | 615,629 | 6,795 | 90.6 | 21.01 | 4.19 | 19 | 49.9 |
| 8 | cool_stuff | 610,204 | 3,718 | 164.12 | 21.91 | 4.22 | 16 | 54.5 |
| 9 | auto | 578,967 | 4,140 | 139.85 | 21.86 | 4.15 | 23 | 58.9 |
| 10 | toys | 471,286 | 4,030 | 116.94 | 18.8 | 4.24 | 14 | 62.4 |
| 11 | garden_tools | 470,495 | 4,268 | 110.24 | 22.65 | 4.18 | 20 | 66 |
| 12 | baby | 400,422 | 2,982 | 134.28 | 22.24 | 4.1 | 27 | 69 |
| 13 | perfumery | 390,145 | 3,340 | 116.81 | 15.88 | 4.26 | 12 | 72 |
| 14 | telephony | 309,860 | 4,430 | 69.95 | 15.65 | 4.05 | 32 | 74.3 |
| 15 | office_furniture | 268,154 | 1,668 | 160.76 | 40.2 | 3.64 | 44 | 76.3 |
| 16 | stationery | 223,789 | 2,466 | 90.75 | 18.57 | 4.3 | 10 | 78 |
| 17 | computers | 218,684 | 199 | 1,098.92 | 48.57 | 4.22 | 16 | 79.7 |
| 18 | pet_shop | 211,696 | 1,924 | 110.03 | 20.23 | 4.27 | 11 | 81.3 |
| 19 | musical_instruments | 184,316 | 651 | 283.13 | 27.45 | 4.23 | 15 | 82.7 |
| 20 | small_appliances | 182,754 | 658 | 277.74 | 23.33 | 4.26 | 12 | 84.1 |

```sql
WITH cat AS (SELECT category, SUM(price) rev FROM v_item_detail WHERE order_status = 'delivered' GROUP BY category),
     cum AS (SELECT category, SUM(rev) OVER (ORDER BY rev DESC) / SUM(rev) OVER () AS cum_share FROM cat)
SELECT (SELECT COUNT(*) FROM cat)               AS total_categories,
       (SELECT COUNT(*) FROM cum WHERE cum_share < 0.8) + 1 AS categories_needed_for_80pct_revenue;
```

| total_categories | categories_needed_for_80pct_revenue |
|---|---|
| 74 | 18 |

**Interpretation:** 18 of 74 categories generate 80% of revenue. The revenue and review rankings diverge: bed_bath_table is #3 in revenue but #34 in satisfaction, and office_furniture is #15 in revenue but #44 in satisfaction. Several smaller categories (stationery, pet_shop, small_appliances) combine solid revenue with top-12 satisfaction.

### P2 — Best-selling product within each top category (`ROW_NUMBER`)
```sql
WITH prod AS (
  SELECT category, product_id, SUM(price) AS revenue, COUNT(*) AS units,
         ROW_NUMBER() OVER (PARTITION BY category ORDER BY SUM(price) DESC) AS rn,
         SUM(SUM(price)) OVER (PARTITION BY category) AS category_revenue
  FROM v_item_detail WHERE order_status = 'delivered'
  GROUP BY category, product_id
)
SELECT category, LEFT(product_id, 8) AS product, ROUND(revenue, 0) AS revenue, units,
       ROUND(100 * revenue / category_revenue, 2) AS pct_of_category
FROM prod
WHERE rn = 1 AND category IN (SELECT category FROM (
        SELECT category FROM v_item_detail WHERE order_status = 'delivered'
        GROUP BY category ORDER BY SUM(price) DESC LIMIT 5) t)
ORDER BY category_revenue DESC;
```

| category | product | revenue | units | pct_of_category |
|---|---|---|---|---|
| health_beauty | bb50f2e2 | 63,560 | 194 | 5.15 |
| watches_gifts | 53b36df6 | 37,455 | 321 | 3.21 |
| bed_bath_table | 99a4788c | 42,050 | 477 | 4.11 |
| sports_leisure | 0bbdc963 | 9,070 | 30 | 0.95 |
| computers_accessories | d1c42706 | 45,621 | 332 | 5.13 |

**Interpretation:** no single product exceeds ~5% of its category, and in sports_leisure the top product is under 1% — categories are broad long-tail assortments, not hero-product driven.

### P3 — Listing photos × product performance
```sql
WITH prod AS (
  SELECT p.product_id, p.product_photos_qty, COUNT(*) AS units, SUM(i.price) AS revenue
  FROM order_items i JOIN orders o USING (order_id) JOIN products p USING (product_id)
  WHERE o.order_status = 'delivered'
  GROUP BY p.product_id, p.product_photos_qty
)
SELECT CASE WHEN product_photos_qty IS NULL THEN '0: unknown'
            WHEN product_photos_qty = 1 THEN '1: 1 photo'
            WHEN product_photos_qty = 2 THEN '2: 2 photos'
            WHEN product_photos_qty <= 4 THEN '3: 3-4 photos'
            ELSE '4: 5+ photos' END                 AS photo_band,
       COUNT(*)                                     AS products,
       ROUND(AVG(units), 2)                         AS avg_units_per_product,
       ROUND(AVG(revenue), 2)                       AS avg_revenue_per_product
FROM prod GROUP BY photo_band ORDER BY photo_band;
```

| photo_band | products | avg_units_per_product | avg_revenue_per_product |
|---|---|---|---|
| 0: unknown | 584 | 2.63 | 292.34 |
| 1: 1 photo | 16,137 | 3.4 | 384.15 |
| 2: 2 photos | 6,111 | 3.52 | 388.96 |
| 3: 3-4 photos | 6,148 | 3.32 | 461.17 |
| 4: 5+ photos | 3,236 | 3.7 | 506.64 |

**Interpretation:** products with 5+ photos average R$507 of revenue versus R$384 for single-photo listings (+32%). Half of products have only one photo. This is an association: higher-priced products may simply get more photos. **Recommendation:** A/B-test a minimum-photo standard before mandating it.

### P4 — Product long tail
```sql
WITH prod AS (
  SELECT product_id, COUNT(*) AS units, SUM(price) AS revenue
  FROM v_item_detail WHERE order_status = 'delivered' GROUP BY product_id
),
r AS (SELECT revenue, units, ROW_NUMBER() OVER (ORDER BY revenue DESC) AS rn, COUNT(*) OVER () AS n FROM prod)
SELECT MAX(n)                                                       AS products_sold,
       SUM(units = 1)                                               AS sold_exactly_once,
       ROUND(100 * AVG(units = 1), 1)                               AS pct_sold_once,
       ROUND(100 * SUM(CASE WHEN rn <= n * 0.01 THEN revenue END) / SUM(revenue), 1) AS top1pct_products_revenue_share,
       ROUND(100 * SUM(CASE WHEN rn <= n * 0.10 THEN revenue END) / SUM(revenue), 1) AS top10pct_products_revenue_share
FROM r;
```

| products_sold | sold_exactly_once | pct_sold_once | top1pct_products_revenue_share | top10pct_products_revenue_share |
|---|---|---|---|---|
| 32,216 | 17,716 | 55 | 24.4 | 60.8 |

**Interpretation:** 55% of products sold exactly once; the top 1% of products generate 24.4% of revenue and the top 10% generate 60.8%.

---

## 16. Seller performance

### S1 — Seller scorecard (revenue + orders + items + reviews + delivery)
```sql
WITH seller_order AS (
  SELECT seller_id, order_id, SUM(price) AS revenue, COUNT(*) AS items,
         MAX(order_delivered_carrier_date > shipping_limit_date) AS handover_late
  FROM v_item_detail WHERE order_status = 'delivered'
  GROUP BY seller_id, order_id
),
perf AS (
  SELECT so.seller_id, COUNT(*) AS orders, SUM(so.items) AS items, SUM(so.revenue) AS revenue,
         AVG(f.review_score) AS avg_review, AVG(f.is_late) AS late_rate,
         AVG(so.handover_late) AS handover_late_rate
  FROM seller_order so JOIN fact_order f USING (order_id)
  GROUP BY so.seller_id
)
SELECT RANK() OVER (ORDER BY revenue DESC)                   AS revenue_rank,
       LEFT(p.seller_id, 8)                                  AS seller,
       s.seller_state,
       ROUND(p.revenue, 0) AS revenue, p.orders, p.items,
       ROUND(p.avg_review, 2)                                AS avg_review,
       ROUND(100 * p.late_rate, 1)                           AS late_pct,
       ROUND(100 * p.handover_late_rate, 1)                  AS handover_late_pct,
       DENSE_RANK() OVER (ORDER BY ROUND(p.avg_review, 2) DESC) AS review_rank_among_all
FROM perf p JOIN sellers s USING (seller_id)
ORDER BY revenue_rank LIMIT 15;
```

| revenue_rank | seller | seller_state | revenue | orders | items | avg_review | late_pct | handover_late_pct | review_rank_among_all |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 4869f7a5 | SP | 226,988 | 1,124 | 1,148 | 4.15 | 10.5 | 5.5 | 76 |
| 2 | 53243585 | BA | 217,940 | 348 | 400 | 4.19 | 3.5 | 6.9 | 72 |
| 3 | 4a3ca931 | SP | 196,882 | 1,772 | 1,949 | 3.85 | 9.7 | 8.7 | 106 |
| 4 | fa1c13f2 | SP | 190,917 | 578 | 579 | 4.37 | 9.2 | 8 | 54 |
| 5 | 7c67e144 | SP | 186,570 | 973 | 1,355 | 3.5 | 9.2 | 29.7 | 139 |
| 6 | 7e93a43e | SP | 165,981 | 319 | 322 | 4.36 | 4.7 | 7.8 | 55 |
| 7 | da8622b1 | SP | 159,817 | 1,311 | 1,548 | 4.18 | 6.6 | 4.5 | 73 |
| 8 | 7a67c85e | SP | 139,659 | 1,145 | 1,155 | 4.28 | 5.2 | 2.8 | 63 |
| 9 | 1025f0e2 | SP | 138,209 | 910 | 1,420 | 4.01 | 7.9 | 17.8 | 90 |
| 10 | 955fee92 | SP | 131,837 | 1,261 | 1,472 | 4.2 | 6.1 | 0.7 | 71 |
| 11 | 46dc3b2c | RJ | 122,811 | 503 | 523 | 4.27 | 5.8 | 10.3 | 64 |
| 12 | 6560211a | SP | 120,703 | 1,819 | 1,996 | 3.98 | 5.3 | 0.6 | 93 |
| 13 | 620c87c1 | RJ | 112,462 | 722 | 778 | 4.31 | 8.7 | 7.5 | 60 |
| 14 | 7d13fca1 | SP | 112,436 | 558 | 571 | 4.04 | 11.5 | 14.9 | 87 |
| 15 | 5dceca12 | SP | 111,127 | 322 | 343 | 4.01 | 5.6 | 4.4 | 90 |

**Interpretation:** big is not always good. Seller #5 (7c67e144, R$187k) has a 3.50 review and misses the carrier hand-over deadline on 29.7% of orders; #3 (4a3ca931) averages 3.85. Others combine scale with quality (#8 7a67c85e: 4.28 review, 2.8% hand-over late). **Recommendation:** the top sellers by revenue should be the first accounts to receive delivery-SLA reviews, because their problems affect the most customers.

### S2 — Seller revenue concentration
```sql
WITH s AS (SELECT seller_id, SUM(price) AS revenue FROM v_item_detail
           WHERE order_status = 'delivered' GROUP BY seller_id),
     r AS (SELECT revenue, ROW_NUMBER() OVER (ORDER BY revenue DESC) AS rn, COUNT(*) OVER () AS n FROM s)
SELECT MAX(n) AS active_sellers,
       ROUND(100 * SUM(CASE WHEN rn <= n * 0.01 THEN revenue END) / SUM(revenue), 1) AS top1pct_share,
       ROUND(100 * SUM(CASE WHEN rn <= n * 0.10 THEN revenue END) / SUM(revenue), 1) AS top10pct_share,
       ROUND(100 * SUM(CASE WHEN rn <= n * 0.20 THEN revenue END) / SUM(revenue), 1) AS top20pct_share,
       ROUND(100 * SUM(CASE WHEN rn >  n * 0.50 THEN revenue END) / SUM(revenue), 1) AS bottom50pct_share
FROM r;
```

| active_sellers | top1pct_share | top10pct_share | top20pct_share | bottom50pct_share |
|---|---|---|---|---|
| 2,970 | 25.5 | 67.1 | 82.3 | 3.3 |

**Interpretation:** the top 1% of sellers (about 30) produce 25.5% of revenue, the top 20% produce 82.3%, and the bottom half just 3.3%.

### S3 — Seller hand-over timeliness × customer outcome × review
**Business question:** how much of late delivery is seller-caused? **Purpose:** allocate accountability between sellers and carriers.

```sql
WITH so AS (
  SELECT order_id,
         MAX(order_delivered_carrier_date > shipping_limit_date) AS any_seller_handover_late
  FROM v_item_detail WHERE order_status = 'delivered' AND order_delivered_carrier_date IS NOT NULL
  GROUP BY order_id
)
SELECT CASE so.any_seller_handover_late WHEN 1 THEN 'seller missed hand-over deadline'
                                        ELSE 'seller handed over on time' END AS seller_handover,
       CASE f.is_late WHEN 1 THEN 'customer delivery late' ELSE 'customer delivery on time' END AS customer_outcome,
       COUNT(*)                         AS orders,
       ROUND(AVG(f.review_score), 2)    AS avg_review
FROM so JOIN fact_order f USING (order_id)
WHERE f.is_late IS NOT NULL
GROUP BY seller_handover, customer_outcome ORDER BY seller_handover DESC, customer_outcome DESC;
```

| seller_handover | customer_outcome | orders | avg_review |
|---|---|---|---|
| seller missed hand-over deadline | customer delivery on time | 6,909 | 4.07 |
| seller missed hand-over deadline | customer delivery late | 1,814 | 2.27 |
| seller handed over on time | customer delivery on time | 83,027 | 4.31 |
| seller handed over on time | customer delivery late | 4,719 | 2.27 |

**Interpretation:** when a seller misses the hand-over deadline, 20.8% of orders arrive late, versus 5.4% when the seller is on time. But once an order is late, the review is the same (2.27) whoever caused it — the customer does not distinguish. Most late orders (4,719 of 6,533) still come from sellers who handed over on time, so **carriers cause the majority of late deliveries** and sellers a significant minority.

---

## 17. Delivery and customer satisfaction

### D1 — Purchase → approval → carrier → customer → estimate
```sql
WITH s AS (
  SELECT TIMESTAMPDIFF(MINUTE, order_purchase_timestamp, order_approved_at) / 60     AS purchase_to_approval_h,
         TIMESTAMPDIFF(MINUTE, order_approved_at, order_delivered_carrier_date) / 1440 AS approval_to_carrier_d,
         TIMESTAMPDIFF(MINUTE, order_delivered_carrier_date, order_delivered_customer_date) / 1440 AS carrier_to_customer_d,
         TIMESTAMPDIFF(MINUTE, order_purchase_timestamp, order_delivered_customer_date) / 1440 AS total_d,
         TIMESTAMPDIFF(MINUTE, order_purchase_timestamp, order_estimated_delivery_date) / 1440 AS promised_d
  FROM fact_order WHERE valid_delivery_chain = 1
)
SELECT COUNT(*)                              AS orders,
       ROUND(AVG(purchase_to_approval_h), 1) AS avg_purchase_to_approval_hours,
       ROUND(AVG(approval_to_carrier_d), 2)  AS avg_approval_to_carrier_days,
       ROUND(AVG(carrier_to_customer_d), 2)  AS avg_carrier_to_customer_days,
       ROUND(AVG(total_d), 2)                AS avg_total_days,
       ROUND(AVG(promised_d), 2)             AS avg_promised_days,
       ROUND(100 * AVG(carrier_to_customer_d) / AVG(total_d), 1) AS carrier_leg_pct_of_total
FROM s;
```

| orders | avg_purchase_to_approval_hours | avg_approval_to_carrier_days | avg_carrier_to_customer_days | avg_total_days | avg_promised_days | carrier_leg_pct_of_total |
|---|---|---|---|---|---|---|
| 95,082 | 9.6 | 2.85 | 9.36 | 12.62 | 23.74 | 74.2 |

**Interpretation:** approval takes ~10 hours, seller hand-over ~2.9 days and the **carrier leg ~9.4 days (74% of total time)**. The promise is 23.7 days against an actual 12.6 — about 11 days of buffer. The carrier leg is where speed can be won.

### D2 — Monthly delivery performance
```sql
SELECT purchase_month,
       COUNT(*)                          AS delivered_orders,
       ROUND(AVG(delivery_days), 1)      AS avg_delivery_days,
       ROUND(100 * AVG(is_late), 1)      AS late_pct,
       ROUND(AVG(review_score), 2)       AS avg_review
FROM fact_order
WHERE order_status = 'delivered' AND is_late IS NOT NULL
  AND purchase_month BETWEEN '2017-01' AND '2018-08'
GROUP BY purchase_month ORDER BY purchase_month;
```

| purchase_month | delivered_orders | avg_delivery_days | late_pct | avg_review |
|---|---|---|---|---|
| 2017-01 | 750 | 12.6 | 2.9 | 4.2 |
| 2017-02 | 1,653 | 13.2 | 3 | 4.2 |
| 2017-03 | 2,546 | 13 | 4.6 | 4.19 |
| 2017-04 | 2,303 | 14.9 | 6.6 | 4.14 |
| 2017-05 | 3,545 | 11.3 | 3 | 4.24 |
| 2017-06 | 3,135 | 12 | 3 | 4.22 |
| 2017-07 | 3,872 | 11.6 | 2.8 | 4.26 |
| 2017-08 | 4,193 | 11.1 | 2.9 | 4.31 |
| 2017-09 | 4,150 | 11.9 | 4.4 | 4.27 |
| 2017-10 | 4,478 | 11.9 | 4.2 | 4.2 |
| 2017-11 | 7,288 | 15.2 | 12.4 | 3.99 |
| 2017-12 | 5,513 | 15.4 | 7.5 | 4.09 |
| 2018-01 | 7,069 | 14.1 | 5.7 | 4.11 |
| 2018-02 | 6,555 | 16.9 | 14.1 | 3.88 |
| 2018-03 | 7,003 | 16.3 | 19 | 3.81 |
| 2018-04 | 6,798 | 11.5 | 4.5 | 4.21 |
| 2018-05 | 6,749 | 11.4 | 6.6 | 4.24 |
| 2018-06 | 6,096 | 9.2 | 1.2 | 4.31 |
| 2018-07 | 6,156 | 9 | 3.4 | 4.32 |
| 2018-08 | 6,351 | 7.7 | 6.2 | 4.31 |

**Interpretation:** late rates spiked in Nov 2017 (12.4%, Black Friday), and again in Feb–Mar 2018 (14.1% and 19.0%). In exactly those months the average review fell to its lowest values (3.99, 3.88, 3.81). When delivery recovered (Jun–Jul 2018: 1.2–3.4% late), reviews returned to 4.31–4.32.

### D3 — Strength of association (Pearson r in SQL)
```sql
WITH d AS (
  SELECT delay_days AS x1, delivery_days AS x2,
         CAST(review_score AS SIGNED) AS y        -- review_score is UNSIGNED: cast before multiplying by negative delays
  FROM fact_order
  WHERE order_status = 'delivered' AND delay_days IS NOT NULL AND review_score IS NOT NULL
)
SELECT COUNT(*) AS n,
       ROUND((AVG(x1 * y) - AVG(x1) * AVG(y)) / (STDDEV_POP(x1) * STDDEV_POP(y)), 3) AS r_delay_days_vs_review,
       ROUND((AVG(x2 * y) - AVG(x2) * AVG(y)) / (STDDEV_POP(x2) * STDDEV_POP(y)), 3) AS r_delivery_days_vs_review
FROM d;
```

| n | r_delay_days_vs_review | r_delivery_days_vs_review |
|---|---|---|
| 95,824 | -0.267 | -0.334 |

### D4 — Late vs on-time
```sql
SELECT CASE is_late WHEN 1 THEN 'late' ELSE 'on time / early' END AS delivery_outcome,
       COUNT(*)                                AS orders,
       ROUND(AVG(review_score), 2)             AS avg_review,
       ROUND(100 * AVG(review_score <= 2), 1)  AS pct_negative,
       ROUND(100 * AVG(review_score = 5), 1)   AS pct_five_star
FROM fact_order
WHERE order_status = 'delivered' AND is_late IS NOT NULL AND review_score IS NOT NULL
GROUP BY delivery_outcome;
```

| delivery_outcome | orders | avg_review | pct_negative | pct_five_star |
|---|---|---|---|---|
| on time / early | 89,443 | 4.29 | 9.3 | 62.3 |
| late | 6,381 | 2.27 | 62.4 | 16.5 |

**Association, not causation.** Late deliveries are strongly associated with low reviews (B5, M3, D2, D4), and the pattern is consistent across bands, states and months — but the data is observational. Plausible confounders include product type (heavy items are both slower and more complex, M10), seller quality (poor sellers both ship late and may misdescribe products, M6) and region. Negative correlations of r = −0.27 (delay) and −0.33 (total delivery days) are moderate, meaning delivery explains only part of the variation in reviews. A causal claim would need a controlled test, for example improving one carrier route and comparing reviews against a matched control route.

---

## 18. Time-series analysis

### T1 — Monthly revenue, orders, customers, AOV, MoM growth (`LAG`), running total, moving average
```sql
WITH m AS (
  SELECT purchase_month,
         SUM(item_revenue)                  AS revenue,
         COUNT(*)                           AS orders,
         COUNT(DISTINCT customer_unique_id) AS customers,
         AVG(item_revenue)                  AS aov
  FROM fact_order
  WHERE order_status = 'delivered' AND purchase_month BETWEEN '2017-01' AND '2018-08'
  GROUP BY purchase_month
)
SELECT purchase_month,
       ROUND(revenue, 0)                                                   AS revenue,
       orders, customers,
       ROUND(aov, 2)                                                       AS aov,
       ROUND(100 * (revenue - LAG(revenue) OVER w) / LAG(revenue) OVER w, 1) AS mom_revenue_growth_pct,
       ROUND(100 * (orders - LAG(orders) OVER w) / LAG(orders) OVER w, 1)    AS mom_orders_growth_pct,
       ROUND(SUM(revenue) OVER (ORDER BY purchase_month ROWS UNBOUNDED PRECEDING), 0) AS running_revenue,
       ROUND(AVG(revenue) OVER (ORDER BY purchase_month ROWS 2 PRECEDING), 0)         AS revenue_3m_moving_avg
FROM m
WINDOW w AS (ORDER BY purchase_month)
ORDER BY purchase_month;
```

| purchase_month | revenue | orders | customers | aov | mom_revenue_growth_pct | mom_orders_growth_pct | running_revenue | revenue_3m_moving_avg |
|---|---|---|---|---|---|---|---|---|
| 2017-01 | 111,798 | 750 | 718 | 149.06 | NULL | NULL | 111,798 | 111,798 |
| 2017-02 | 234,223 | 1,653 | 1,630 | 141.7 | 109.5 | 120.4 | 346,022 | 173,011 |
| 2017-03 | 359,199 | 2,546 | 2,508 | 141.08 | 53.4 | 54 | 705,221 | 235,074 |
| 2017-04 | 340,670 | 2,303 | 2,274 | 147.92 | -5.2 | -9.5 | 1,045,890 | 311,364 |
| 2017-05 | 489,338 | 3,546 | 3,479 | 138 | 43.6 | 54 | 1,535,229 | 396,402 |
| 2017-06 | 421,923 | 3,135 | 3,076 | 134.58 | -13.8 | -11.6 | 1,957,152 | 417,310 |
| 2017-07 | 481,605 | 3,872 | 3,802 | 124.38 | 14.1 | 23.5 | 2,438,756 | 464,289 |
| 2017-08 | 554,700 | 4,193 | 4,114 | 132.29 | 15.2 | 8.3 | 2,993,456 | 486,076 |
| 2017-09 | 607,400 | 4,150 | 4,083 | 146.36 | 9.5 | -1 | 3,600,856 | 547,901 |
| 2017-10 | 648,248 | 4,478 | 4,417 | 144.76 | 6.7 | 7.9 | 4,249,103 | 603,449 |
| 2017-11 | 987,765 | 7,289 | 7,183 | 135.51 | 52.4 | 62.8 | 5,236,869 | 747,804 |
| 2017-12 | 726,033 | 5,513 | 5,450 | 131.69 | -26.5 | -24.4 | 5,962,902 | 787,349 |
| 2018-01 | 924,645 | 7,069 | 6,974 | 130.8 | 27.4 | 28.2 | 6,887,547 | 879,481 |
| 2018-02 | 826,437 | 6,555 | 6,400 | 126.08 | -10.6 | -7.3 | 7,713,984 | 825,705 |
| 2018-03 | 953,356 | 7,003 | 6,914 | 136.14 | 15.4 | 6.8 | 8,667,340 | 901,479 |
| 2018-04 | 973,534 | 6,798 | 6,744 | 143.21 | 2.1 | -2.9 | 9,640,874 | 917,776 |
| 2018-05 | 977,545 | 6,749 | 6,693 | 144.84 | 0.4 | -0.7 | 10,618,419 | 968,145 |
| 2018-06 | 856,078 | 6,099 | 6,061 | 140.36 | -12.4 | -9.6 | 11,474,497 | 935,719 |
| 2018-07 | 867,953 | 6,159 | 6,100 | 140.92 | 1.4 | 1 | 12,342,450 | 900,525 |
| 2018-08 | 838,577 | 6,351 | 6,310 | 132.04 | -3.4 | 3.1 | 13,181,027 | 854,203 |

**Interpretation:** revenue grew from R$112k (Jan 2017) to a Black-Friday peak of R$988k (Nov 2017, +52.4% MoM), then **flattened**: since Jan 2018 every month has been between R$826k and R$978k, and the last five months show MoM changes of +2.1%, +0.4%, −12.4%, +1.4% and −3.4%. AOV has stayed within R$124–149 throughout, so growth came from order volume, not basket size.

### T2 — Year → quarter hierarchy (`WITH ROLLUP`)
```sql
SELECT COALESCE(CAST(yr AS CHAR), 'ALL YEARS')         AS year_,
       COALESCE(CONCAT('Q', qtr), IF(yr IS NULL, '', 'year total')) AS quarter_,
       orders, ROUND(revenue, 0) AS revenue, ROUND(revenue / orders, 2) AS aov
FROM (
  SELECT YEAR(order_purchase_timestamp) AS yr, QUARTER(order_purchase_timestamp) AS qtr,
         COUNT(*) AS orders, SUM(item_revenue) AS revenue
  FROM fact_order WHERE order_status = 'delivered'
  GROUP BY yr, qtr WITH ROLLUP
) r;
```

| year_ | quarter_ | orders | revenue | aov |
|---|---|---|---|---|
| 2016 | Q3 | 1 | 135 | 134.97 |
| 2016 | Q4 | 266 | 40,336 | 151.64 |
| 2016 | year total | 267 | 40,471 | 151.58 |
| 2017 | Q1 | 4,949 | 705,221 | 142.5 |
| 2017 | Q2 | 8,984 | 1,251,931 | 139.35 |
| 2017 | Q3 | 12,215 | 1,643,704 | 134.56 |
| 2017 | Q4 | 17,280 | 2,362,046 | 136.69 |
| 2017 | year total | 43,428 | 5,962,902 | 137.31 |
| 2018 | Q1 | 20,627 | 2,704,438 | 131.11 |
| 2018 | Q2 | 19,646 | 2,807,157 | 142.89 |
| 2018 | Q3 | 12,510 | 1,706,530 | 136.41 |
| 2018 | year total | 52,783 | 7,218,125 | 136.75 |
| ALL YEARS |  | 96,478 | 13,221,498 | 137.04 |

### T3 — Year-over-year, Jan–Aug
```sql
WITH m AS (
  SELECT YEAR(order_purchase_timestamp) AS yr, MONTH(order_purchase_timestamp) AS mon,
         SUM(item_revenue) AS revenue, COUNT(*) AS orders
  FROM fact_order
  WHERE order_status = 'delivered' AND MONTH(order_purchase_timestamp) <= 8
    AND YEAR(order_purchase_timestamp) IN (2017, 2018)
  GROUP BY yr, mon
)
SELECT LPAD(mon, 2, '0') AS month_,
       ROUND(MAX(CASE WHEN yr = 2017 THEN revenue END), 0) AS revenue_2017,
       ROUND(MAX(CASE WHEN yr = 2018 THEN revenue END), 0) AS revenue_2018,
       ROUND(100 * (MAX(CASE WHEN yr = 2018 THEN revenue END) / MAX(CASE WHEN yr = 2017 THEN revenue END) - 1), 1) AS yoy_growth_pct
FROM m GROUP BY mon
UNION ALL
SELECT 'Jan-Aug total',
       ROUND(SUM(CASE WHEN yr = 2017 THEN revenue END), 0),
       ROUND(SUM(CASE WHEN yr = 2018 THEN revenue END), 0),
       ROUND(100 * (SUM(CASE WHEN yr = 2018 THEN revenue END) / SUM(CASE WHEN yr = 2017 THEN revenue END) - 1), 1)
FROM m
ORDER BY month_;
```

| month_ | revenue_2017 | revenue_2018 | yoy_growth_pct |
|---|---|---|---|
| 01 | 111,798 | 924,645 | 727.1 |
| 02 | 234,223 | 826,437 | 252.8 |
| 03 | 359,199 | 953,356 | 165.4 |
| 04 | 340,670 | 973,534 | 185.8 |
| 05 | 489,338 | 977,545 | 99.8 |
| 06 | 421,923 | 856,078 | 102.9 |
| 07 | 481,605 | 867,953 | 80.2 |
| 08 | 554,700 | 838,577 | 51.2 |
| Jan-Aug total | 2,993,456 | 7,218,125 | 141.1 |

**Interpretation:** Jan–Aug 2018 revenue was 141% above the same period of 2017, but YoY growth decays steadily month by month (from +727% to +51%) as 2017 volumes caught up with the 2018 plateau.

### T4 — Category momentum
```sql
WITH c AS (
  SELECT category,
         SUM(CASE WHEN order_purchase_timestamp >= '2017-01-01' AND order_purchase_timestamp < '2017-09-01' THEN price END) AS rev_2017,
         SUM(CASE WHEN order_purchase_timestamp >= '2018-01-01' AND order_purchase_timestamp < '2018-09-01' THEN price END) AS rev_2018
  FROM v_item_detail WHERE order_status = 'delivered'
  GROUP BY category
)
SELECT category, ROUND(rev_2017, 0) AS jan_aug_2017, ROUND(rev_2018, 0) AS jan_aug_2018,
       ROUND(100 * (rev_2018 / rev_2017 - 1), 1) AS growth_pct,
       RANK() OVER (ORDER BY rev_2018 / rev_2017 DESC) AS growth_rank
FROM c WHERE rev_2018 >= 100000
ORDER BY growth_pct DESC;
```

| category | jan_aug_2017 | jan_aug_2018 | growth_pct | growth_rank |
|---|---|---|---|---|
| construction_tools_construction | 2,581 | 122,887 | 4,660.30 | 1 |
| baby | 67,998 | 250,616 | 268.6 | 2 |
| stationery | 36,725 | 132,316 | 260.3 | 3 |
| watches_gifts | 201,138 | 687,855 | 242 | 4 |
| health_beauty | 243,522 | 755,725 | 210.3 | 5 |
| housewares | 127,535 | 391,823 | 207.2 | 6 |
| telephony | 57,473 | 174,124 | 203 | 7 |
| musical_instruments | 37,051 | 105,827 | 185.6 | 8 |
| auto | 125,247 | 343,288 | 174.1 | 9 |
| pet_shop | 49,083 | 126,850 | 158.4 | 10 |
| sports_leisure | 216,724 | 517,166 | 138.6 | 11 |
| computers_accessories | 214,631 | 496,269 | 131.2 | 12 |
| furniture_decor | 170,859 | 381,650 | 123.4 | 13 |
| bed_bath_table | 254,445 | 532,359 | 109.2 | 14 |
| office_furniture | 74,662 | 140,578 | 88.3 | 15 |
| garden_tools | 138,051 | 212,186 | 53.7 | 16 |
| perfumery | 121,953 | 174,372 | 43 | 17 |
| toys | 118,450 | 168,123 | 41.9 | 18 |
| cool_stuff | 206,306 | 227,744 | 10.4 | 19 |

**Interpretation:** fastest-growing established categories are baby (+269%), stationery (+260%), watches_gifts (+242%) and health_beauty (+210%). construction_tools_construction grew from a very small base. cool_stuff (+10%), toys (+42%), perfumery (+43%) and garden_tools (+54%) are lagging far behind the platform's +141%.

### T5 — Peak trading days
```sql
SELECT purchase_date, DAYNAME(purchase_date) AS weekday, COUNT(*) AS orders,
       ROUND(SUM(item_revenue), 0) AS revenue,
       ROUND(COUNT(*) / (SELECT COUNT(*) / COUNT(DISTINCT purchase_date) FROM fact_order
                         WHERE order_status = 'delivered'
                           AND purchase_month BETWEEN '2017-01' AND '2018-08'), 1) AS x_average_day
FROM fact_order WHERE order_status = 'delivered'
GROUP BY purchase_date ORDER BY orders DESC LIMIT 5;
```

| purchase_date | weekday | orders | revenue | x_average_day |
|---|---|---|---|---|
| 2017-11-24 | Friday | 1,147 | 149,917 | 7.2 |
| 2017-11-25 | Saturday | 487 | 59,929 | 3 |
| 2017-11-27 | Monday | 395 | 47,237 | 2.5 |
| 2017-11-26 | Sunday | 382 | 44,000 | 2.4 |
| 2017-11-28 | Tuesday | 372 | 47,695 | 2.3 |

**Interpretation:** Black Friday (24 Nov 2017) produced 1,147 delivered orders — 7.2× an average day — and elevated demand persisted for the following four days. This peak was followed by the late-delivery spike in D2.

---

## 19. Advanced SQL coverage

| Technique | Where it is used |
|---|---|
| INNER JOIN | `v_item_detail`, S1, M9, every item-to-order join |
| LEFT JOIN | `v_order_summary` (orders without items/payments/reviews kept), DQ20 orphan tests, `zip_code` centroid join |
| Multi-table JOINs | `v_item_detail` (5 tables), `v_order_summary` (4 sources), P3 |
| GROUP BY / aggregates | every analysis (`SUM`, `AVG`, `COUNT DISTINCT`, `STDDEV`, `MIN/MAX`) |
| HAVING | B4, B7, B9, M3, M6, C5, M9 single-seller filter |
| CASE | banding in U1/U6/U9/U10, B5, M6 segments, `is_late`, conditional aggregation in M5/T3 pivots |
| CTEs | RV10, `v_order_summary`, M1–M10, all deep dives |
| Subqueries | KPI11 scalar subqueries, M1 ordering, P2 `IN (…)`, RV checks |
| Views | `v_product`, `v_order_summary`, `v_item_detail` (+ `fact_order` materialisation) |
| Date functions | `STR_TO_DATE`, `TIMESTAMPDIFF`, `DATEDIFF`, `DATE_FORMAT`, `YEAR`, `QUARTER`, `MONTH`, `DAYNAME`, `HOUR` |
| `ROW_NUMBER()` | latest review per order, median/percentiles (KPI9, U1b), P2, C7, Pareto shares |
| `RANK()` | B3, M1, M2, P1, S1, C4, T4 |
| `DENSE_RANK()` | B10, P1 review rank, S1 review rank |
| `LAG()` | T1 MoM growth, C6 days between orders |
| Running totals | T1 running revenue, B1/U2/P1 cumulative share |
| Moving average | T1 3-month window (`ROWS 2 PRECEDING`) |
| `NTILE()` | C3 deciles |
| `WITH ROLLUP` | T2 year/quarter subtotals |
| Named window (`WINDOW w AS`) | T1 |
| Stored function | `fn_std_city()` |
| Constraints | 9 enforced FKs, composite PKs, `UNIQUE`, `CHECK`, `ENUM` |

---

## 20. Key insights

1. **Growth has stalled.** Revenue rose to ~R$0.9M/month by early 2018 and then plateaued; AOV has been flat (R$124–149), so all historical growth came from acquiring new customers.
2. **Retention is close to zero.** Only 3.0% of customers return (and 28.5% of those "repeats" are same-day split baskets). Repeaters produce 5.5% of revenue, yet a second order roughly doubles lifetime value.
3. **Late delivery is the strongest correlate of dissatisfaction.** On-time orders average 4.29 stars, late orders 2.27; 1-star reviews jump from ~7% to ~70% once orders are 8+ days late. Monthly satisfaction dips mirror late-delivery spikes.
4. **The carrier leg is the bottleneck.** 74% of delivery time is in transit; carriers account for most late orders, sellers for a meaningful minority (missing the hand-over deadline quadruples the late rate).
5. **Geography is a structural handicap.** 60% of sellers and 64% of revenue originate in SP. Cross-state orders take twice as long, cost 72% more freight and are rated lower; the Northeast waits 20 days and pays ~22% freight — while spending the most per order.
6. **The promise is padded but still missed.** Estimates allow ~23.7 days for ~12.6 days of actual delivery, yet 6.8% of orders still arrive late.
7. **Revenue is concentrated.** 18 categories = 80% of revenue; top 10% of sellers = 67%; top 10% of customers = 41%.
8. **Category portfolio is uneven.** health_beauty and watches_gifts are growing leaders; computers_accessories and sports_leisure fell sharply in 2018-Q2; office_furniture and bed_bath_table have weak satisfaction.
9. **A small group of sellers damages the experience.** 153 established sellers rated below 4.0 carry ~22% of established-seller revenue; the worst miss hand-over deadlines on a third of orders.
10. **Instalments power high-ticket sales**, with 7+ instalment card orders forming the largest single pool of payment value.

---

## 21. Business recommendations

For the **Sales Director / E-commerce Manager**, in order of expected impact:

1. **Make on-time delivery a managed KPI with carrier SLAs.** Set a monthly late-rate target (e.g. < 5%, the level achieved in most of mid-2017 and mid-2018), track it by carrier and route, and prioritise RJ (12.1% late, #2 revenue state) and the Northeast. *Evidence: B5, M3, D2, D4.*
2. **Build peak-season logistics capacity.** Black Friday and Feb–Mar 2018 both produced late-delivery spikes and the lowest reviews. Pre-book carrier capacity and tighten seller hand-over windows before known peaks. *Evidence: D2, T5.*
3. **Introduce a seller performance programme.** Publish a monthly seller scorecard (revenue, review, late %, hand-over %); place the 153 at-risk and problem sellers on improvement plans, and reward "star" sellers with search visibility. *Evidence: M6, S1, S3.*
4. **Launch a retention programme.** With 97% one-time buyers, even lifting repeat rate from 3% to 5% would materially grow revenue. Use post-delivery re-engagement in the 30–90-day window and category-based cross-sell. *Evidence: C1, C2, C6.*
5. **Reduce the geographic handicap.** Recruit sellers in the Northeast and other under-served regions (BA and PE sellers already show high revenue per seller), or pilot regional fulfilment for top SKUs. *Evidence: M7, M9, B8.*
6. **Rethink freight for low-price categories and remote states.** Test free-shipping thresholds or bundles where freight exceeds ~20% of price (electronics, telephony, furniture_decor, housewares) and in high-AOV remote states. *Evidence: KPI6, B7, B9.*
7. **Rebalance category investment.** Double down on growing leaders (health_beauty, watches_gifts, baby, stationery); diagnose the Q2-2018 collapse in computers_accessories and sports_leisure; run quality audits for office_furniture and bed_bath_table. *Evidence: M5, T4, B4, P1.*
8. **Protect high-value orders.** Orders above ~R$1,000 deserve proactive tracking and priority support — several of the largest orders received 1-star reviews. Keep instalment options prominent on high-ticket items. *Evidence: C4, M4.*
9. **Fix catalogue and data capture.** Require category, photos and dimensions at listing creation (610 incomplete products), validate seller addresses, and stop issuing duplicate reviews per order. *Evidence: section 5.*

---

## 22. Limitations

- **Snapshot and coverage.** 2016 and Sep–Oct 2018 are sparse; trend conclusions rely on Jan 2017 – Aug 2018. Orders still `shipped`/`processing` at the snapshot are excluded from revenue.
- **Revenue definition.** Revenue is product price on delivered orders. There is no cost, commission or margin data, so profitability cannot be assessed.
- **Reviews.** Reviews are at order level; in the 1,278 multi-seller orders a review is attributed to every seller in the order. 768 orders have no review, and non-response may not be random. Multiple reviews per order were resolved to the latest.
- **Correlation, not causation.** All relationships (delay × review, photos × revenue, first review × repeat) are observational associations with possible confounders.
- **Customer identity.** Repeat analysis depends on Olist's `customer_unique_id` matching; customers using different details would appear as new.
- **Geography.** ZIP prefixes are approximate; 162 prefixes have no coordinates and centroids average several raw points.
- **Data anomalies retained.** 1,388 delivered orders with inconsistent timestamps are excluded from stage timing but included in total-delivery KPIs if they have a delivery date.
- **No demand-side data.** Without traffic, conversion or marketing data, the analysis cannot explain *why* growth plateaued — only that it did.
- **Supplemented translations.** Two category translations were added by the analyst and are flagged.

---

## 23. Conclusion

This project turns nine raw Olist files into a validated relational MySQL database with enforced keys, documented cleaning and a two-grain analytical layer that structurally prevents join inflation — an error shown to overstate revenue by 5% and payments by 29%.

On that foundation, the analysis shows that Olist's next phase of growth will not come from acquisition alone. The data points to three levers a Sales Director can act on: **delivery reliability** (the factor most strongly associated with satisfaction), **seller and regional supply quality** (which drives delivery speed, freight cost and reviews), and **retention** (where almost all customers are lost after one order). Because every metric is reproducible from SQL views, these KPIs can be refreshed monthly and used to track whether interventions — carrier SLAs, seller scorecards, retention campaigns — actually move the numbers.

---

*Reproduce: `bash run_all.sh` (MySQL 8.0 with `local_infile=1`; set the CSV path in `sql/01_staging_load.sql`). Then `python3 build_report.py` regenerates this README from fresh query output.*
