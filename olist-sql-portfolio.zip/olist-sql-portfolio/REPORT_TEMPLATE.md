# Olist E-Commerce Sales & Customer Performance Analysis

**Domain:** E-commerce / Retail Analytics · **Audience:** Sales Director / E-commerce Manager · **Database:** MySQL 8.0 · **Type:** Multi-table SQL data modelling and advanced business analytics

Every number in this document was produced by executing the SQL in `/sql` against MySQL 8.0.46 loaded with the nine original Olist CSV files. Result tables are inserted programmatically from the query output (`build_report.py`), not typed by hand.

---

## Contents

1. [Executive summary](#1-executive-summary)
2. [Dataset overview](#2-dataset-overview)
3. [Data dictionary](#3-data-dictionary)
4. [Key assessment](#4-key-assessment)
5. [Data quality assessment](#5-data-quality-assessment)
6. [SQL cleaning](#6-sql-cleaning)
7. [ER diagram and relational model](#7-er-diagram-and-relational-model)
8. [Relationship validation and join inflation](#8-relationship-validation-and-join-inflation)
9. [Analytical layer (views)](#9-analytical-layer-views)
10. [10 KPIs](#10-ten-kpis)
11. [10 univariate analyses](#11-ten-univariate-analyses)
12. [10 bivariate analyses](#12-ten-bivariate-analyses)
13. [10 multivariate analyses](#13-ten-multivariate-analyses)
14. [Customer analysis](#14-customer-analysis)
15. [Product analysis](#15-product-analysis)
16. [Seller performance](#16-seller-performance)
17. [Delivery and customer satisfaction](#17-delivery-and-customer-satisfaction)
18. [Time-series analysis](#18-time-series-analysis)
19. [Advanced SQL coverage](#19-advanced-sql-coverage)
20. [Key insights](#20-key-insights)
21. [Business recommendations](#21-business-recommendations)
22. [Limitations](#22-limitations)
23. [Conclusion](#23-conclusion)

---

## 1. Executive summary

Olist delivered **96,478 orders worth R$13.22M in product revenue** (R$15.42M including freight) to **93,358 unique customers** between September 2016 and August 2018. Growth was very strong through 2017 but **plateaued in 2018**: monthly revenue has hovered between roughly R$0.83M and R$0.98M since January 2018, and year-on-year growth fell from +727% in January to +51% in August.

Three findings matter most for management:

- **Delivery reliability is the single strongest correlate of customer satisfaction.** Orders delivered on time average 4.29 stars; late orders average 2.27, and 62.4% of late orders receive a 1–2 star review. The satisfaction dips in Nov 2017 and Feb–Mar 2018 coincide exactly with late-delivery spikes (up to 19% late).
- **Geography drives cost and experience.** 64% of revenue is shipped by São Paulo sellers. Customers in the Northeast wait 20 days on average (vs 8.8 in SP), pay 21.7% of the product value in freight (vs 13.9%), and rate Olist lower.
- **Olist is almost entirely a first-purchase business.** Only 3.0% of customers ordered more than once, and repeat customers generate just 5.5% of revenue. Retention is the largest untapped growth lever.

Revenue is concentrated: 18 of 74 categories produce 80% of revenue, the top 10% of sellers produce 67%, and the top 10% of customers produce 41%.

---

## 2. Dataset overview

Nine CSV files were supplied. Row counts below are records as loaded by MySQL (`01_staging_load.sql`) and reconciled against an independent pandas parse.

| File | Records | Columns | Grain |
|---|---|---|---|
| `olist_orders_dataset.csv` | 99,441 | 8 | one row per order |
| `olist_customers_dataset.csv` | 99,441 | 5 | one row per order-level customer key |
| `olist_order_items_dataset.csv` | 112,650 | 7 | one row per item line in an order |
| `olist_order_payments_dataset.csv` | 103,886 | 5 | one row per payment record of an order |
| `olist_order_reviews_dataset.csv` | **99,224** | 7 | one row per (review, order) pair |
| `olist_products_dataset.csv` | 32,951 | 9 | one row per product |
| `olist_sellers_dataset.csv` | 3,095 | 4 | one row per seller |
| `olist_geolocation_dataset.csv` | 1,000,163 | 5 | one row per raw geocoded point (not unique per ZIP) |
| `product_category_name_translation.csv` | 71 | 2 | one row per Portuguese category |

Load reconciliation (`01_staging_load.sql`):

{{T:LD01_load_reconciliation}}

**Correction to the brief — reviews row count.** The reviews file has 104,720 physical lines but only **99,224 records**: free-text comments contain line breaks inside quoted fields. "104,719 rows" is a line count, not a record count.

**Load issue found and fixed.** One review comment ends with a literal backslash (`…não chegou nada :\"`). With MySQL's default `ESCAPED BY '\\'`, the sequence `\"` is read as an escaped quote and two reviews merge into one (99,223 loaded). Every load therefore uses `ESCAPED BY ''`, because the files do not use backslash escaping.

**Column-name note.** The products file genuinely uses the misspelled names `product_name_lenght` and `product_description_lenght`; the project keeps them verbatim so every query matches the source.

**Time coverage.** Purchases run from 2016-09-04 to 2018-10-17, but volumes are sparse at both ends (4 orders in Sep 2016, none in Nov 2016, 1 in Dec 2016, 16 in Sep 2018 and 4 in Oct 2018). Trend analyses therefore use the **20 complete trading months Jan 2017 – Aug 2018**.

{{T:DQ15_monthly_order_volume}}

### Project files

| File | Purpose |
|---|---|
| `sql/01_staging_load.sql` | Raw staging tables (all text) and `LOAD DATA` |
| `sql/02_data_quality.sql` | 23 profiling checks on the raw layer |
| `sql/03_clean_model.sql` | Cleaning rules and the constrained relational schema |
| `sql/04_relationship_validation.sql` | Relationship checks and join-inflation proof |
| `sql/05_views.sql` | Analytical views and `fact_order` |
| `sql/06_kpis.sql` | 10 KPIs |
| `sql/07_univariate.sql` / `08_bivariate.sql` / `09_multivariate.sql` | 10 + 10 + 10 analyses |
| `sql/10_deep_dives.sql` | Customer, product, seller, delivery, time-series deep dives |
| `schema/olist_schema.sql` | `mysqldump --no-data` of the final schema |
| `results/*.md` | Raw query outputs |
| `run_all.sh` | Rebuilds everything end-to-end |

---

## 3. Data dictionary

Generated from `information_schema` of the cleaned `olist` database.

{{DICT}}

---

## 4. Key assessment

### Candidate-key tests

A column (or column set) is a valid key only if `COUNT(DISTINCT key) = COUNT(*)`.

{{S:DQ05_key_uniqueness}}

{{T:DQ05_key_uniqueness}}

### Conclusions

| Table | Grain | Primary key | Why |
|---|---|---|---|
| orders | order | `order_id` | unique |
| customers | order-level customer | `customer_id` | unique; `customer_unique_id` repeats (96,096 distinct) |
| order_items | item line | (`order_id`, `order_item_id`) | `order_item_id` is a 1..n sequence per order, unique only with `order_id` |
| order_payments | payment record | (`order_id`, `payment_sequential`) | 2,961 orders have several payments |
| order_reviews | review–order pair | (`review_id`, `order_id`) | `review_id` alone repeats (98,410 distinct of 99,224) |
| products | product | `product_id` | unique |
| sellers | seller | `seller_id` | unique |
| category_translation | category | `product_category_name` | unique |
| geolocation | raw point | **none as supplied** | 1,000,163 rows, 19,015 ZIP prefixes; aggregated into `zip_code` |

**`customer_id` vs `customer_unique_id`.** `orders.customer_id` is also unique (99,441 distinct), so every `customer_id` belongs to exactly one order: Olist issues a new `customer_id` per order. The person is `customer_unique_id`. Counting `customer_id` overstates delivered customers by 3,120.

{{T:DQ07_customer_unique_id_distribution}}

### Relationship specification

```
customers (customer_unique_id = person)
   │ 1:1 on customer_id
orders ──1:M── order_items ──M:1── products ──M:1── category_translation
   │                 └──────M:1── sellers
   ├──1:M── order_payments
   └──1:M── order_reviews        (≈1:1 in practice; 547 orders have 2–3)

customers ──M:1── zip_code ──1:M── sellers      (geography dimension)
```

| Relationship | Cardinality | Explanation |
|---|---|---|
| customers → orders | **1 : 1** (on `customer_id`) | each order gets its own `customer_id`; enforced by `UNIQUE(orders.customer_id)` |
| customer_unique_id → orders | 1 : M | the real person can place many orders (max 17 per person) |
| orders → order_items | 1 : 0..M | 775 orders (mostly `unavailable`/`canceled`) have no items |
| order_items → products | M : 1 | every item references a product |
| order_items → sellers | M : 1 | every item references a seller; 1,278 orders involve 2+ sellers |
| orders → order_payments | 1 : 0..M | 1 order has no payment record |
| orders → order_reviews | 1 : 0..M | 768 orders have no review, 547 have more than one |
| products → category_translation | M : 0..1 | 610 products have no category |
| customers / sellers → zip_code | M : 1 | after aggregating geolocation to one row per prefix |

**No many-to-many relationships are forced.** Products ↔ sellers and orders ↔ sellers are genuinely M:M, but both are already resolved by `order_items`, which acts as the associative table.

---

## 5. Data quality assessment

All checks run on the raw staging layer, where missing values are empty strings.

### 5.1 Missing values

{{S:DQ01_missing_orders}}

{{T:DQ01_missing_orders}}

Missing order timestamps are **structurally expected**, not errors: undelivered orders cannot have a delivery date. The status-by-timestamp matrix confirms this, and isolates the true anomalies: 8 `delivered` orders with no delivery date, 14 `delivered` orders with no approval time, and 6 `canceled` orders that do have a delivery date.

{{T:DQ14_status_vs_timestamps}}

{{T:DQ02_missing_products}}

The same 610 products are missing category, name length, description length and photo count — one block of incomplete catalogue records, not random gaps. They are still sold products, so they are kept.

{{T:DQ03_missing_reviews}}

Comments are optional: 88% of reviews have no title and 59% no message. The score is always present, so every review row is analytically valid.

{{T:DQ04_missing_other_tables}}

### 5.2 Duplicates

{{T:DQ06_full_row_duplicates}}

Only geolocation contains exact duplicate rows (279,667). No transactional table has a duplicated row.

{{T:DQ08_review_grain}}

These are not duplicate rows (every (review_id, order_id) pair is unique) but **grain anomalies**: 547 orders have several reviews and 202 of them have conflicting scores. Joining reviews directly to orders would therefore double-count those orders; the model uses the latest review per order.

{{T:DQ09_rows_per_order}}

### 5.3 Data types, dates and numeric validity

All timestamps parse cleanly with `STR_TO_DATE` — there are no malformed dates.

{{T:DQ12_date_parse_check}}

{{T:DQ13_chronology_violations}}

1,359 orders record a carrier hand-over **before** payment approval and 166 before the purchase itself; 23 are delivered before reaching the carrier. These are system-logging inconsistencies. The records are kept, but they are excluded from stage-duration analysis via the `valid_delivery_chain` flag.

{{T:DQ10_numeric_ranges}}

{{T:DQ11_payment_type_values}}

Findings: 383 item lines with zero freight (valid — free shipping), 9 zero-value payments (6 vouchers, 3 `not_defined`), 2 credit-card payments with 0 instalments (impossible), and 4 products weighing 0 g (impossible). Prices are all positive.

### 5.4 Category and geographic consistency

{{T:DQ16_untranslated_categories}}

{{T:DQ17_geolocation_profile}}

The database's default collation (`utf8mb4_0900_ai_ci`) is **accent-insensitive**, so a normal `GROUP BY` silently merges "são paulo" into "sao paulo" and hides the problem. Grouping with a binary collation exposes the real variants, including mojibake:

{{S:DQ18_city_spelling_variants_example}}

{{T:DQ18_city_spelling_variants_example}}

Seller cities contain free-text errors — state suffixes, full addresses, an e-mail address and a number:

{{T:DQ19_dirty_seller_cities}}

### 5.5 Orphans and referential integrity

{{S:DQ20_orphan_summary}}

{{T:DQ20_orphan_summary}}

{{T:DQ21_parents_without_children}}

{{T:DQ22_orders_without_items_by_status}}

All transactional foreign keys are clean. The only unmatched references are 13 products in two untranslated categories and 285 customer/seller rows whose ZIP prefix does not exist in geolocation.

### 5.6 Cross-table reconciliation

{{T:DQ23_items_vs_payments_reconciliation}}

For 99.6% of orders, payments equal price + freight to the centavo. The 380 mismatches are consistent with instalment interest (overpayment) or vouchers/partial records (underpayment). This is why revenue is measured from `order_items.price`, not from payments.

---

## 6. SQL cleaning

`03_clean_model.sql` builds a typed, constrained database (`olist`) from staging. Principles: **no valid record deleted for containing NULLs; blanks become NULL, never fake values; only true duplicates removed; every rule documented and flagged.**

| # | Issue | Decision | Rows |
|---|---|---|---|
| 1 | All columns loaded as text | Cast to `CHAR(32) ascii_bin` IDs, `DATETIME`, `DECIMAL(10,2)`, `ENUM`, small unsigned ints | all |
| 2 | Blank timestamps (orders) | `NULLIF(...,'')` → NULL; rows kept | 4,908 cells |
| 3 | Chronology anomalies | Kept; flagged in view (`valid_delivery_chain`) | 1,388 delivered orders excluded from stage timing |
| 4 | Products missing category | Kept with NULL FK; labelled `uncategorized` in `v_product` | 610 |
| 5 | Products weighing 0 g | Set to NULL, flagged `weight_was_zero` | 4 |
| 6 | Categories missing from translation file | Added 2 rows with `is_supplemented = 1` | 13 products |
| 7 | 0 instalments | Recoded to 1, flagged `installments_recoded` | 2 |
| 8 | Zero-value payments | Kept (real records, no revenue effect) | 9 |
| 9 | Blank review comments | NULL; rows kept (score valid) | 58,256 messages* |
| 10 | Multiple reviews per order | Rows kept; latest review chosen with `ROW_NUMBER()` in views | 547 orders |
| 11 | Geolocation duplicates / out-of-Brazil points / non-unique ZIP | De-duplicated, filtered, aggregated to one row per prefix | 1,000,163 → 19,015 |
| 12 | ZIPs used by customers/sellers but absent from geolocation | Added to `zip_code` with `has_geolocation = 0` so FKs hold | 162 prefixes |
| 13 | City spelling (accents, mojibake, free text) | `fn_std_city()` + seller-specific parsing | see below |
| 14 | Status/state/category text | `LOWER/UPPER(TRIM())` | all |

\*58,247 raw blanks plus 9 whitespace-only messages that became blank after `TRIM`.

### City standardisation function

```sql
CREATE FUNCTION fn_std_city(s VARCHAR(200)) RETURNS VARCHAR(200)
DETERMINISTIC NO SQL
BEGIN
  DECLARE r VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;
  IF s IS NULL OR TRIM(s) = '' THEN RETURN NULL; END IF;
  SET r = LOWER(TRIM(s));
  SET r = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(r,'á','a'),'à','a'),'â','a'),'ã','a'),'ä','a');
  -- … same for e, i, o, u, ç, ñ …
  SET r = REPLACE(REPLACE(REPLACE(r,'´',''''),'`',''''),'£','');
  WHILE INSTR(r,'  ') > 0 DO SET r = REPLACE(r,'  ',' '); END WHILE;
  RETURN TRIM(r);
END
```

### Geolocation → `zip_code` dimension

```sql
INSERT INTO zip_code
WITH dedup AS (                                  -- (a) exact duplicates removed
  SELECT DISTINCT geolocation_zip_code_prefix AS zip,
         CAST(geolocation_lat AS DECIMAL(18,14)) AS lat,
         CAST(geolocation_lng AS DECIMAL(18,14)) AS lng,
         fn_std_city(geolocation_city)          AS city,
         UPPER(TRIM(geolocation_state))         AS state
  FROM olist_stg.stg_geolocation
),
valid AS (                                       -- (b) inside Brazil only
  SELECT * FROM dedup
  WHERE lat BETWEEN -33.75 AND 5.27 AND lng BETWEEN -73.99 AND -34.79
),
centroid AS (                                    -- (c) one row per prefix
  SELECT zip, AVG(lat) AS lat, AVG(lng) AS lng, COUNT(*) AS pts
  FROM valid GROUP BY zip
),
modal_city AS (
  SELECT zip, city, state,
         ROW_NUMBER() OVER (PARTITION BY zip ORDER BY COUNT(*) DESC, city) AS rn
  FROM dedup GROUP BY zip, city, state
)
SELECT m.zip, c.lat, c.lng, m.city, m.state, COALESCE(c.pts, 0), 1
FROM modal_city m
LEFT JOIN centroid c ON c.zip = m.zip
WHERE m.rn = 1;
```

### Cleaning audit

{{T:CL01_row_reconciliation}}

Every transactional and master table keeps **100% of its rows**. Only geolocation shrinks, by design (raw points → one row per ZIP prefix).

{{T:CL02_zip_code_dimension}}

{{T:CL03_city_standardisation_effect}}

Customer cities were already clean (no change); geolocation city variants fell from 8,010 to 5,771 and seller cities from 611 to 584.

{{T:CL04_seller_city_fixes}}

{{T:CL05_flags_set}}

---

## 7. ER diagram and relational model

```mermaid
erDiagram
    CUSTOMERS ||--|| ORDERS : "places (customer_id, 1:1)"
    ORDERS ||--o{ ORDER_ITEMS : contains
    ORDERS ||--o{ ORDER_PAYMENTS : "paid by"
    ORDERS ||--o{ ORDER_REVIEWS : "reviewed in"
    PRODUCTS ||--o{ ORDER_ITEMS : "sold as"
    SELLERS ||--o{ ORDER_ITEMS : fulfils
    CATEGORY_TRANSLATION |o--o{ PRODUCTS : classifies
    ZIP_CODE ||--o{ CUSTOMERS : locates
    ZIP_CODE ||--o{ SELLERS : locates

    CUSTOMERS {
        char32 customer_id PK
        char32 customer_unique_id "person key, indexed"
        char5 customer_zip_code_prefix FK
        varchar customer_city
        char2 customer_state
    }
    ORDERS {
        char32 order_id PK
        char32 customer_id FK "UNIQUE"
        enum order_status
        datetime order_purchase_timestamp
        datetime order_approved_at
        datetime order_delivered_carrier_date
        datetime order_delivered_customer_date
        datetime order_estimated_delivery_date
    }
    ORDER_ITEMS {
        char32 order_id PK,FK
        tinyint order_item_id PK
        char32 product_id FK
        char32 seller_id FK
        datetime shipping_limit_date
        decimal price
        decimal freight_value
    }
    ORDER_PAYMENTS {
        char32 order_id PK,FK
        tinyint payment_sequential PK
        enum payment_type
        tinyint payment_installments
        decimal payment_value
    }
    ORDER_REVIEWS {
        char32 review_id PK
        char32 order_id PK,FK
        tinyint review_score
        varchar review_comment_title
        text review_comment_message
        datetime review_creation_date
        datetime review_answer_timestamp
    }
    PRODUCTS {
        char32 product_id PK
        varchar product_category_name FK
        smallint product_name_lenght
        smallint product_description_lenght
        tinyint product_photos_qty
        int product_weight_g
        smallint product_length_cm
        smallint product_height_cm
        smallint product_width_cm
    }
    SELLERS {
        char32 seller_id PK
        char5 seller_zip_code_prefix FK
        varchar seller_city
        char2 seller_state
    }
    CATEGORY_TRANSLATION {
        varchar product_category_name PK
        varchar product_category_name_english
    }
    ZIP_CODE {
        char5 zip_code_prefix PK
        decimal latitude
        decimal longitude
        varchar geo_city
        char2 geo_state
    }
```

### Relational model specification

| Table | Primary key | Foreign key(s) | Relationship | Cardinality | Business purpose |
|---|---|---|---|---|---|
| `orders` | `order_id` | `customer_id` → customers (UNIQUE) | order belongs to one order-level customer | 1 : 1 | central fact: status, timeline, promise |
| `customers` | `customer_id` | `customer_zip_code_prefix` → zip_code | customer located in one ZIP | M : 1 | who bought, where; `customer_unique_id` identifies the person |
| `order_items` | (`order_id`, `order_item_id`) | `order_id` → orders; `product_id` → products; `seller_id` → sellers | lines of an order; resolves orders↔products↔sellers M:M | orders 1 : M items; items M : 1 product / seller | revenue, units, freight |
| `order_payments` | (`order_id`, `payment_sequential`) | `order_id` → orders | how an order was paid | orders 1 : M payments | payment mix, instalments |
| `order_reviews` | (`review_id`, `order_id`) | `order_id` → orders | customer feedback on an order | orders 1 : M reviews | satisfaction |
| `products` | `product_id` | `product_category_name` → category_translation (nullable) | product classified in ≤1 category | M : 0..1 | catalogue attributes |
| `sellers` | `seller_id` | `seller_zip_code_prefix` → zip_code | seller located in one ZIP | M : 1 | marketplace supply |
| `category_translation` | `product_category_name` | — | lookup | 1 : M products | English reporting labels |
| `zip_code` | `zip_code_prefix` | — | geography dimension | 1 : M customers / sellers | coordinates, region mapping |

All nine foreign keys are **declared and enforced by InnoDB**. Because the data was inserted after the constraints were created, a successful load is itself proof of referential integrity.

{{T:RV01_enforced_foreign_keys}}

{{T:RV02_primary_keys}}

The full DDL is in `schema/olist_schema.sql`.

---

## 8. Relationship validation and join inflation

### 8.1 Validation queries

**Orders → Customers**

{{S:RV03_orders_customers}}

{{T:RV03_orders_customers}}

Every order has a customer and every `customer_id` has exactly one order (confirming 1:1); one person (`customer_unique_id`) has up to 17 orders (confirming 1:M at person level).

**Orders → Order Items**

{{S:RV04_orders_items}}

{{T:RV04_orders_items}}

775 orders have no items, but **none of them is delivered** — 767 are unavailable or cancelled and 8 are stuck in created/invoiced/shipped, all with no sales value, so analyses use `LEFT JOIN` from orders where they must be counted (status mix) and an implicit inner join where only sales matter.

**Order Items → Products / Sellers**

{{T:RV05_items_products_sellers}}

**Orders → Payments**

{{T:RV06_orders_payments}}

One delivered order (`bfbd0f9b…`) has items but no payment record. It is kept: product revenue comes from items, so it contributes R$134.97 of revenue but nothing to payment totals — one reason total payment value and GMV do not match exactly in KPI 1.

**Orders → Reviews**

{{T:RV07_orders_reviews}}

768 orders have no review (treated as NULL, never as zero) and 547 have several (resolved to the latest).

**Products → Category translation**

{{T:RV08_products_categories}}

After supplementing two translations, no product has an untranslated category; 610 have no category at all and are reported as `uncategorized`.

**Geography coverage**

{{T:RV09_geography_coverage}}

### 8.2 Join inflation — demonstrated and prevented

`order_items`, `order_payments` and `order_reviews` each have **many rows per `order_id`**. Joining them together multiplies rows: an order with 3 items, 2 payments and 2 reviews produces 3 × 2 × 2 = 12 rows, so its price is summed 4 times and its payments 6 times.

The query below calculates delivered revenue both ways.

{{S:RV10_join_inflation_wrong_vs_right}}

{{T:RV10_join_inflation_wrong_vs_right}}

The naive join **overstates revenue by R$654,974 (+5.0%) and payments by R$4,459,483 (+28.9%)**, while `COUNT(DISTINCT order_id)` looks perfectly correct — which is exactly why this error goes unnoticed. The fix is to **aggregate each child table to order grain in its own CTE, then join 1:1**.

Worst individual cases:

{{T:RV11_worst_inflated_order}}

One order with 29 payment records would report R$11,383.95 instead of R$392.55.

---

## 9. Analytical layer (views)

`05_views.sql` creates a reusable layer with **two grains that are never mixed**:

- `v_order_summary` — exactly one row per order. Items, payments and reviews are each aggregated in a separate CTE before joining; the latest review per order is chosen with `ROW_NUMBER()`. Also derives delivery days, delay vs estimate, `is_late` and `valid_delivery_chain`.
- `v_item_detail` — exactly one row per item line, enriched only through M:1 joins (order, customer, product, seller), so `SUM(price)` is always safe.
- `v_product` — products with an English category label, never NULL.
- `fact_order` — an indexed table materialised from `v_order_summary` (MySQL has no materialised views) for fast repeated analysis.

### Metric definitions used throughout

| Metric | Definition |
|---|---|
| **Revenue** | `SUM(order_items.price)` on **delivered** orders — product sales value, excluding freight |
| Freight | `SUM(order_items.freight_value)`, reported separately |
| GMV incl. freight | Revenue + freight |
| Payment value | `SUM(order_payments.payment_value)` (includes freight, instalment interest, vouchers) |
| Order review | latest review per order |
| Delivery days | purchase → customer delivery, in days (minute precision) |
| Late | delivered **date** > estimated delivery **date** |
| Customer | `customer_unique_id` |

```sql
CREATE OR REPLACE VIEW v_order_summary AS
WITH item_agg AS (
  SELECT order_id, COUNT(*) AS items, COUNT(DISTINCT product_id) AS distinct_products,
         COUNT(DISTINCT seller_id) AS distinct_sellers,
         SUM(price) AS item_revenue, SUM(freight_value) AS freight
  FROM order_items GROUP BY order_id
),
pay_agg AS (
  SELECT order_id, SUM(payment_value) AS payment_value, COUNT(*) AS payment_rows,
         MAX(payment_installments) AS max_installments,
         SUBSTRING_INDEX(GROUP_CONCAT(payment_type ORDER BY payment_value DESC, payment_sequential), ',', 1)
           AS main_payment_type
  FROM order_payments GROUP BY order_id
),
review_ranked AS (
  SELECT order_id, review_score,
         ROW_NUMBER() OVER (PARTITION BY order_id
                            ORDER BY review_answer_timestamp DESC, review_creation_date DESC, review_id) AS rn
  FROM order_reviews
)
SELECT o.order_id, o.customer_id, c.customer_unique_id, c.customer_city, c.customer_state,
       o.order_status, o.order_purchase_timestamp, /* … timestamps … */
       COALESCE(ia.items, 0) AS items, COALESCE(ia.item_revenue, 0) AS item_revenue,
       COALESCE(ia.freight, 0) AS freight, pa.payment_value, pa.main_payment_type,
       pa.max_installments, rr.review_score,
       ROUND(TIMESTAMPDIFF(MINUTE, o.order_purchase_timestamp, o.order_delivered_customer_date) / 1440, 2) AS delivery_days,
       DATEDIFF(o.order_delivered_customer_date, o.order_estimated_delivery_date) AS delay_days,
       CASE WHEN o.order_delivered_customer_date IS NULL THEN NULL
            WHEN DATE(o.order_delivered_customer_date) > DATE(o.order_estimated_delivery_date) THEN 1
            ELSE 0 END AS is_late
       /* … valid_delivery_chain flag … */
FROM orders o
JOIN customers c           ON c.customer_id = o.customer_id
LEFT JOIN item_agg ia      ON ia.order_id = o.order_id
LEFT JOIN pay_agg pa       ON pa.order_id = o.order_id
LEFT JOIN review_ranked rr ON rr.order_id = o.order_id AND rr.rn = 1;
```

### View validation

{{T:VW01_view_grain_checks}}

{{T:VW02_revenue_tie_out}}

Revenue ties out to the centavo across the order grain, the item grain and the base tables.

{{T:VW03_delivery_chain_quality}}

---

## 10. Ten KPIs

Scope: delivered orders (realised sales) unless stated.

### KPI 1 — Total Revenue
**Definition:** `SUM(price)` on delivered orders; freight, GMV and payments shown alongside. **Business purpose:** headline measure of realised sales.

{{S:KPI01_total_revenue}}

{{T:KPI01_total_revenue}}

**Interpretation:** R$13.22M of product revenue plus R$2.20M of freight. Payments exceed GMV by only R$2,688, confirming the two sources reconcile.

### KPI 2 — Total Orders
**Definition:** all orders and delivered orders. **Business purpose:** volume and fulfilment health.

{{S:KPI02_total_orders}}

{{T:KPI02_total_orders}}

**Interpretation:** 97.0% of orders are delivered; 1.2% are cancelled or unavailable. The remaining ~1.7% were still in progress (mostly `shipped`) when the snapshot was taken.

### KPI 3 — Unique Customers
**Definition:** `COUNT(DISTINCT customer_unique_id)` on delivered orders. **Business purpose:** size of the active customer base.

{{S:KPI03_unique_customers}}

{{T:KPI03_unique_customers}}

**Interpretation:** 93,358 real customers. Using `customer_id` would overstate the base by 3,120 (3.3%) and make repeat behaviour invisible.

### KPI 4 — Average Order Value
**Definition:** revenue ÷ delivered orders. **Business purpose:** basket size; lever for revenue growth without more customers.

{{S:KPI04_average_order_value}}

{{T:KPI04_average_order_value}}

**Interpretation:** R$137.04 per order in product value (R$159.83 including freight). The median order is only R$86.57 (U1), so the mean is pulled up by a long tail of expensive orders.

### KPI 5 — Total Items Sold
**Definition:** item lines on delivered orders. **Business purpose:** unit volume and basket depth.

{{S:KPI05_items_sold}}

{{T:KPI05_items_sold}}

**Interpretation:** 110,197 items; 90% of orders contain a single item. Cross-selling is almost absent.

### KPI 6 — Average Freight Cost
**Definition:** freight per order, per item, and as % of revenue. **Business purpose:** shipping cost burden on the customer.

{{S:KPI06_freight}}

{{T:KPI06_freight}}

**Interpretation:** customers pay R$22.79 per order in freight — **16.6% on top of the product price**, a material conversion barrier.

### KPI 7 — Average Review Score
**Definition:** mean of the latest review per order (all reviewed orders). **Business purpose:** customer satisfaction.

{{S:KPI07_review_score}}

{{T:KPI07_review_score}}

**Interpretation:** 4.09 / 5, with 77% positive but a sizeable 14.7% negative (1–2 stars).

### KPI 8 — Active Sellers
**Definition:** sellers with ≥1 delivered item. **Business purpose:** marketplace supply breadth.

{{S:KPI08_active_sellers}}

{{T:KPI08_active_sellers}}

**Interpretation:** 2,970 of 3,095 registered sellers made at least one delivered sale; average revenue per active seller is R$4,452 over the period — but this average hides heavy concentration (S2).

### KPI 9 — Average Delivery Time
**Definition:** purchase → customer delivery in days; median and 90th percentile via `ROW_NUMBER()`. **Business purpose:** speed of service.

{{S:KPI09_delivery_time}}

{{T:KPI09_delivery_time}}

**Interpretation:** mean 12.6 days, median 10.2; 1 in 10 orders takes more than 23 days.

### KPI 10 — On-Time Delivery Rate
**Definition:** share of delivered orders arriving on or before the estimated date. **Business purpose:** reliability of the delivery promise.

{{S:KPI10_on_time_rate}}

{{T:KPI10_on_time_rate}}

**Interpretation:** 93.2% on time, and on average orders arrive 11.9 days **before** the estimate — Olist's promise is very conservative, yet 6,534 orders still missed it.

### Executive scorecard (one query, scalar subqueries)

{{S:KPI11_executive_scorecard}}

{{T:KPI11_executive_scorecard}}

---

## 11. Ten univariate analyses

### U1 — Order value
**Business question:** what does a typical order look like, and where does revenue come from? **Purpose:** pricing, promotions and free-shipping thresholds.

{{S:U01_order_value_distribution}}

{{T:U01_order_value_distribution}}

{{T:U01b_order_value_summary_stats}}

**Interpretation:** 58.6% of orders are under R$100 but generate only 22.8% of revenue; orders of R$500+ are 3.6% of orders but 24.6% of revenue. The distribution is strongly right-skewed (mean 137 vs median 87). **Recommendation:** manage the high-value tail as a distinct segment (service, instalments, fraud checks) and use bundles to lift sub-R$100 baskets.

### U2 — Product categories by items sold
**Business question:** which categories move the most units? **Purpose:** assortment and inventory focus.

{{S:U02_category_item_share}}

{{T:U02_category_item_share}}

{{T:U02b_category_count}}

**Interpretation:** 74 categories sell, but the top 7 account for over half of all items; bed_bath_table alone is ~10%. **Recommendation:** prioritise seller acquisition and merchandising in these core categories.

### U3 — Order status
**Business question:** how many orders fail or are stuck? **Purpose:** operational health.

{{S:U03_order_status}}

{{T:U03_order_status}}

**Interpretation:** 97% delivered; 1,234 orders (1.2%) were cancelled or unavailable — 603 "unavailable" orders never even received items, i.e. stock-outs after purchase. **Recommendation:** enforce real-time stock sync for sellers to eliminate "unavailable" orders.

### U4 — Payment methods
**Business question:** how do customers pay? **Purpose:** checkout and payment-partner strategy.

{{S:U04_payment_methods}}

{{T:U04_payment_methods}}

**Interpretation:** credit card carries 78% of value; boleto (bank slip) 18%. Debit card is marginal. **Recommendation:** keep checkout optimised for credit card with instalments, and preserve boleto for unbanked customers.

### U5 — Review scores
**Business question:** how satisfied are customers? **Purpose:** service quality baseline.

{{S:U05_review_scores}}

{{T:U05_review_scores}}

**Interpretation:** bimodal — 57.8% give 5 stars but 11.5% give 1 star, far more than 2 or 3 stars. Customers are either happy or very unhappy; the drivers of 1-star reviews are investigated in B5 and section 17.

### U6 — Freight per order
**Business question:** how much do customers pay for shipping? **Purpose:** freight policy.

{{S:U06_freight_distribution}}

{{T:U06_freight_distribution}}

**Interpretation:** 54% of orders pay R$10–20; free shipping is almost non-existent (0.35%). 6.3% pay R$50 or more.

### U7 — Customer geography
**Business question:** where are customers? **Purpose:** regional marketing and logistics planning.

{{S:U07_customers_by_state}}

{{T:U07_customers_by_state}}

**Interpretation:** São Paulo state alone holds 42% of unique customers; SP, RJ and MG together hold 67%.

### U8 — Seller geography
**Business question:** where is supply located? **Purpose:** compare supply with demand.

{{S:U08_sellers_by_state}}

{{T:U08_sellers_by_state}}

**Interpretation:** 60% of sellers are in SP and 90.6% in five southern/south-eastern states. Supply is far more concentrated than demand — the root of the long cross-state deliveries in M7 and M9.

### U9 — Credit-card instalments
**Business question:** how many instalments do card payers use? **Purpose:** instalment offer design.

{{S:U09_installments}}

{{T:U09_installments}}

**Interpretation:** two-thirds of card payments use instalments, and value rises steeply with instalment count (R$96 at 1x vs R$334 at 7–10x).

### U10 — Delivery duration
**Business question:** how long do customers wait? **Purpose:** service-level setting.

{{S:U10_delivery_duration}}

{{T:U10_delivery_duration}}

**Interpretation:** only 27% of orders arrive within a week; 13% take three weeks or more.

---

## 12. Ten bivariate analyses

### B1 — Product category × revenue
**Business question:** which categories make the money? **Purpose:** category investment priorities.

{{S:B01_category_revenue}}

{{T:B01_category_revenue}}

**Interpretation:** health_beauty (9.3%) and watches_gifts (8.8%) lead revenue; watches_gifts ranks 7th in units but 2nd in revenue because of a high average price (B10). **Recommendation:** protect these two categories with seller-quality programmes and featured placement.

### B2 — Customer state × revenue
**Business question:** which states generate revenue, and how valuable is each customer? **Purpose:** regional targeting.

{{S:B02_customer_state_revenue}}

{{T:B02_customer_state_revenue}}

**Interpretation:** SP is 38% of revenue but has the **lowest** revenue per customer of the top 12 states (R$129); north-eastern customers (CE R$175, PE R$162, BA R$156) spend more per head.

### B3 — Seller × revenue
**Business question:** who are the biggest sellers? **Purpose:** key-account management.

{{S:B03_top_sellers}}

{{T:B03_top_sellers}}

**Interpretation:** no single seller exceeds 1.8% of revenue — low single-seller risk — but the top 10 together contribute about 13%. Revenue does not equal order volume: seller #2 (BA) earns R$218k from only 348 orders.

### B4 — Product category × review score
**Business question:** which categories disappoint customers? **Purpose:** quality interventions. Grain is (order, category) so multi-item orders are not over-weighted.

{{S:B04_category_review}}

{{T:B04_category_review}}

**Interpretation:** office_furniture is the clear outlier (3.65, 22% negative), followed by bed_bath_table (4.00) — the #3 revenue category. **Recommendation:** audit office_furniture sellers and delivery (heavy, high freight — see B7/M10) and bed_bath_table product-description accuracy.

### B5 — Delivery delay × review score
**Business question:** how does delivery timing relate to satisfaction? **Purpose:** quantify the value of reliability.

{{S:B05_delay_review}}

{{T:B05_delay_review}}

**Interpretation:** reviews are stable at 4.2–4.3 for early deliveries, fall sharply from the first late day (3.29 at 1–3 days late) and collapse to ~1.7 with 59–71% one-star once orders are 4+ days late. This is the strongest pattern in the dataset (association, not proven causation — see section 17).

### B6 — Payment type × order value
**Business question:** does payment method relate to basket size? **Purpose:** payment promotion strategy.

{{S:B06_payment_type_order_value}}

{{T:B06_payment_type_order_value}}

**Interpretation:** credit-card orders are ~18% larger than boleto orders in product value (R$143 vs R$121); 64% of voucher orders are split with another method.

### B7 — Freight × product category
**Business question:** where is freight disproportionate to product value? **Purpose:** freight subsidy and pricing.

{{S:B07_category_freight}}

{{T:B07_category_freight}}

**Interpretation:** electronics pays 29.5% of the price in freight (cheap, light items), office_furniture 25% (heavy items); watches_gifts only 8.4%. **Recommendation:** target freight subsidies or minimum-basket offers at low-price, high-freight-ratio categories.

### B8 — Seller state × sales
**Business question:** where is revenue shipped from? **Purpose:** supply-side regional strategy.

{{S:B08_seller_state_sales}}

{{T:B08_seller_state_sales}}

**Interpretation:** SP sellers ship 64% of revenue. BA and PE have few sellers but very high revenue per seller (R$15.4k and R$10.1k) — a sign that capable sellers exist outside the South-East.

### B9 — Customer state × average order value
**Business question:** do order values differ by state? **Purpose:** regional assortment and freight policy.

{{S:B09_state_aov}}

{{T:B09_state_aov}}

**Interpretation:** AOV rises with distance from SP (PB R$218 vs SP R$125), as does the freight burden (MA 26.3% vs SP 13.9%). High freight plausibly suppresses small orders in remote states, leaving larger baskets.

### B10 — Product category × units sold
**Business question:** are high-volume categories also high-value? **Purpose:** distinguish traffic drivers from revenue drivers.

{{S:B10_category_units}}

{{T:B10_category_units}}

**Interpretation:** volume and value diverge: telephony is 8th in units but 14th in revenue (R$70 avg price); electronics is 15th in units but 22nd in revenue. bed_bath_table and furniture_decor are traffic drivers; watches_gifts and cool_stuff are value drivers.

---

## 13. Ten multivariate analyses

### M1 — Category × customer state × revenue
**Business question:** what are the top two categories in each major state? **Purpose:** regionalised merchandising. Uses `RANK() OVER (PARTITION BY state)`.

{{S:M01_top_categories_per_state}}

{{T:M01_top_categories_per_state}}

**Interpretation:** category leadership differs by region: bed_bath_table leads SP and RS, watches_gifts leads RJ and DF, health_beauty leads MG and BA, sports_leisure leads PR and SC. **Recommendation:** tailor home-page and campaign categories by state.

### M2 — Seller × category × revenue
**Business question:** are top sellers specialists or generalists? **Purpose:** seller-development strategy.

{{S:M02_top_seller_category_mix}}

{{T:M02_top_seller_category_mix}}

**Interpretation:** 9 of the top 10 sellers earn 75–99% of revenue from one category; only #10 is a generalist (23 categories). Scale on Olist is built through category specialisation.

### M3 — Delivery performance × review × customer state
**Business question:** are regional satisfaction gaps explained by delivery? **Purpose:** prioritise logistics fixes by state.

{{S:M03_state_delivery_review}}

{{T:M03_state_delivery_review}}

**Interpretation:** states with the highest late rates (CE, BA, RJ: 12–14%) have the lowest average reviews (3.93–3.97), while on-time reviews are similar everywhere (4.14–4.32). The regional gap in satisfaction is largely a gap in lateness. RJ stands out: it is close to SP yet 12.1% late. **Recommendation:** investigate carrier performance into RJ as a priority — it is the #2 revenue state.

### M4 — Payment type × instalments × order value
**Business question:** do instalments enable bigger baskets? **Purpose:** instalment policy.

{{S:M04_payment_installments_value}}

{{T:M04_payment_installments_value}}

**Interpretation:** credit-card orders paid in 7+ instalments average R$334 versus R$101 at 1x, and this band is the single largest pool of payment value (R$3.93M). Instalments are central to high-ticket sales.

### M5 — Quarter × category × revenue
**Business question:** which leading categories are growing or stalling? **Purpose:** category momentum. Complete quarters 2017-Q1 to 2018-Q2; categories are the top 5 from B1.

{{S:M05_quarter_category_revenue}}

{{T:M05_quarter_category_revenue}}

**Interpretation:** health_beauty and watches_gifts kept growing into 2018-Q2 (+22% and +27% vs Q1), while computers_accessories fell 44% and sports_leisure 30% from Q1 to Q2 2018. **Recommendation:** investigate the Q2-2018 drop in these two categories (seller churn, stock, pricing).

### M6 — Seller × revenue × review × delivery performance
**Business question:** how is revenue distributed across seller quality tiers? **Purpose:** seller-management programme. Sellers with ≥30 delivered orders; seller-order grain to avoid item over-counting.

{{S:M06_seller_segments}}

{{T:M06_seller_segments}}

**Interpretation:** 23 "problem" sellers miss the carrier hand-over deadline on 34.5% of orders (vs 4.4% for stars) and average 15.5% late deliveries. "At-risk" and "problem" sellers together carry 22.4% of the revenue of established sellers — revenue exposed to poor experience. **Recommendation:** put the 153 at-risk/problem sellers on improvement plans with hand-over SLAs.

### M7 — Region × freight × delivery time × review
**Business question:** do remote customers pay more, wait longer and rate lower? **Purpose:** regional logistics investment.

{{S:M07_region_freight_delivery_review}}

{{T:M07_region_freight_delivery_review}}

**Interpretation:** a clear gradient: SP customers wait 8.8 days and pay 13.9% freight; Northeast customers wait 20.0 days, pay 21.7% and are late 12.7% of the time, with the lowest review (3.97). Yet remote regions have the highest AOV. **Recommendation:** remote regions are valuable but under-served — target them with regional fulfilment and freight offers.

### M8 — Day of week × time of day × orders × revenue
**Business question:** when do customers buy? **Purpose:** campaign and customer-service timing.

{{S:M08_weekday_hour_demand}}

{{T:M08_weekday_hour_demand}}

**Interpretation:** Monday and Tuesday are the busiest days, Saturday the quietest. Afternoons (12–17h) dominate on weekdays, but on Sunday the evening (18–23h) is the peak. **Recommendation:** schedule campaigns for Sunday evening and Monday, and staff service desks early in the week.

### M9 — Seller–customer geography × delivery × lateness × review
**Business question:** what does cross-state shipping cost in speed and satisfaction? **Purpose:** quantify the case for regional fulfilment. Single-seller orders only.

{{S:M09_same_vs_cross_state}}

{{T:M09_same_vs_cross_state}}

**Interpretation:** same-state orders arrive in 8 days; cross-state orders from SP take 16 days, cost 72% more freight (R$25.63 vs R$14.94), are twice as likely to be late (9.6% vs 4.7%) and are rated lower (4.05 vs 4.26). 64% of these orders are cross-state.

### M10 — Product weight × freight × delivery × review
**Business question:** are heavy items a logistics and satisfaction problem? **Purpose:** category logistics policy.

{{S:M10_weight_freight_delivery_review}}

{{T:M10_weight_freight_delivery_review}}

**Interpretation:** items over 15 kg take 15.5 days, are late 10% of the time and score 3.91, versus 11.8 days, 6.3% and 4.10 for items under 0.5 kg. Light items have the highest freight-to-price ratio (20.2%). **Recommendation:** dedicated heavy-goods carriers for furniture/appliance categories. *(Item-grain metrics: a multi-item order contributes once per item.)*

---

## 14. Customer analysis

All customer metrics use `customer_unique_id`.

### C1 — Customer base and repeat rate
**Business question:** how many real customers do we have and how many return? **Purpose:** retention baseline.

{{S:C01_customer_overview}}

{{T:C01_customer_overview}}

**Interpretation:** only **2,801 of 93,358 customers (3.0%)** placed more than one delivered order, and they contribute just 5.5% of revenue. Average orders per customer is 1.03.

### C2 — Order frequency
{{S:C02_order_frequency}}

{{T:C02_order_frequency}}

**Interpretation:** 97% of customers bought once. Lifetime spend rises with each order (R$138 → R$245 → R$365), so every converted repeat customer is worth roughly double.

### C3 — Customer spending deciles (`NTILE`)
**Business question:** how concentrated is customer value? **Purpose:** high-value customer programme sizing.

{{S:C03_spend_deciles}}

{{T:C03_spend_deciles}}

**Interpretation:** the top 10% of customers (lifetime spend ≥ R$280) generate **41.1% of revenue**; the bottom 50% generate 16.7%.

### C4 — High-value customers
{{S:C04_top_customers}}

{{T:C04_top_customers}}

**Interpretation:** the highest-value customers are almost all one-off buyers of expensive items, and three of the top seven left a 1-star review — including the single largest order (R$13,440). **Recommendation:** white-glove service (proactive tracking, priority support) for orders above roughly R$1,000.

### C5 — Repeat rate and value by state
{{S:C05_state_customer_value}}

{{T:C05_state_customer_value}}

**Interpretation:** repeat rates are uniformly low (2.7%–3.3%) across states — low retention is a platform-wide issue, not a regional one.

### C6 — Time to next order (`LAG`)
**Business question:** when do repeat customers come back? **Purpose:** timing of retention campaigns.

{{S:C06_days_to_next_order}}

{{T:C06_days_to_next_order}}

**Interpretation:** 28.5% of "repeat" orders are placed the **same day** as the previous one — split baskets rather than genuine loyalty — so true repeat behaviour is even lower than 3%. Among genuine (not same-day) returns, 56% come back within 90 days. **Recommendation:** trigger re-engagement campaigns in the 30–90-day window.

### C7 — First-order experience × repeat rate
**Business question:** do customers whose first order went badly come back less? **Purpose:** test whether satisfaction drives retention.

{{S:C07_first_review_vs_repeat}}

{{T:C07_first_review_vs_repeat}}

**Interpretation:** the difference is small (3.03% after a 4–5 star first order vs 2.84% after 1–2 stars). On this data, a good first experience alone does not create loyalty; low retention appears structural (marketplace model, no loyalty mechanism) rather than purely a service issue.

---

## 15. Product analysis

### P1 — Category league table (`RANK`, `DENSE_RANK`, running share)
{{S:P01_category_league}}

{{T:P01_category_league}}

{{S:P01b_categories_for_80pct}}

{{T:P01b_categories_for_80pct}}

**Interpretation:** 18 of 74 categories generate 80% of revenue. The revenue and review rankings diverge: bed_bath_table is #3 in revenue but #34 in satisfaction, and office_furniture is #15 in revenue but #44 in satisfaction. Several smaller categories (stationery, pet_shop, small_appliances) combine solid revenue with top-12 satisfaction.

### P2 — Best-selling product within each top category (`ROW_NUMBER`)
{{S:P02_top_product_per_category}}

{{T:P02_top_product_per_category}}

**Interpretation:** no single product exceeds ~5% of its category, and in sports_leisure the top product is under 1% — categories are broad long-tail assortments, not hero-product driven.

### P3 — Listing photos × product performance
{{S:P03_photos_vs_performance}}

{{T:P03_photos_vs_performance}}

**Interpretation:** products with 5+ photos average R$507 of revenue versus R$384 for single-photo listings (+32%). Half of products have only one photo. This is an association: higher-priced products may simply get more photos. **Recommendation:** A/B-test a minimum-photo standard before mandating it.

### P4 — Product long tail
{{S:P04_product_long_tail}}

{{T:P04_product_long_tail}}

**Interpretation:** 55% of products sold exactly once; the top 1% of products generate 24.4% of revenue and the top 10% generate 60.8%.

---

## 16. Seller performance

### S1 — Seller scorecard (revenue + orders + items + reviews + delivery)
{{S:S01_seller_scorecard}}

{{T:S01_seller_scorecard}}

**Interpretation:** big is not always good. Seller #5 (7c67e144, R$187k) has a 3.50 review and misses the carrier hand-over deadline on 29.7% of orders; #3 (4a3ca931) averages 3.85. Others combine scale with quality (#8 7a67c85e: 4.28 review, 2.8% hand-over late). **Recommendation:** the top sellers by revenue should be the first accounts to receive delivery-SLA reviews, because their problems affect the most customers.

### S2 — Seller revenue concentration
{{S:S02_seller_concentration}}

{{T:S02_seller_concentration}}

**Interpretation:** the top 1% of sellers (about 30) produce 25.5% of revenue, the top 20% produce 82.3%, and the bottom half just 3.3%.

### S3 — Seller hand-over timeliness × customer outcome × review
**Business question:** how much of late delivery is seller-caused? **Purpose:** allocate accountability between sellers and carriers.

{{S:S03_handover_vs_review}}

{{T:S03_handover_vs_review}}

**Interpretation:** when a seller misses the hand-over deadline, 20.8% of orders arrive late, versus 5.4% when the seller is on time. But once an order is late, the review is the same (2.27) whoever caused it — the customer does not distinguish. Most late orders (4,719 of 6,533) still come from sellers who handed over on time, so **carriers cause the majority of late deliveries** and sellers a significant minority.

---

## 17. Delivery and customer satisfaction

### D1 — Purchase → approval → carrier → customer → estimate
{{S:D01_stage_durations}}

{{T:D01_stage_durations}}

**Interpretation:** approval takes ~10 hours, seller hand-over ~2.9 days and the **carrier leg ~9.4 days (74% of total time)**. The promise is 23.7 days against an actual 12.6 — about 11 days of buffer. The carrier leg is where speed can be won.

### D2 — Monthly delivery performance
{{S:D02_monthly_delivery}}

{{T:D02_monthly_delivery}}

**Interpretation:** late rates spiked in Nov 2017 (12.4%, Black Friday), and again in Feb–Mar 2018 (14.1% and 19.0%). In exactly those months the average review fell to its lowest values (3.99, 3.88, 3.81). When delivery recovered (Jun–Jul 2018: 1.2–3.4% late), reviews returned to 4.31–4.32.

### D3 — Strength of association (Pearson r in SQL)
{{S:D03_correlations}}

{{T:D03_correlations}}

### D4 — Late vs on-time
{{S:D04_late_vs_ontime_review}}

{{T:D04_late_vs_ontime_review}}

**Association, not causation.** Late deliveries are strongly associated with low reviews (B5, M3, D2, D4), and the pattern is consistent across bands, states and months — but the data is observational. Plausible confounders include product type (heavy items are both slower and more complex, M10), seller quality (poor sellers both ship late and may misdescribe products, M6) and region. Negative correlations of r = −0.27 (delay) and −0.33 (total delivery days) are moderate, meaning delivery explains only part of the variation in reviews. A causal claim would need a controlled test, for example improving one carrier route and comparing reviews against a matched control route.

---

## 18. Time-series analysis

### T1 — Monthly revenue, orders, customers, AOV, MoM growth (`LAG`), running total, moving average
{{S:T01_monthly_trend}}

{{T:T01_monthly_trend}}

**Interpretation:** revenue grew from R$112k (Jan 2017) to a Black-Friday peak of R$988k (Nov 2017, +52.4% MoM), then **flattened**: since Jan 2018 every month has been between R$826k and R$978k, and the last five months show MoM changes of +2.1%, +0.4%, −12.4%, +1.4% and −3.4%. AOV has stayed within R$124–149 throughout, so growth came from order volume, not basket size.

### T2 — Year → quarter hierarchy (`WITH ROLLUP`)
{{S:T02_year_quarter_rollup}}

{{T:T02_year_quarter_rollup}}

### T3 — Year-over-year, Jan–Aug
{{S:T03_yoy_jan_aug}}

{{T:T03_yoy_jan_aug}}

**Interpretation:** Jan–Aug 2018 revenue was 141% above the same period of 2017, but YoY growth decays steadily month by month (from +727% to +51%) as 2017 volumes caught up with the 2018 plateau.

### T4 — Category momentum
{{S:T04_category_momentum}}

{{T:T04_category_momentum}}

**Interpretation:** fastest-growing established categories are baby (+269%), stationery (+260%), watches_gifts (+242%) and health_beauty (+210%). construction_tools_construction grew from a very small base. cool_stuff (+10%), toys (+42%), perfumery (+43%) and garden_tools (+54%) are lagging far behind the platform's +141%.

### T5 — Peak trading days
{{S:T05_peak_days}}

{{T:T05_peak_days}}

**Interpretation:** Black Friday (24 Nov 2017) produced 1,147 delivered orders — 7.2× an average day — and elevated demand persisted for the following four days. This peak was followed by the late-delivery spike in D2.

---

## 19. Advanced SQL coverage

| Technique | Where it is used |
|---|---|
| INNER JOIN | `v_item_detail`, S1, M9, every item-to-order join |
| LEFT JOIN | `v_order_summary` (orders without items/payments/reviews kept), DQ20 orphan tests, `zip_code` centroid join |
| Multi-table JOINs | `v_item_detail` (5 tables), `v_order_summary` (4 sources), P3 |
| GROUP BY / aggregates | every analysis (`SUM`, `AVG`, `COUNT DISTINCT`, `STDDEV`, `MIN/MAX`) |
| HAVING | B4, B7, B9, M3, M6, C5, M9 single-seller filter |
| CASE | banding in U1/U6/U9/U10, B5, M6 segments, `is_late`, conditional aggregation in M5/T3 pivots |
| CTEs | RV10, `v_order_summary`, M1–M10, all deep dives |
| Subqueries | KPI11 scalar subqueries, M1 ordering, P2 `IN (…)`, RV checks |
| Views | `v_product`, `v_order_summary`, `v_item_detail` (+ `fact_order` materialisation) |
| Date functions | `STR_TO_DATE`, `TIMESTAMPDIFF`, `DATEDIFF`, `DATE_FORMAT`, `YEAR`, `QUARTER`, `MONTH`, `DAYNAME`, `HOUR` |
| `ROW_NUMBER()` | latest review per order, median/percentiles (KPI9, U1b), P2, C7, Pareto shares |
| `RANK()` | B3, M1, M2, P1, S1, C4, T4 |
| `DENSE_RANK()` | B10, P1 review rank, S1 review rank |
| `LAG()` | T1 MoM growth, C6 days between orders |
| Running totals | T1 running revenue, B1/U2/P1 cumulative share |
| Moving average | T1 3-month window (`ROWS 2 PRECEDING`) |
| `NTILE()` | C3 deciles |
| `WITH ROLLUP` | T2 year/quarter subtotals |
| Named window (`WINDOW w AS`) | T1 |
| Stored function | `fn_std_city()` |
| Constraints | 9 enforced FKs, composite PKs, `UNIQUE`, `CHECK`, `ENUM` |

---

## 20. Key insights

1. **Growth has stalled.** Revenue rose to ~R$0.9M/month by early 2018 and then plateaued; AOV has been flat (R$124–149), so all historical growth came from acquiring new customers.
2. **Retention is close to zero.** Only 3.0% of customers return (and 28.5% of those "repeats" are same-day split baskets). Repeaters produce 5.5% of revenue, yet a second order roughly doubles lifetime value.
3. **Late delivery is the strongest correlate of dissatisfaction.** On-time orders average 4.29 stars, late orders 2.27; 1-star reviews jump from ~7% to ~70% once orders are 8+ days late. Monthly satisfaction dips mirror late-delivery spikes.
4. **The carrier leg is the bottleneck.** 74% of delivery time is in transit; carriers account for most late orders, sellers for a meaningful minority (missing the hand-over deadline quadruples the late rate).
5. **Geography is a structural handicap.** 60% of sellers and 64% of revenue originate in SP. Cross-state orders take twice as long, cost 72% more freight and are rated lower; the Northeast waits 20 days and pays ~22% freight — while spending the most per order.
6. **The promise is padded but still missed.** Estimates allow ~23.7 days for ~12.6 days of actual delivery, yet 6.8% of orders still arrive late.
7. **Revenue is concentrated.** 18 categories = 80% of revenue; top 10% of sellers = 67%; top 10% of customers = 41%.
8. **Category portfolio is uneven.** health_beauty and watches_gifts are growing leaders; computers_accessories and sports_leisure fell sharply in 2018-Q2; office_furniture and bed_bath_table have weak satisfaction.
9. **A small group of sellers damages the experience.** 153 established sellers rated below 4.0 carry ~22% of established-seller revenue; the worst miss hand-over deadlines on a third of orders.
10. **Instalments power high-ticket sales**, with 7+ instalment card orders forming the largest single pool of payment value.

---

## 21. Business recommendations

For the **Sales Director / E-commerce Manager**, in order of expected impact:

1. **Make on-time delivery a managed KPI with carrier SLAs.** Set a monthly late-rate target (e.g. < 5%, the level achieved in most of mid-2017 and mid-2018), track it by carrier and route, and prioritise RJ (12.1% late, #2 revenue state) and the Northeast. *Evidence: B5, M3, D2, D4.*
2. **Build peak-season logistics capacity.** Black Friday and Feb–Mar 2018 both produced late-delivery spikes and the lowest reviews. Pre-book carrier capacity and tighten seller hand-over windows before known peaks. *Evidence: D2, T5.*
3. **Introduce a seller performance programme.** Publish a monthly seller scorecard (revenue, review, late %, hand-over %); place the 153 at-risk and problem sellers on improvement plans, and reward "star" sellers with search visibility. *Evidence: M6, S1, S3.*
4. **Launch a retention programme.** With 97% one-time buyers, even lifting repeat rate from 3% to 5% would materially grow revenue. Use post-delivery re-engagement in the 30–90-day window and category-based cross-sell. *Evidence: C1, C2, C6.*
5. **Reduce the geographic handicap.** Recruit sellers in the Northeast and other under-served regions (BA and PE sellers already show high revenue per seller), or pilot regional fulfilment for top SKUs. *Evidence: M7, M9, B8.*
6. **Rethink freight for low-price categories and remote states.** Test free-shipping thresholds or bundles where freight exceeds ~20% of price (electronics, telephony, furniture_decor, housewares) and in high-AOV remote states. *Evidence: KPI6, B7, B9.*
7. **Rebalance category investment.** Double down on growing leaders (health_beauty, watches_gifts, baby, stationery); diagnose the Q2-2018 collapse in computers_accessories and sports_leisure; run quality audits for office_furniture and bed_bath_table. *Evidence: M5, T4, B4, P1.*
8. **Protect high-value orders.** Orders above ~R$1,000 deserve proactive tracking and priority support — several of the largest orders received 1-star reviews. Keep instalment options prominent on high-ticket items. *Evidence: C4, M4.*
9. **Fix catalogue and data capture.** Require category, photos and dimensions at listing creation (610 incomplete products), validate seller addresses, and stop issuing duplicate reviews per order. *Evidence: section 5.*

---

## 22. Limitations

- **Snapshot and coverage.** 2016 and Sep–Oct 2018 are sparse; trend conclusions rely on Jan 2017 – Aug 2018. Orders still `shipped`/`processing` at the snapshot are excluded from revenue.
- **Revenue definition.** Revenue is product price on delivered orders. There is no cost, commission or margin data, so profitability cannot be assessed.
- **Reviews.** Reviews are at order level; in the 1,278 multi-seller orders a review is attributed to every seller in the order. 768 orders have no review, and non-response may not be random. Multiple reviews per order were resolved to the latest.
- **Correlation, not causation.** All relationships (delay × review, photos × revenue, first review × repeat) are observational associations with possible confounders.
- **Customer identity.** Repeat analysis depends on Olist's `customer_unique_id` matching; customers using different details would appear as new.
- **Geography.** ZIP prefixes are approximate; 162 prefixes have no coordinates and centroids average several raw points.
- **Data anomalies retained.** 1,388 delivered orders with inconsistent timestamps are excluded from stage timing but included in total-delivery KPIs if they have a delivery date.
- **No demand-side data.** Without traffic, conversion or marketing data, the analysis cannot explain *why* growth plateaued — only that it did.
- **Supplemented translations.** Two category translations were added by the analyst and are flagged.

---

## 23. Conclusion

This project turns nine raw Olist files into a validated relational MySQL database with enforced keys, documented cleaning and a two-grain analytical layer that structurally prevents join inflation — an error shown to overstate revenue by 5% and payments by 29%.

On that foundation, the analysis shows that Olist's next phase of growth will not come from acquisition alone. The data points to three levers a Sales Director can act on: **delivery reliability** (the factor most strongly associated with satisfaction), **seller and regional supply quality** (which drives delivery speed, freight cost and reviews), and **retention** (where almost all customers are lost after one order). Because every metric is reproducible from SQL views, these KPIs can be refreshed monthly and used to track whether interventions — carrier SLAs, seller scorecards, retention campaigns — actually move the numbers.

---

*Reproduce: `bash run_all.sh` (MySQL 8.0 with `local_infile=1`; set the CSV path in `sql/01_staging_load.sql`). Then `python3 build_report.py` regenerates this README from fresh query output.*
