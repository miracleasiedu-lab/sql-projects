/* =====================================================================
   04_relationship_validation.sql
   Stage 6: Relationship validation on the clean model + join-inflation
   ===================================================================== */
USE olist;

/* ---------- 1. Constraints actually enforced by the engine ---------- */
-- @Q RV01_enforced_foreign_keys
SELECT kcu.TABLE_NAME            AS child_table,
       kcu.COLUMN_NAME           AS fk_column,
       kcu.REFERENCED_TABLE_NAME AS parent_table,
       kcu.REFERENCED_COLUMN_NAME AS parent_key,
       kcu.CONSTRAINT_NAME
FROM information_schema.KEY_COLUMN_USAGE kcu
WHERE kcu.TABLE_SCHEMA = 'olist' AND kcu.REFERENCED_TABLE_NAME IS NOT NULL
ORDER BY child_table, fk_column;

-- @Q RV02_primary_keys
SELECT TABLE_NAME AS table_name,
       GROUP_CONCAT(COLUMN_NAME ORDER BY ORDINAL_POSITION) AS primary_key_columns,
       CASE WHEN COUNT(*) > 1 THEN 'composite' ELSE 'single' END AS key_type
FROM information_schema.KEY_COLUMN_USAGE
WHERE TABLE_SCHEMA = 'olist' AND CONSTRAINT_NAME = 'PRIMARY'
GROUP BY TABLE_NAME ORDER BY TABLE_NAME;

/* ---------- 2. Each relationship: child coverage & parent coverage ---------- */
-- Orders -> Customers   (expected 1:1 on customer_id)
-- @Q RV03_orders_customers
SELECT
  (SELECT COUNT(*) FROM orders)                                                   AS orders,
  (SELECT COUNT(*) FROM orders o LEFT JOIN customers c USING (customer_id)
    WHERE c.customer_id IS NULL)                                                  AS orders_without_customer,
  (SELECT COUNT(*) FROM customers c LEFT JOIN orders o USING (customer_id)
    WHERE o.order_id IS NULL)                                                     AS customers_without_order,
  (SELECT MAX(n) FROM (SELECT customer_id, COUNT(*) n FROM orders GROUP BY customer_id) x)
                                                                                  AS max_orders_per_customer_id,
  (SELECT MAX(n) FROM (SELECT c.customer_unique_id, COUNT(*) n FROM orders o
     JOIN customers c USING (customer_id) GROUP BY c.customer_unique_id) y)       AS max_orders_per_customer_unique_id;

-- Orders -> Order Items  (1:M, optional on the child side)
-- @Q RV04_orders_items
SELECT
  (SELECT COUNT(*) FROM order_items i LEFT JOIN orders o USING (order_id) WHERE o.order_id IS NULL) AS items_without_order,
  (SELECT COUNT(*) FROM orders o WHERE NOT EXISTS (SELECT 1 FROM order_items i WHERE i.order_id = o.order_id)) AS orders_without_items,
  (SELECT COUNT(*) FROM orders o WHERE o.order_status = 'delivered'
     AND NOT EXISTS (SELECT 1 FROM order_items i WHERE i.order_id = o.order_id))                      AS delivered_orders_without_items,
  (SELECT ROUND(AVG(n), 3) FROM (SELECT order_id, COUNT(*) n FROM order_items GROUP BY order_id) a)    AS avg_items_per_order,
  (SELECT MAX(n) FROM (SELECT order_id, COUNT(*) n FROM order_items GROUP BY order_id) b)              AS max_items_per_order;

-- Order Items -> Products, Order Items -> Sellers  (M:1)
-- @Q RV05_items_products_sellers
SELECT
  (SELECT COUNT(*) FROM order_items i LEFT JOIN products p USING (product_id) WHERE p.product_id IS NULL) AS items_without_product,
  (SELECT COUNT(*) FROM products p WHERE NOT EXISTS (SELECT 1 FROM order_items i WHERE i.product_id = p.product_id)) AS products_never_sold,
  (SELECT COUNT(*) FROM order_items i LEFT JOIN sellers s USING (seller_id) WHERE s.seller_id IS NULL)   AS items_without_seller,
  (SELECT COUNT(*) FROM sellers s WHERE NOT EXISTS (SELECT 1 FROM order_items i WHERE i.seller_id = s.seller_id))   AS sellers_never_sold,
  (SELECT COUNT(*) FROM (SELECT order_id FROM order_items GROUP BY order_id HAVING COUNT(DISTINCT seller_id) > 1) m) AS multi_seller_orders;

-- Orders -> Payments  (1:M)
-- @Q RV06_orders_payments
SELECT
  (SELECT COUNT(*) FROM order_payments p LEFT JOIN orders o USING (order_id) WHERE o.order_id IS NULL) AS payments_without_order,
  (SELECT COUNT(*) FROM orders o WHERE NOT EXISTS (SELECT 1 FROM order_payments p WHERE p.order_id = o.order_id)) AS orders_without_payment,
  (SELECT GROUP_CONCAT(CONCAT(o.order_id, ' (', o.order_status, ')'))
     FROM orders o WHERE NOT EXISTS (SELECT 1 FROM order_payments p WHERE p.order_id = o.order_id)) AS which_order,
  (SELECT COUNT(*) FROM (SELECT order_id FROM order_payments GROUP BY order_id HAVING COUNT(*) > 1) m) AS orders_with_multiple_payments;

-- Orders -> Reviews  (1:M in practice, expected ~1:1)
-- @Q RV07_orders_reviews
SELECT
  (SELECT COUNT(*) FROM order_reviews r LEFT JOIN orders o USING (order_id) WHERE o.order_id IS NULL) AS reviews_without_order,
  (SELECT COUNT(*) FROM orders o WHERE NOT EXISTS (SELECT 1 FROM order_reviews r WHERE r.order_id = o.order_id)) AS orders_without_review,
  (SELECT COUNT(*) FROM (SELECT order_id FROM order_reviews GROUP BY order_id HAVING COUNT(*) > 1) m) AS orders_with_multiple_reviews;

-- Products -> Category translation  (M:1, optional)
-- @Q RV08_products_categories
SELECT
  SUM(p.product_category_name IS NULL)                                                  AS products_without_category,
  SUM(p.product_category_name IS NOT NULL AND t.product_category_name IS NULL)          AS products_with_untranslated_category,
  SUM(t.is_supplemented = 1)                                                            AS products_using_supplemented_translation,
  (SELECT COUNT(*) FROM category_translation ct WHERE NOT EXISTS
      (SELECT 1 FROM products p2 WHERE p2.product_category_name = ct.product_category_name)) AS translations_never_used
FROM products p LEFT JOIN category_translation t USING (product_category_name);

-- Customers / Sellers -> zip_code (M:1)
-- @Q RV09_geography_coverage
SELECT 'customers' AS entity, COUNT(*) AS rows_,
       SUM(z.has_geolocation = 0 OR z.latitude IS NULL) AS rows_without_coordinates,
       ROUND(100 * AVG(z.latitude IS NOT NULL), 2)       AS pct_geocoded
FROM customers c JOIN zip_code z ON z.zip_code_prefix = c.customer_zip_code_prefix
UNION ALL
SELECT 'sellers', COUNT(*), SUM(z.has_geolocation = 0 OR z.latitude IS NULL), ROUND(100 * AVG(z.latitude IS NOT NULL), 2)
FROM sellers s JOIN zip_code z ON z.zip_code_prefix = s.seller_zip_code_prefix;

/* ---------- 3. JOIN INFLATION — the problem, demonstrated ---------- */
-- WRONG: joining items, payments and reviews at once multiplies rows.
-- An order with 3 items, 2 payments and 2 reviews yields 3 x 2 x 2 = 12
-- rows; SUM(price) is counted 4x and SUM(payment_value) 6x.
-- @Q RV10_join_inflation_wrong_vs_right
WITH naive AS (                      -- the anti-pattern
  SELECT SUM(i.price)          AS revenue,
         SUM(p.payment_value)  AS payments,
         COUNT(*)              AS joined_rows,
         COUNT(DISTINCT o.order_id) AS orders
  FROM orders o
  JOIN order_items i     ON i.order_id = o.order_id
  JOIN order_payments p  ON p.order_id = o.order_id
  LEFT JOIN order_reviews r ON r.order_id = o.order_id
  WHERE o.order_status = 'delivered'
),
item_agg AS (                        -- correct: collapse each child to order grain FIRST
  SELECT order_id, SUM(price) AS revenue FROM order_items GROUP BY order_id
),
pay_agg AS (
  SELECT order_id, SUM(payment_value) AS payments FROM order_payments GROUP BY order_id
),
rev_agg AS (
  SELECT order_id, AVG(review_score) AS score FROM order_reviews GROUP BY order_id
),
correct AS (
  SELECT SUM(ia.revenue) AS revenue, SUM(pa.payments) AS payments,
         COUNT(*) AS joined_rows, COUNT(DISTINCT o.order_id) AS orders
  FROM orders o
  JOIN item_agg ia     ON ia.order_id = o.order_id
  JOIN pay_agg  pa     ON pa.order_id = o.order_id
  LEFT JOIN rev_agg ra ON ra.order_id = o.order_id
  WHERE o.order_status = 'delivered'
)
SELECT 'naive multi-join' AS method, revenue, payments, joined_rows, orders FROM naive
UNION ALL
SELECT 'aggregate-then-join', revenue, payments, joined_rows, orders FROM correct
UNION ALL
SELECT 'overstatement (naive - correct)', n.revenue - c.revenue, n.payments - c.payments,
       n.joined_rows - c.joined_rows, n.orders - c.orders
FROM naive n CROSS JOIN correct c;

-- The worst individual case of inflation
-- @Q RV11_worst_inflated_order
WITH i AS (SELECT order_id, COUNT(*) n_items, SUM(price) rev FROM order_items GROUP BY order_id),
     p AS (SELECT order_id, COUNT(*) n_pay FROM order_payments GROUP BY order_id),
     r AS (SELECT order_id, COUNT(*) n_rev FROM order_reviews GROUP BY order_id)
SELECT i.order_id, i.n_items, p.n_pay, COALESCE(r.n_rev, 0) AS n_reviews,
       i.n_items * p.n_pay * GREATEST(COALESCE(r.n_rev, 1), 1) AS rows_after_naive_join,
       i.rev AS true_revenue,
       i.rev * p.n_pay * GREATEST(COALESCE(r.n_rev, 1), 1)     AS naive_revenue
FROM i JOIN p USING (order_id) LEFT JOIN r USING (order_id)
ORDER BY rows_after_naive_join DESC, i.order_id
LIMIT 5;
