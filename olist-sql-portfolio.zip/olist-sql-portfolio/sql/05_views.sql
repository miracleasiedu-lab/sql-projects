/* =====================================================================
   05_views.sql
   Reusable analytical layer. Two grains, never mixed:
     v_order_summary  — exactly ONE row per order_id
     v_item_detail    — exactly ONE row per (order_id, order_item_id)
   ---------------------------------------------------------------------
   METRIC DEFINITIONS (used consistently in every later script)
     Revenue          = SUM(order_items.price) on DELIVERED orders
                        (product sales value; excludes freight)
     Freight          = SUM(order_items.freight_value), reported separately
     GMV incl. freight= Revenue + Freight
     Payment value    = SUM(order_payments.payment_value) (includes
                        freight and any instalment interest/vouchers)
     Order review     = the LATEST review per order (547 orders have
                        more than one; 202 of them with different scores)
     Late delivery    = delivered DATE > estimated delivery DATE
   ===================================================================== */
USE olist;

/* ---------------------------------------------------------------------
   v_category — one label per product, never NULL
   --------------------------------------------------------------------- */
CREATE OR REPLACE VIEW v_product AS
SELECT p.*,
       COALESCE(t.product_category_name_english, 'uncategorized') AS category
FROM products p
LEFT JOIN category_translation t USING (product_category_name);

/* ---------------------------------------------------------------------
   v_order_summary — order grain. Each child table is collapsed to one
   row per order in its own CTE BEFORE joining (prevents join inflation).
   --------------------------------------------------------------------- */
CREATE OR REPLACE VIEW v_order_summary AS
WITH item_agg AS (
  SELECT order_id,
         COUNT(*)                   AS items,
         COUNT(DISTINCT product_id) AS distinct_products,
         COUNT(DISTINCT seller_id)  AS distinct_sellers,
         SUM(price)                 AS item_revenue,
         SUM(freight_value)         AS freight
  FROM order_items GROUP BY order_id
),
pay_agg AS (
  SELECT order_id,
         SUM(payment_value)          AS payment_value,
         COUNT(*)                    AS payment_rows,
         MAX(payment_installments)   AS max_installments,
         -- dominant method = the method carrying the largest share of the value
         SUBSTRING_INDEX(GROUP_CONCAT(payment_type ORDER BY payment_value DESC, payment_sequential), ',', 1)
                                     AS main_payment_type
  FROM order_payments GROUP BY order_id
),
review_ranked AS (
  SELECT order_id, review_score,
         ROW_NUMBER() OVER (PARTITION BY order_id
                            ORDER BY review_answer_timestamp DESC, review_creation_date DESC, review_id) AS rn
  FROM order_reviews
)
SELECT
  o.order_id,
  o.customer_id,
  c.customer_unique_id,
  c.customer_city,
  c.customer_state,
  o.order_status,
  o.order_purchase_timestamp,
  DATE(o.order_purchase_timestamp)                         AS purchase_date,
  DATE_FORMAT(o.order_purchase_timestamp, '%Y-%m')         AS purchase_month,
  o.order_approved_at,
  o.order_delivered_carrier_date,
  o.order_delivered_customer_date,
  o.order_estimated_delivery_date,
  COALESCE(ia.items, 0)               AS items,
  ia.distinct_products,
  ia.distinct_sellers,
  COALESCE(ia.item_revenue, 0)        AS item_revenue,
  COALESCE(ia.freight, 0)             AS freight,
  pa.payment_value,
  pa.payment_rows,
  pa.max_installments,
  pa.main_payment_type,
  rr.review_score,
  -- delivery metrics (NULL unless the order actually reached the customer)
  ROUND(TIMESTAMPDIFF(MINUTE, o.order_purchase_timestamp, o.order_delivered_customer_date) / 1440, 2)
                                                           AS delivery_days,
  DATEDIFF(o.order_delivered_customer_date, o.order_estimated_delivery_date)
                                                           AS delay_days,      -- >0 late, <=0 on time/early
  CASE WHEN o.order_delivered_customer_date IS NULL THEN NULL
       WHEN DATE(o.order_delivered_customer_date) > DATE(o.order_estimated_delivery_date) THEN 1
       ELSE 0 END                                          AS is_late,
  -- data-quality flag: complete, chronologically valid delivery chain
  CASE WHEN o.order_status = 'delivered'
        AND o.order_approved_at IS NOT NULL
        AND o.order_delivered_carrier_date IS NOT NULL
        AND o.order_delivered_customer_date IS NOT NULL
        AND o.order_approved_at >= o.order_purchase_timestamp
        AND o.order_delivered_carrier_date >= o.order_approved_at
        AND o.order_delivered_customer_date >= o.order_delivered_carrier_date
       THEN 1 ELSE 0 END                                   AS valid_delivery_chain
FROM orders o
JOIN customers c        ON c.customer_id = o.customer_id
LEFT JOIN item_agg ia   ON ia.order_id = o.order_id
LEFT JOIN pay_agg pa    ON pa.order_id = o.order_id
LEFT JOIN review_ranked rr ON rr.order_id = o.order_id AND rr.rn = 1;

/* ---------------------------------------------------------------------
   v_item_detail — line grain, enriched with order/customer/product/
   seller attributes. Safe for SUM(price) because there is no 1:M join
   below the item level (orders, products, sellers are all M:1 here).
   --------------------------------------------------------------------- */
CREATE OR REPLACE VIEW v_item_detail AS
SELECT
  i.order_id, i.order_item_id, i.product_id, i.seller_id,
  i.price, i.freight_value, i.shipping_limit_date,
  o.order_status, o.order_purchase_timestamp,
  DATE_FORMAT(o.order_purchase_timestamp, '%Y-%m') AS purchase_month,
  o.order_delivered_carrier_date, o.order_delivered_customer_date, o.order_estimated_delivery_date,
  c.customer_unique_id, c.customer_state,
  p.category, p.product_weight_g, p.product_photos_qty,
  p.product_length_cm * p.product_height_cm * p.product_width_cm AS product_volume_cm3,
  s.seller_city, s.seller_state
FROM order_items i
JOIN orders o     ON o.order_id = i.order_id
JOIN customers c  ON c.customer_id = o.customer_id
JOIN v_product p  ON p.product_id = i.product_id
JOIN sellers s    ON s.seller_id = i.seller_id;

/* ---------------------------------------------------------------------
   Materialised copy of the order summary for fast repeated analysis.
   (MySQL has no materialised views; a table rebuilt from the view is
   the standard pattern. Re-run this script after any reload.)
   --------------------------------------------------------------------- */
DROP TABLE IF EXISTS fact_order;
CREATE TABLE fact_order AS SELECT * FROM v_order_summary;
ALTER TABLE fact_order
  ADD PRIMARY KEY (order_id),
  ADD KEY ix_fo_unique (customer_unique_id),
  ADD KEY ix_fo_month (purchase_month),
  ADD KEY ix_fo_status (order_status);

-- @Q VW01_view_grain_checks
SELECT 'v_order_summary' AS object_, COUNT(*) AS rows_, COUNT(DISTINCT order_id) AS distinct_grain_keys,
       (SELECT COUNT(*) FROM orders) AS expected_rows
FROM v_order_summary
UNION ALL
SELECT 'v_item_detail', COUNT(*), COUNT(DISTINCT order_id, order_item_id), (SELECT COUNT(*) FROM order_items)
FROM v_item_detail
UNION ALL
SELECT 'fact_order', COUNT(*), COUNT(DISTINCT order_id), (SELECT COUNT(*) FROM orders) FROM fact_order;

-- Revenue must tie out across both grains
-- @Q VW02_revenue_tie_out
SELECT (SELECT SUM(item_revenue) FROM fact_order WHERE order_status = 'delivered') AS revenue_order_grain,
       (SELECT SUM(price) FROM v_item_detail WHERE order_status = 'delivered')     AS revenue_item_grain,
       (SELECT SUM(i.price) FROM order_items i JOIN orders o USING (order_id)
         WHERE o.order_status = 'delivered')                                       AS revenue_base_tables;

-- @Q VW03_delivery_chain_quality
SELECT COUNT(*)                                             AS delivered_orders,
       SUM(order_delivered_customer_date IS NOT NULL)       AS with_delivery_timestamp,
       SUM(valid_delivery_chain)                            AS with_valid_full_chain,
       SUM(order_delivered_customer_date IS NOT NULL) - SUM(valid_delivery_chain) AS excluded_from_stage_analysis
FROM fact_order WHERE order_status = 'delivered';
