/* =====================================================================
   06_kpis.sql — Stage 7: 10 management KPIs
   Scope: delivered orders unless stated (realised sales).
   ===================================================================== */
USE olist;

-- KPI 1: Total Revenue (product sales, delivered orders) + freight & GMV
-- @Q KPI01_total_revenue
SELECT ROUND(SUM(item_revenue), 2)                 AS total_revenue,
       ROUND(SUM(freight), 2)                      AS total_freight,
       ROUND(SUM(item_revenue + freight), 2)       AS gmv_incl_freight,
       ROUND(SUM(payment_value), 2)                AS total_payment_value
FROM fact_order
WHERE order_status = 'delivered';

-- KPI 2: Total Orders (all statuses vs delivered) and fulfilment rate
-- @Q KPI02_total_orders
SELECT COUNT(*)                                            AS all_orders,
       SUM(order_status = 'delivered')                     AS delivered_orders,
       SUM(order_status IN ('canceled', 'unavailable'))    AS canceled_or_unavailable,
       ROUND(100 * AVG(order_status = 'delivered'), 2)     AS pct_delivered,
       ROUND(100 * AVG(order_status IN ('canceled', 'unavailable')), 2) AS pct_canceled_unavailable
FROM fact_order;

-- KPI 3: Unique customers (customer_unique_id) vs order-level customer_id
-- @Q KPI03_unique_customers
SELECT COUNT(DISTINCT customer_unique_id)  AS unique_customers_delivered,
       COUNT(DISTINCT customer_id)         AS customer_ids_delivered,
       COUNT(DISTINCT customer_id) - COUNT(DISTINCT customer_unique_id) AS overcount_if_customer_id_used
FROM fact_order WHERE order_status = 'delivered';

-- KPI 4: Average Order Value (product revenue per delivered order)
-- @Q KPI04_average_order_value
SELECT ROUND(AVG(item_revenue), 2)                  AS aov_product_revenue,
       ROUND(AVG(item_revenue + freight), 2)        AS aov_incl_freight,
       ROUND(AVG(payment_value), 2)                 AS avg_amount_paid
FROM fact_order WHERE order_status = 'delivered';

-- KPI 5: Total items sold (delivered) and items per order
-- @Q KPI05_items_sold
SELECT SUM(items)                AS items_sold,
       ROUND(AVG(items), 3)      AS avg_items_per_order,
       SUM(items > 1)            AS multi_item_orders,
       ROUND(100 * AVG(items > 1), 2) AS pct_multi_item_orders
FROM fact_order WHERE order_status = 'delivered';

-- KPI 6: Average freight cost per order and freight as % of product value
-- @Q KPI06_freight
SELECT ROUND(AVG(freight), 2)                              AS avg_freight_per_order,
       ROUND(SUM(freight) / SUM(items), 2)                 AS avg_freight_per_item,
       ROUND(100 * SUM(freight) / SUM(item_revenue), 2)    AS freight_pct_of_revenue
FROM fact_order WHERE order_status = 'delivered';

-- KPI 7: Average review score (one review per order) and satisfaction split
-- @Q KPI07_review_score
SELECT COUNT(review_score)                              AS reviewed_orders,
       ROUND(AVG(review_score), 3)                      AS avg_review_score,
       ROUND(100 * AVG(review_score >= 4), 2)           AS pct_positive_4_5,
       ROUND(100 * AVG(review_score <= 2), 2)           AS pct_negative_1_2
FROM fact_order WHERE review_score IS NOT NULL;

-- KPI 8: Active sellers (>= 1 delivered item) and revenue per seller
-- @Q KPI08_active_sellers
SELECT COUNT(DISTINCT i.seller_id)                            AS active_sellers,
       (SELECT COUNT(*) FROM sellers)                         AS registered_sellers,
       ROUND(SUM(i.price) / COUNT(DISTINCT i.seller_id), 2)   AS avg_revenue_per_active_seller
FROM order_items i JOIN orders o USING (order_id)
WHERE o.order_status = 'delivered';

-- KPI 9: Average delivery time (purchase -> customer), days
-- @Q KPI09_delivery_time
WITH d AS (
  SELECT delivery_days,
         ROW_NUMBER() OVER (ORDER BY delivery_days) AS rn,
         COUNT(*)     OVER ()                       AS n
  FROM fact_order
  WHERE order_status = 'delivered' AND delivery_days IS NOT NULL
)
SELECT ROUND(AVG(delivery_days), 2)                                     AS avg_delivery_days,
       MAX(CASE WHEN rn = CEIL(n * 0.5) THEN delivery_days END)         AS median_delivery_days,
       MAX(CASE WHEN rn = CEIL(n * 0.9) THEN delivery_days END)         AS p90_delivery_days,
       MAX(n)                                                           AS orders_measured
FROM d;

-- KPI 10: On-time delivery rate (delivered on or before estimated date)
-- @Q KPI10_on_time_rate
SELECT COUNT(*)                                  AS delivered_with_date,
       SUM(is_late = 0)                          AS on_time,
       SUM(is_late = 1)                          AS late,
       ROUND(100 * AVG(is_late = 0), 2)          AS on_time_rate_pct,
       ROUND(AVG(delay_days), 2)                 AS avg_days_vs_estimate   -- negative = early
FROM fact_order
WHERE order_status = 'delivered' AND order_delivered_customer_date IS NOT NULL;

-- KPI dashboard: one-row executive summary (scalar subqueries)
-- @Q KPI11_executive_scorecard
SELECT
  (SELECT ROUND(SUM(item_revenue), 0) FROM fact_order WHERE order_status = 'delivered')            AS revenue,
  (SELECT COUNT(*) FROM fact_order WHERE order_status = 'delivered')                               AS delivered_orders,
  (SELECT COUNT(DISTINCT customer_unique_id) FROM fact_order WHERE order_status = 'delivered')     AS unique_customers,
  (SELECT ROUND(AVG(item_revenue), 2) FROM fact_order WHERE order_status = 'delivered')            AS aov,
  (SELECT SUM(items) FROM fact_order WHERE order_status = 'delivered')                             AS items_sold,
  (SELECT ROUND(AVG(freight), 2) FROM fact_order WHERE order_status = 'delivered')                 AS avg_freight,
  (SELECT ROUND(AVG(review_score), 2) FROM fact_order)                                             AS avg_review,
  (SELECT COUNT(DISTINCT seller_id) FROM order_items JOIN orders USING (order_id)
     WHERE order_status = 'delivered')                                                             AS active_sellers,
  (SELECT ROUND(AVG(delivery_days), 1) FROM fact_order WHERE order_status = 'delivered')           AS avg_delivery_days,
  (SELECT ROUND(100 * AVG(is_late = 0), 1) FROM fact_order
     WHERE order_status = 'delivered' AND is_late IS NOT NULL)                                     AS on_time_pct;
