/* =====================================================================
   08_bivariate.sql — Stage 9: 10 two-variable analyses
   Delivered orders only, unless stated.
   ===================================================================== */
USE olist;

-- B1  Product Category x Revenue — which categories drive sales?
-- @Q B01_category_revenue
SELECT category,
       ROUND(SUM(price), 0)                                         AS revenue,
       ROUND(100 * SUM(price) / SUM(SUM(price)) OVER (), 2)         AS pct_revenue,
       ROUND(100 * SUM(SUM(price)) OVER (ORDER BY SUM(price) DESC) / SUM(SUM(price)) OVER (), 2) AS cumulative_pct,
       COUNT(DISTINCT order_id)                                     AS orders
FROM v_item_detail WHERE order_status = 'delivered'
GROUP BY category ORDER BY revenue DESC LIMIT 15;

-- B2  Customer State x Revenue
-- @Q B02_customer_state_revenue
SELECT customer_state,
       ROUND(SUM(item_revenue), 0)                                    AS revenue,
       ROUND(100 * SUM(item_revenue) / SUM(SUM(item_revenue)) OVER (), 2) AS pct_revenue,
       COUNT(*)                                                       AS orders,
       COUNT(DISTINCT customer_unique_id)                             AS unique_customers,
       ROUND(SUM(item_revenue) / COUNT(DISTINCT customer_unique_id), 2) AS revenue_per_customer
FROM fact_order WHERE order_status = 'delivered'
GROUP BY customer_state ORDER BY revenue DESC LIMIT 12;

-- B3  Seller x Revenue — how concentrated is seller revenue?
-- @Q B03_top_sellers
SELECT seller_id, seller_state,
       ROUND(SUM(price), 0)                                    AS revenue,
       ROUND(100 * SUM(price) / SUM(SUM(price)) OVER (), 2)    AS pct_marketplace_revenue,
       COUNT(DISTINCT order_id)                                AS orders,
       RANK() OVER (ORDER BY SUM(price) DESC)                  AS revenue_rank
FROM v_item_detail WHERE order_status = 'delivered'
GROUP BY seller_id, seller_state
ORDER BY revenue DESC LIMIT 10;

-- B4  Product Category x Review Score (categories with >= 1,000 reviewed orders)
--     Grain fix: one row per (order, category) so a 3-item order is not counted 3x.
-- @Q B04_category_review
WITH order_cat AS (
  SELECT DISTINCT i.order_id, i.category
  FROM v_item_detail i WHERE i.order_status = 'delivered'
)
SELECT oc.category,
       COUNT(*)                                 AS reviewed_orders,
       ROUND(AVG(f.review_score), 3)            AS avg_review,
       ROUND(100 * AVG(f.review_score <= 2), 2) AS pct_negative_1_2
FROM order_cat oc JOIN fact_order f USING (order_id)
WHERE f.review_score IS NOT NULL
GROUP BY oc.category
HAVING COUNT(*) >= 1000
ORDER BY avg_review ASC;

-- B5  Delivery delay (days vs estimate) x Review Score
-- @Q B05_delay_review
SELECT CASE WHEN delay_days <= -15 THEN '01: 15+ days early'
            WHEN delay_days <= -8  THEN '02: 8-14 days early'
            WHEN delay_days <= -1  THEN '03: 1-7 days early'
            WHEN delay_days =  0   THEN '04: on estimated day'
            WHEN delay_days <=  3  THEN '05: 1-3 days late'
            WHEN delay_days <=  7  THEN '06: 4-7 days late'
            WHEN delay_days <= 14  THEN '07: 8-14 days late'
            ELSE                        '08: 15+ days late' END AS delay_band,
       COUNT(*)                                   AS orders,
       ROUND(AVG(review_score), 3)                AS avg_review,
       ROUND(100 * AVG(review_score = 1), 2)      AS pct_1_star,
       ROUND(100 * AVG(review_score = 5), 2)      AS pct_5_star
FROM fact_order
WHERE order_status = 'delivered' AND delay_days IS NOT NULL AND review_score IS NOT NULL
GROUP BY delay_band ORDER BY delay_band;

-- B6  Payment Type x Order Value
-- @Q B06_payment_type_order_value
SELECT main_payment_type,
       COUNT(*)                        AS orders,
       ROUND(AVG(payment_value), 2)    AS avg_paid,
       ROUND(AVG(item_revenue), 2)     AS avg_product_value,
       ROUND(SUM(payment_value), 0)    AS total_paid,
       ROUND(100 * AVG(payment_rows > 1), 2) AS pct_split_payments
FROM fact_order WHERE order_status = 'delivered' AND main_payment_type IS NOT NULL
GROUP BY main_payment_type ORDER BY orders DESC;

-- B7  Freight Cost x Product Category (categories with >= 1,000 items)
-- @Q B07_category_freight
SELECT category,
       COUNT(*)                                       AS items,
       ROUND(AVG(price), 2)                           AS avg_price,
       ROUND(AVG(freight_value), 2)                   AS avg_freight,
       ROUND(100 * SUM(freight_value) / SUM(price), 1) AS freight_pct_of_price,
       ROUND(AVG(product_weight_g) / 1000, 2)         AS avg_weight_kg
FROM v_item_detail WHERE order_status = 'delivered'
GROUP BY category HAVING COUNT(*) >= 1000
ORDER BY freight_pct_of_price DESC;

-- B8  Seller State x Sales
-- @Q B08_seller_state_sales
SELECT seller_state,
       COUNT(DISTINCT seller_id)                              AS active_sellers,
       ROUND(SUM(price), 0)                                   AS revenue,
       ROUND(100 * SUM(price) / SUM(SUM(price)) OVER (), 2)   AS pct_revenue,
       ROUND(SUM(price) / COUNT(DISTINCT seller_id), 0)       AS revenue_per_seller
FROM v_item_detail WHERE order_status = 'delivered'
GROUP BY seller_state ORDER BY revenue DESC LIMIT 10;

-- B9  Customer State x Average Order Value (states with >= 500 orders)
-- @Q B09_state_aov
SELECT customer_state,
       COUNT(*)                         AS orders,
       ROUND(AVG(item_revenue), 2)      AS aov,
       ROUND(AVG(freight), 2)           AS avg_freight,
       ROUND(100 * SUM(freight) / SUM(item_revenue), 1) AS freight_pct
FROM fact_order WHERE order_status = 'delivered'
GROUP BY customer_state HAVING COUNT(*) >= 500
ORDER BY aov DESC;

-- B10 Product Category x Units Sold — volume vs. value
-- @Q B10_category_units
SELECT category,
       COUNT(*)                                 AS units_sold,
       DENSE_RANK() OVER (ORDER BY COUNT(*) DESC)  AS units_rank,
       ROUND(SUM(price), 0)                     AS revenue,
       DENSE_RANK() OVER (ORDER BY SUM(price) DESC) AS revenue_rank,
       ROUND(AVG(price), 2)                     AS avg_unit_price,
       COUNT(DISTINCT product_id)               AS distinct_products
FROM v_item_detail WHERE order_status = 'delivered'
GROUP BY category ORDER BY units_sold DESC LIMIT 15;
