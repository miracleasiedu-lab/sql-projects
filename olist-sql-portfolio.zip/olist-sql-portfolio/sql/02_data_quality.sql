/* =====================================================================
   02_data_quality.sql
   Stage 2–3: Key assessment & data-quality profiling on the RAW layer
   Every check runs against olist_stg (text columns, exactly as supplied).
   Empty strings ('') are how the CSVs encode missing values.
   ===================================================================== */
USE olist_stg;

/* ---------- 1. Missing values per table (empty string = missing) ---------- */
-- @Q DQ01_missing_orders
SELECT COUNT(*)                                         AS total_rows,
       SUM(order_id = '')                               AS order_id,
       SUM(customer_id = '')                            AS customer_id,
       SUM(order_status = '')                           AS order_status,
       SUM(order_purchase_timestamp = '')               AS purchase_ts,
       SUM(order_approved_at = '')                      AS approved_at,
       SUM(order_delivered_carrier_date = '')           AS delivered_carrier,
       SUM(order_delivered_customer_date = '')          AS delivered_customer,
       SUM(order_estimated_delivery_date = '')          AS estimated_delivery
FROM stg_orders;

-- @Q DQ02_missing_products
SELECT COUNT(*)                              AS total_rows,
       SUM(product_category_name = '')       AS category,
       SUM(product_name_lenght = '')         AS name_length,
       SUM(product_description_lenght = '')  AS description_length,
       SUM(product_photos_qty = '')          AS photos_qty,
       SUM(product_weight_g = '')            AS weight_g,
       SUM(product_length_cm = '')           AS length_cm,
       SUM(product_height_cm = '')           AS height_cm,
       SUM(product_width_cm = '')            AS width_cm
FROM stg_products;

-- @Q DQ03_missing_reviews
SELECT COUNT(*)                                   AS total_rows,
       SUM(review_comment_title = '')             AS comment_title_missing,
       ROUND(100 * AVG(review_comment_title = ''), 2)   AS pct_title_missing,
       SUM(review_comment_message = '')           AS comment_message_missing,
       ROUND(100 * AVG(review_comment_message = ''), 2) AS pct_message_missing,
       SUM(review_score = '')                     AS score_missing
FROM stg_order_reviews;

-- @Q DQ04_missing_other_tables
SELECT 'customers' AS tbl,
       SUM(customer_id='') + SUM(customer_unique_id='') + SUM(customer_zip_code_prefix='')
       + SUM(customer_city='') + SUM(customer_state='') AS missing_cells FROM stg_customers
UNION ALL
SELECT 'order_items',
       SUM(order_id='') + SUM(order_item_id='') + SUM(product_id='') + SUM(seller_id='')
       + SUM(shipping_limit_date='') + SUM(price='') + SUM(freight_value='') FROM stg_order_items
UNION ALL
SELECT 'order_payments',
       SUM(order_id='') + SUM(payment_sequential='') + SUM(payment_type='')
       + SUM(payment_installments='') + SUM(payment_value='') FROM stg_order_payments
UNION ALL
SELECT 'sellers',
       SUM(seller_id='') + SUM(seller_zip_code_prefix='') + SUM(seller_city='') + SUM(seller_state='')
FROM stg_sellers
UNION ALL
SELECT 'geolocation',
       SUM(geolocation_zip_code_prefix='') + SUM(geolocation_lat='') + SUM(geolocation_lng='')
       + SUM(geolocation_city='') + SUM(geolocation_state='') FROM stg_geolocation
UNION ALL
SELECT 'category_translation',
       SUM(product_category_name='') + SUM(product_category_name_english='') FROM stg_category_translation;

/* ---------- 2. Key uniqueness / candidate keys ---------- */
-- @Q DQ05_key_uniqueness
SELECT 'orders.order_id' AS candidate_key, COUNT(*) AS total_rows, COUNT(DISTINCT order_id) AS distinct_values FROM stg_orders
UNION ALL SELECT 'orders.customer_id', COUNT(*), COUNT(DISTINCT customer_id) FROM stg_orders
UNION ALL SELECT 'customers.customer_id', COUNT(*), COUNT(DISTINCT customer_id) FROM stg_customers
UNION ALL SELECT 'customers.customer_unique_id', COUNT(*), COUNT(DISTINCT customer_unique_id) FROM stg_customers
UNION ALL SELECT 'order_items.order_id', COUNT(*), COUNT(DISTINCT order_id) FROM stg_order_items
UNION ALL SELECT 'order_items.(order_id, order_item_id)', COUNT(*), COUNT(DISTINCT order_id, order_item_id) FROM stg_order_items
UNION ALL SELECT 'order_payments.order_id', COUNT(*), COUNT(DISTINCT order_id) FROM stg_order_payments
UNION ALL SELECT 'order_payments.(order_id, payment_sequential)', COUNT(*), COUNT(DISTINCT order_id, payment_sequential) FROM stg_order_payments
UNION ALL SELECT 'order_reviews.review_id', COUNT(*), COUNT(DISTINCT review_id) FROM stg_order_reviews
UNION ALL SELECT 'order_reviews.order_id', COUNT(*), COUNT(DISTINCT order_id) FROM stg_order_reviews
UNION ALL SELECT 'order_reviews.(review_id, order_id)', COUNT(*), COUNT(DISTINCT review_id, order_id) FROM stg_order_reviews
UNION ALL SELECT 'products.product_id', COUNT(*), COUNT(DISTINCT product_id) FROM stg_products
UNION ALL SELECT 'sellers.seller_id', COUNT(*), COUNT(DISTINCT seller_id) FROM stg_sellers
UNION ALL SELECT 'geolocation.zip_code_prefix', COUNT(*), COUNT(DISTINCT geolocation_zip_code_prefix) FROM stg_geolocation
UNION ALL SELECT 'category_translation.product_category_name', COUNT(*), COUNT(DISTINCT product_category_name) FROM stg_category_translation;

/* ---------- 3. Fully duplicated rows ---------- */
-- @Q DQ06_full_row_duplicates
SELECT 'customers' AS tbl, COUNT(*) - (SELECT COUNT(*) FROM (SELECT DISTINCT * FROM stg_customers) d) AS duplicate_rows FROM stg_customers
UNION ALL SELECT 'orders', COUNT(*) - (SELECT COUNT(*) FROM (SELECT DISTINCT * FROM stg_orders) d) FROM stg_orders
UNION ALL SELECT 'order_items', COUNT(*) - (SELECT COUNT(*) FROM (SELECT DISTINCT * FROM stg_order_items) d) FROM stg_order_items
UNION ALL SELECT 'order_payments', COUNT(*) - (SELECT COUNT(*) FROM (SELECT DISTINCT * FROM stg_order_payments) d) FROM stg_order_payments
UNION ALL SELECT 'order_reviews', COUNT(*) - (SELECT COUNT(*) FROM (SELECT DISTINCT * FROM stg_order_reviews) d) FROM stg_order_reviews
UNION ALL SELECT 'products', COUNT(*) - (SELECT COUNT(*) FROM (SELECT DISTINCT * FROM stg_products) d) FROM stg_products
UNION ALL SELECT 'sellers', COUNT(*) - (SELECT COUNT(*) FROM (SELECT DISTINCT * FROM stg_sellers) d) FROM stg_sellers
UNION ALL SELECT 'geolocation', COUNT(*) - (SELECT COUNT(*) FROM (SELECT DISTINCT * FROM stg_geolocation) d) FROM stg_geolocation;

/* ---------- 4. Repeat-customer structure (customer_id vs customer_unique_id) ---------- */
-- @Q DQ07_customer_unique_id_distribution
SELECT orders_per_unique_customer, COUNT(*) AS unique_customers
FROM (SELECT customer_unique_id, COUNT(*) AS orders_per_unique_customer
      FROM stg_customers GROUP BY customer_unique_id) x
GROUP BY orders_per_unique_customer
ORDER BY orders_per_unique_customer;

/* ---------- 5. Review grain anomalies ---------- */
-- @Q DQ08_review_grain
SELECT
  (SELECT COUNT(*) FROM (SELECT order_id FROM stg_order_reviews GROUP BY order_id HAVING COUNT(*) > 1) a)
      AS orders_with_multiple_reviews,
  (SELECT COUNT(*) FROM (SELECT order_id FROM stg_order_reviews GROUP BY order_id
                         HAVING COUNT(DISTINCT review_score) > 1) b)
      AS of_which_conflicting_scores,
  (SELECT COUNT(*) FROM (SELECT review_id FROM stg_order_reviews GROUP BY review_id
                         HAVING COUNT(DISTINCT order_id) > 1) c)
      AS review_ids_reused_across_orders;

/* ---------- 6. Multi-row-per-order structure (join inflation risk) ---------- */
-- @Q DQ09_rows_per_order
SELECT 'order_items' AS tbl, SUM(n) AS rows_, COUNT(*) AS orders,
       SUM(n > 1) AS orders_with_gt1_row, MAX(n) AS max_rows_per_order
FROM (SELECT order_id, COUNT(*) n FROM stg_order_items GROUP BY order_id) t
UNION ALL
SELECT 'order_payments', SUM(n), COUNT(*), SUM(n > 1), MAX(n)
FROM (SELECT order_id, COUNT(*) n FROM stg_order_payments GROUP BY order_id) t
UNION ALL
SELECT 'order_reviews', SUM(n), COUNT(*), SUM(n > 1), MAX(n)
FROM (SELECT order_id, COUNT(*) n FROM stg_order_reviews GROUP BY order_id) t;

/* ---------- 7. Invalid / suspicious numerical values ---------- */
-- @Q DQ10_numeric_ranges
SELECT 'order_items.price' AS measure, MIN(price + 0) AS min_val, MAX(price + 0) AS max_val,
       SUM(price + 0 <= 0) AS zero_or_negative FROM stg_order_items
UNION ALL SELECT 'order_items.freight_value', MIN(freight_value + 0), MAX(freight_value + 0), SUM(freight_value + 0 = 0) FROM stg_order_items
UNION ALL SELECT 'payments.payment_value', MIN(payment_value + 0), MAX(payment_value + 0), SUM(payment_value + 0 = 0) FROM stg_order_payments
UNION ALL SELECT 'payments.payment_installments', MIN(payment_installments + 0), MAX(payment_installments + 0), SUM(payment_installments + 0 = 0) FROM stg_order_payments
UNION ALL SELECT 'products.product_weight_g', MIN(NULLIF(product_weight_g,'') + 0), MAX(NULLIF(product_weight_g,'') + 0), SUM(product_weight_g <> '' AND product_weight_g + 0 = 0) FROM stg_products
UNION ALL SELECT 'reviews.review_score', MIN(review_score + 0), MAX(review_score + 0), SUM(review_score + 0 NOT BETWEEN 1 AND 5) FROM stg_order_reviews;

-- @Q DQ11_payment_type_values
SELECT payment_type, COUNT(*) AS rows_, SUM(payment_value + 0 = 0) AS zero_value_rows
FROM stg_order_payments GROUP BY payment_type ORDER BY rows_ DESC;

/* ---------- 8. Date validity & chronological logic ---------- */
-- @Q DQ12_date_parse_check
SELECT
  SUM(order_purchase_timestamp <> '' AND STR_TO_DATE(order_purchase_timestamp, '%Y-%m-%d %H:%i:%s') IS NULL)      AS bad_purchase,
  SUM(order_approved_at <> '' AND STR_TO_DATE(order_approved_at, '%Y-%m-%d %H:%i:%s') IS NULL)                    AS bad_approved,
  SUM(order_delivered_carrier_date <> '' AND STR_TO_DATE(order_delivered_carrier_date, '%Y-%m-%d %H:%i:%s') IS NULL)  AS bad_carrier,
  SUM(order_delivered_customer_date <> '' AND STR_TO_DATE(order_delivered_customer_date, '%Y-%m-%d %H:%i:%s') IS NULL) AS bad_customer,
  SUM(order_estimated_delivery_date <> '' AND STR_TO_DATE(order_estimated_delivery_date, '%Y-%m-%d %H:%i:%s') IS NULL) AS bad_estimated,
  MIN(order_purchase_timestamp) AS first_purchase,
  MAX(order_purchase_timestamp) AS last_purchase
FROM stg_orders;

-- @Q DQ13_chronology_violations
SELECT
  SUM(order_approved_at <> '' AND order_approved_at < order_purchase_timestamp)                    AS approved_before_purchase,
  SUM(order_delivered_carrier_date <> '' AND order_approved_at <> ''
      AND order_delivered_carrier_date < order_approved_at)                                         AS carrier_before_approval,
  SUM(order_delivered_carrier_date <> '' AND order_delivered_carrier_date < order_purchase_timestamp) AS carrier_before_purchase,
  SUM(order_delivered_customer_date <> '' AND order_delivered_customer_date < order_purchase_timestamp) AS delivered_before_purchase,
  SUM(order_delivered_customer_date <> '' AND order_delivered_carrier_date <> ''
      AND order_delivered_customer_date < order_delivered_carrier_date)                             AS delivered_before_carrier
FROM stg_orders;

-- @Q DQ14_status_vs_timestamps
SELECT order_status,
       COUNT(*)                                   AS orders,
       SUM(order_approved_at = '')                AS no_approval_ts,
       SUM(order_delivered_carrier_date = '')     AS no_carrier_ts,
       SUM(order_delivered_customer_date = '')    AS no_delivery_ts,
       SUM(order_delivered_customer_date <> '')   AS has_delivery_ts
FROM stg_orders GROUP BY order_status ORDER BY orders DESC;

-- @Q DQ15_monthly_order_volume
SELECT DATE_FORMAT(order_purchase_timestamp, '%Y-%m') AS purchase_month, COUNT(*) AS orders
FROM stg_orders GROUP BY purchase_month ORDER BY purchase_month;

/* ---------- 9. Category consistency ---------- */
-- @Q DQ16_untranslated_categories
SELECT CASE WHEN p.product_category_name = '' THEN '(blank)' ELSE p.product_category_name END AS product_category_name,
       COUNT(*) AS products
FROM stg_products p
LEFT JOIN stg_category_translation t ON t.product_category_name = p.product_category_name
WHERE t.product_category_name IS NULL
GROUP BY 1 ORDER BY products DESC;

/* ---------- 10. Geographic consistency ---------- */
-- @Q DQ17_geolocation_profile
SELECT COUNT(*)                                       AS raw_rows,
       (SELECT COUNT(*) FROM (SELECT DISTINCT * FROM stg_geolocation) d) AS distinct_rows,
       COUNT(DISTINCT geolocation_zip_code_prefix)   AS distinct_zip_prefixes,
       SUM(geolocation_lat + 0 NOT BETWEEN -33.75 AND 5.27
           OR geolocation_lng + 0 NOT BETWEEN -73.99 AND -34.79) AS points_outside_brazil_bbox,
       (SELECT COUNT(*) FROM (SELECT geolocation_zip_code_prefix FROM stg_geolocation
                              GROUP BY 1 HAVING COUNT(DISTINCT geolocation_state) > 1) s) AS zips_in_gt1_state,
       (SELECT COUNT(*) FROM (SELECT geolocation_zip_code_prefix FROM stg_geolocation
                              GROUP BY 1 HAVING COUNT(DISTINCT geolocation_city) > 1) c) AS zips_with_gt1_city_spelling
FROM stg_geolocation;

-- NOTE: the default collation utf8mb4_0900_ai_ci is accent-INSENSITIVE, so a
-- plain GROUP BY silently merges 'são paulo' into 'sao paulo'. Grouping with a
-- binary collation exposes the true spelling variants.
-- @Q DQ18_city_spelling_variants_example
SELECT geolocation_city COLLATE utf8mb4_bin AS geolocation_city_exact, COUNT(*) AS rows_
FROM stg_geolocation
WHERE geolocation_zip_code_prefix BETWEEN '01000' AND '05999'      -- São Paulo capital ZIP range
GROUP BY geolocation_city_exact ORDER BY rows_ DESC;

-- @Q DQ19_dirty_seller_cities
SELECT seller_city, seller_state, COUNT(*) AS sellers
FROM stg_sellers
WHERE seller_city REGEXP '[/,@0-9\\\\]| - |´'
GROUP BY seller_city, seller_state ORDER BY sellers DESC, seller_city;

/* ---------- 11. Orphans & referential integrity ---------- */
-- @Q DQ20_orphan_summary
SELECT 'orders.customer_id -> customers' AS relationship,
       SUM(c.customer_id IS NULL) AS orphan_rows FROM stg_orders o LEFT JOIN stg_customers c ON c.customer_id = o.customer_id
UNION ALL SELECT 'order_items.order_id -> orders', SUM(o.order_id IS NULL)
  FROM stg_order_items i LEFT JOIN stg_orders o ON o.order_id = i.order_id
UNION ALL SELECT 'order_items.product_id -> products', SUM(p.product_id IS NULL)
  FROM stg_order_items i LEFT JOIN stg_products p ON p.product_id = i.product_id
UNION ALL SELECT 'order_items.seller_id -> sellers', SUM(s.seller_id IS NULL)
  FROM stg_order_items i LEFT JOIN stg_sellers s ON s.seller_id = i.seller_id
UNION ALL SELECT 'order_payments.order_id -> orders', SUM(o.order_id IS NULL)
  FROM stg_order_payments p LEFT JOIN stg_orders o ON o.order_id = p.order_id
UNION ALL SELECT 'order_reviews.order_id -> orders', SUM(o.order_id IS NULL)
  FROM stg_order_reviews r LEFT JOIN stg_orders o ON o.order_id = r.order_id
UNION ALL SELECT 'products.category -> translation (non-blank)', SUM(t.product_category_name IS NULL)
  FROM stg_products p LEFT JOIN stg_category_translation t ON t.product_category_name = p.product_category_name
  WHERE p.product_category_name <> ''
UNION ALL SELECT 'customers.zip -> geolocation', SUM(NOT EXISTS (SELECT 1 FROM stg_geolocation g
                     WHERE g.geolocation_zip_code_prefix = c.customer_zip_code_prefix))
  FROM stg_customers c
UNION ALL SELECT 'sellers.zip -> geolocation', SUM(NOT EXISTS (SELECT 1 FROM stg_geolocation g
                     WHERE g.geolocation_zip_code_prefix = s.seller_zip_code_prefix))
  FROM stg_sellers s;

-- @Q DQ21_parents_without_children
SELECT 'orders without items' AS check_, COUNT(*) AS rows_
  FROM stg_orders o WHERE NOT EXISTS (SELECT 1 FROM stg_order_items i WHERE i.order_id = o.order_id)
UNION ALL SELECT 'orders without payments', COUNT(*)
  FROM stg_orders o WHERE NOT EXISTS (SELECT 1 FROM stg_order_payments p WHERE p.order_id = o.order_id)
UNION ALL SELECT 'orders without reviews', COUNT(*)
  FROM stg_orders o WHERE NOT EXISTS (SELECT 1 FROM stg_order_reviews r WHERE r.order_id = o.order_id)
UNION ALL SELECT 'customers without orders', COUNT(*)
  FROM stg_customers c WHERE NOT EXISTS (SELECT 1 FROM stg_orders o WHERE o.customer_id = c.customer_id)
UNION ALL SELECT 'products never sold', COUNT(*)
  FROM stg_products p WHERE NOT EXISTS (SELECT 1 FROM stg_order_items i WHERE i.product_id = p.product_id)
UNION ALL SELECT 'sellers with no sales', COUNT(*)
  FROM stg_sellers s WHERE NOT EXISTS (SELECT 1 FROM stg_order_items i WHERE i.seller_id = s.seller_id);

-- @Q DQ22_orders_without_items_by_status
SELECT o.order_status, COUNT(*) AS orders_without_items
FROM stg_orders o
WHERE NOT EXISTS (SELECT 1 FROM stg_order_items i WHERE i.order_id = o.order_id)
GROUP BY o.order_status ORDER BY orders_without_items DESC;

/* ---------- 12. Cross-table reconciliation: items vs payments ---------- */
-- @Q DQ23_items_vs_payments_reconciliation
WITH items AS (SELECT order_id, SUM(price + freight_value) AS item_total FROM stg_order_items GROUP BY order_id),
     pays  AS (SELECT order_id, SUM(payment_value + 0)    AS paid_total FROM stg_order_payments GROUP BY order_id)
SELECT COUNT(*)                                   AS orders_in_both,
       SUM(ABS(paid_total - item_total) <= 0.01)  AS match_within_1_centavo,
       SUM(paid_total - item_total > 0.01)        AS paid_more_than_items,
       SUM(item_total - paid_total > 0.01)        AS paid_less_than_items,
       ROUND(SUM(item_total), 2)                  AS sum_price_plus_freight,
       ROUND(SUM(paid_total), 2)                  AS sum_payment_value
FROM items JOIN pays USING (order_id);
