/* =====================================================================
   03_clean_model.sql
   Stage 4–5: SQL cleaning + relational data model (database: olist)
   ---------------------------------------------------------------------
   Builds typed, constrained tables from the olist_stg raw layer.
   Principles
     * No valid record is deleted because it contains NULLs.
     * Empty strings become NULL (NULLIF) — never fake values.
     * Only true duplicates (geolocation) are removed.
     * Every PK / FK below is ENFORCED by InnoDB, so the load itself
       proves referential integrity.
   ===================================================================== */

DROP DATABASE IF EXISTS olist;
CREATE DATABASE olist CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE olist;

/* ---------------------------------------------------------------------
   Helper: city-name standardiser
   - lower-case, trim, collapse spaces
   - strip Portuguese diacritics (são paulo -> sao paulo)
   - normalise acute-accent apostrophe (d´oeste -> d'oeste)
   - remove the stray mojibake byte '£' seen in 'sa£o paulo'
   --------------------------------------------------------------------- */
DROP FUNCTION IF EXISTS fn_std_city;
DELIMITER //
CREATE FUNCTION fn_std_city(s VARCHAR(200)) RETURNS VARCHAR(200)
DETERMINISTIC NO SQL
BEGIN
  DECLARE r VARCHAR(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;
  IF s IS NULL OR TRIM(s) = '' THEN RETURN NULL; END IF;
  SET r = LOWER(TRIM(s));
  SET r = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(r,'á','a'),'à','a'),'â','a'),'ã','a'),'ä','a');
  SET r = REPLACE(REPLACE(REPLACE(REPLACE(r,'é','e'),'ê','e'),'è','e'),'ë','e');
  SET r = REPLACE(REPLACE(REPLACE(REPLACE(r,'í','i'),'î','i'),'ì','i'),'ï','i');
  SET r = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(r,'ó','o'),'ô','o'),'õ','o'),'ò','o'),'ö','o');
  SET r = REPLACE(REPLACE(REPLACE(REPLACE(r,'ú','u'),'û','u'),'ù','u'),'ü','u');
  SET r = REPLACE(REPLACE(r,'ç','c'),'ñ','n');
  SET r = REPLACE(REPLACE(REPLACE(r,'´',''''),'`',''''),'£','');
  WHILE INSTR(r,'  ') > 0 DO SET r = REPLACE(r,'  ',' '); END WHILE;
  RETURN TRIM(r);
END //
DELIMITER ;

/* =====================================================================
   1. category_translation   (PK product_category_name)
   ---------------------------------------------------------------------
   71 supplied rows + 2 categories that exist in products but are missing
   from the supplied translation file (13 products). They are added with
   is_supplemented = 1 so the addition is transparent.
   ===================================================================== */
CREATE TABLE category_translation (
  product_category_name         VARCHAR(80) NOT NULL,
  product_category_name_english VARCHAR(80) NOT NULL,
  is_supplemented               TINYINT(1)  NOT NULL DEFAULT 0,
  PRIMARY KEY (product_category_name)
) ENGINE = InnoDB;

INSERT INTO category_translation (product_category_name, product_category_name_english)
SELECT TRIM(product_category_name), TRIM(product_category_name_english)
FROM olist_stg.stg_category_translation;

INSERT INTO category_translation VALUES
  ('pc_gamer', 'pc_gamer', 1),
  ('portateis_cozinha_e_preparadores_de_alimentos', 'portable_kitchen_food_processors', 1);

/* =====================================================================
   2. zip_code   (PK zip_code_prefix)  — conformed geography dimension
   ---------------------------------------------------------------------
   Raw geolocation: 1,000,163 rows, 279,667 exact duplicates, 19,015
   prefixes, 42 points outside Brazil's bounding box, conflicting city
   spellings/states for some prefixes. The prefix is NOT unique, so it
   cannot be a key as supplied.
   Transformation:
     a) DISTINCT to remove exact duplicate rows
     b) discard coordinates outside Brazil (lat -33.75..5.27,
        lng -73.99..-34.79)
     c) one row per prefix: centroid = AVG(lat), AVG(lng);
        city/state = most frequent (modal) standardised value
     d) UNION in every prefix used by customers/sellers but absent from
        geolocation (has_geolocation = 0, coordinates NULL) so that the
        customer and seller FKs can be enforced without dropping rows.
   ===================================================================== */
CREATE TABLE zip_code (
  zip_code_prefix   CHAR(5)       NOT NULL,
  latitude          DECIMAL(10,7) NULL,
  longitude         DECIMAL(10,7) NULL,
  geo_city          VARCHAR(100)  NULL,
  geo_state         CHAR(2)       NULL,
  geo_points        INT           NOT NULL DEFAULT 0,  -- distinct valid raw points behind the centroid
  has_geolocation   TINYINT(1)    NOT NULL,
  PRIMARY KEY (zip_code_prefix)
) ENGINE = InnoDB;

INSERT INTO zip_code
WITH dedup AS (                                  -- (a) exact duplicates removed
  SELECT DISTINCT geolocation_zip_code_prefix AS zip,
         CAST(geolocation_lat AS DECIMAL(18,14)) AS lat,
         CAST(geolocation_lng AS DECIMAL(18,14)) AS lng,
         fn_std_city(geolocation_city)          AS city,
         UPPER(TRIM(geolocation_state))         AS state
  FROM olist_stg.stg_geolocation
),
valid AS (                                       -- (b) inside Brazil only
  SELECT * FROM dedup
  WHERE lat BETWEEN -33.75 AND 5.27 AND lng BETWEEN -73.99 AND -34.79
),
centroid AS (                                    -- (c) one row per prefix
  SELECT zip, AVG(lat) AS lat, AVG(lng) AS lng, COUNT(*) AS pts
  FROM valid GROUP BY zip
),
modal_city AS (
  SELECT zip, city, state,
         ROW_NUMBER() OVER (PARTITION BY zip ORDER BY COUNT(*) DESC, city) AS rn
  FROM dedup GROUP BY zip, city, state
)
SELECT m.zip, c.lat, c.lng, m.city, m.state, COALESCE(c.pts, 0), 1
FROM modal_city m
LEFT JOIN centroid c ON c.zip = m.zip            -- prefixes whose only points were invalid keep NULL coords
WHERE m.rn = 1;

INSERT INTO zip_code (zip_code_prefix, has_geolocation)           -- (d)
SELECT z, 0 FROM (
  SELECT customer_zip_code_prefix AS z FROM olist_stg.stg_customers
  UNION
  SELECT seller_zip_code_prefix FROM olist_stg.stg_sellers
) u
WHERE z NOT IN (SELECT zip_code_prefix FROM zip_code);

/* =====================================================================
   3. customers   (PK customer_id; FK zip -> zip_code)
   ---------------------------------------------------------------------
   customer_id        = one per ORDER (order-level customer key)
   customer_unique_id = the real person; repeats across orders
   ===================================================================== */
CREATE TABLE customers (
  customer_id              CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  customer_unique_id       CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  customer_zip_code_prefix CHAR(5)      NOT NULL,
  customer_city            VARCHAR(100) NOT NULL,
  customer_state           CHAR(2)      NOT NULL,
  PRIMARY KEY (customer_id),
  KEY ix_customers_unique (customer_unique_id),
  KEY ix_customers_state (customer_state),
  CONSTRAINT fk_customers_zip FOREIGN KEY (customer_zip_code_prefix)
      REFERENCES zip_code (zip_code_prefix)
) ENGINE = InnoDB;

INSERT INTO customers
SELECT customer_id, customer_unique_id, customer_zip_code_prefix,
       fn_std_city(customer_city), UPPER(TRIM(customer_state))
FROM olist_stg.stg_customers;

/* =====================================================================
   4. sellers   (PK seller_id; FK zip -> zip_code)
   ---------------------------------------------------------------------
   seller_city contained free text such as 'sao paulo - sp',
   'auriflama/sp', 'novo hamburgo, rio grande do sul, brasil',
   an e-mail address and a number. Rule: keep the text before the first
   '/', '\', ',' or ' - '; values that are not city names -> NULL;
   two unambiguous abbreviations expanded. seller_state is authoritative.
   ===================================================================== */
CREATE TABLE sellers (
  seller_id              CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  seller_zip_code_prefix CHAR(5)      NOT NULL,
  seller_city            VARCHAR(100) NULL,
  seller_state           CHAR(2)      NOT NULL,
  PRIMARY KEY (seller_id),
  KEY ix_sellers_state (seller_state),
  CONSTRAINT fk_sellers_zip FOREIGN KEY (seller_zip_code_prefix)
      REFERENCES zip_code (zip_code_prefix)
) ENGINE = InnoDB;

INSERT INTO sellers
SELECT seller_id, seller_zip_code_prefix,
       CASE
         WHEN c REGEXP '[0-9@]' THEN NULL                      -- '04482255', e-mail address
         WHEN c = 'sbc' THEN 'sao bernardo do campo'
         WHEN c = 'sp'  THEN 'sao paulo'
         ELSE c
       END,
       UPPER(TRIM(seller_state))
FROM (
  SELECT seller_id, seller_zip_code_prefix, seller_state,
         TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING_INDEX(
              fn_std_city(seller_city), '/', 1), '\\', 1), ',', 1), ' - ', 1)) AS c
  FROM olist_stg.stg_sellers
) s;

/* =====================================================================
   5. products   (PK product_id; FK category -> category_translation)
   ---------------------------------------------------------------------
   * 610 products have no category (and no name/description/photo
     metadata). They are SOLD products, so they are kept; category stays
     NULL and is labelled 'uncategorized' at reporting time.
   * 2 products have no dimensions/weight -> NULL.
   * 4 products report weight 0 g, which is physically impossible ->
     set to NULL (flagged by weight_was_zero) instead of deleting.
   * Source column names product_name_lenght / product_description_lenght
     are misspelled; kept verbatim for traceability.
   ===================================================================== */
CREATE TABLE products (
  product_id                 CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  product_category_name      VARCHAR(80)       NULL,
  product_name_lenght        SMALLINT UNSIGNED NULL,
  product_description_lenght SMALLINT UNSIGNED NULL,
  product_photos_qty         TINYINT UNSIGNED  NULL,
  product_weight_g           INT UNSIGNED      NULL,
  product_length_cm          SMALLINT UNSIGNED NULL,
  product_height_cm          SMALLINT UNSIGNED NULL,
  product_width_cm           SMALLINT UNSIGNED NULL,
  weight_was_zero            TINYINT(1)        NOT NULL DEFAULT 0,
  PRIMARY KEY (product_id),
  KEY ix_products_category (product_category_name),
  CONSTRAINT fk_products_category FOREIGN KEY (product_category_name)
      REFERENCES category_translation (product_category_name)
) ENGINE = InnoDB;

INSERT INTO products
SELECT product_id,
       NULLIF(TRIM(product_category_name), ''),
       NULLIF(product_name_lenght, ''),
       NULLIF(product_description_lenght, ''),
       NULLIF(product_photos_qty, ''),
       NULLIF(NULLIF(product_weight_g, ''), '0'),
       NULLIF(product_length_cm, ''),
       NULLIF(product_height_cm, ''),
       NULLIF(product_width_cm, ''),
       (product_weight_g = '0')
FROM olist_stg.stg_products;

/* =====================================================================
   6. orders   (PK order_id; FK customer_id -> customers, UNIQUE => 1:1)
   ---------------------------------------------------------------------
   * Timestamps typed as DATETIME; blanks -> NULL (160 approvals,
     1,783 carrier and 2,965 customer-delivery timestamps). Missing
     timestamps are legitimate for undelivered/cancelled orders and are
     NOT deleted.
   * Chronology anomalies (e.g. 1,359 carrier hand-overs logged before
     approval) are retained in the table and flagged in v_order_summary;
     delivery-time KPIs only use orders with a valid delivery sequence.
   * order_status kept as an ENUM of the 8 observed values.
   ===================================================================== */
CREATE TABLE orders (
  order_id                      CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  customer_id                   CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  order_status                  ENUM('created','approved','invoiced','processing','shipped',
                                     'delivered','canceled','unavailable') NOT NULL,
  order_purchase_timestamp      DATETIME NOT NULL,
  order_approved_at             DATETIME NULL,
  order_delivered_carrier_date  DATETIME NULL,
  order_delivered_customer_date DATETIME NULL,
  order_estimated_delivery_date DATETIME NOT NULL,
  PRIMARY KEY (order_id),
  UNIQUE KEY uq_orders_customer (customer_id),
  KEY ix_orders_purchase (order_purchase_timestamp),
  KEY ix_orders_status (order_status),
  CONSTRAINT fk_orders_customer FOREIGN KEY (customer_id)
      REFERENCES customers (customer_id)
) ENGINE = InnoDB;

INSERT INTO orders
SELECT order_id, customer_id, LOWER(TRIM(order_status)),
       STR_TO_DATE(order_purchase_timestamp, '%Y-%m-%d %H:%i:%s'),
       STR_TO_DATE(NULLIF(order_approved_at, ''), '%Y-%m-%d %H:%i:%s'),
       STR_TO_DATE(NULLIF(order_delivered_carrier_date, ''), '%Y-%m-%d %H:%i:%s'),
       STR_TO_DATE(NULLIF(order_delivered_customer_date, ''), '%Y-%m-%d %H:%i:%s'),
       STR_TO_DATE(order_estimated_delivery_date, '%Y-%m-%d %H:%i:%s')
FROM olist_stg.stg_orders;

/* =====================================================================
   7. order_items   (PK order_id + order_item_id; FKs order/product/seller)
   ---------------------------------------------------------------------
   Grain: one row per item line. order_item_id is a 1..n sequence within
   the order, so it is only unique in combination with order_id.
   383 lines with freight_value = 0 are kept (free shipping is valid).
   ===================================================================== */
CREATE TABLE order_items (
  order_id            CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  order_item_id       TINYINT UNSIGNED NOT NULL,
  product_id          CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  seller_id           CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  shipping_limit_date DATETIME      NOT NULL,
  price               DECIMAL(10,2) NOT NULL,
  freight_value       DECIMAL(10,2) NOT NULL,
  PRIMARY KEY (order_id, order_item_id),
  KEY ix_items_product (product_id),
  KEY ix_items_seller (seller_id),
  CONSTRAINT fk_items_order   FOREIGN KEY (order_id)   REFERENCES orders (order_id),
  CONSTRAINT fk_items_product FOREIGN KEY (product_id) REFERENCES products (product_id),
  CONSTRAINT fk_items_seller  FOREIGN KEY (seller_id)  REFERENCES sellers (seller_id),
  CONSTRAINT ck_items_price   CHECK (price > 0),
  CONSTRAINT ck_items_freight CHECK (freight_value >= 0)
) ENGINE = InnoDB;

INSERT INTO order_items
SELECT order_id, order_item_id, product_id, seller_id,
       STR_TO_DATE(shipping_limit_date, '%Y-%m-%d %H:%i:%s'),
       CAST(price AS DECIMAL(10,2)), CAST(freight_value AS DECIMAL(10,2))
FROM olist_stg.stg_order_items;

/* =====================================================================
   8. order_payments   (PK order_id + payment_sequential; FK order)
   ---------------------------------------------------------------------
   * 2 credit-card rows record 0 instalments; a payment has at least one
     instalment, so they are recoded to 1 (flagged installments_recoded).
   * 9 zero-value rows (6 voucher, 3 'not_defined') are kept: they are
     real records and do not affect revenue sums.
   ===================================================================== */
CREATE TABLE order_payments (
  order_id             CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  payment_sequential   TINYINT UNSIGNED  NOT NULL,
  payment_type         ENUM('credit_card','boleto','voucher','debit_card','not_defined') NOT NULL,
  payment_installments TINYINT UNSIGNED  NOT NULL,
  payment_value        DECIMAL(10,2)     NOT NULL,
  installments_recoded TINYINT(1)        NOT NULL DEFAULT 0,
  PRIMARY KEY (order_id, payment_sequential),
  CONSTRAINT fk_payments_order FOREIGN KEY (order_id) REFERENCES orders (order_id),
  CONSTRAINT ck_payments_value CHECK (payment_value >= 0)
) ENGINE = InnoDB;

INSERT INTO order_payments
SELECT order_id, payment_sequential, LOWER(TRIM(payment_type)),
       GREATEST(CAST(payment_installments AS UNSIGNED), 1),
       CAST(payment_value AS DECIMAL(10,2)),
       (payment_installments = '0')
FROM olist_stg.stg_order_payments;

/* =====================================================================
   9. order_reviews   (PK review_id + order_id; FK order)
   ---------------------------------------------------------------------
   review_id is NOT unique on its own (789 review_ids are attached to
   more than one order) and 547 orders have >1 review, so the natural
   key is the composite (review_id, order_id). Blank comment fields ->
   NULL; the rows are kept because the review_score is still valid.
   ===================================================================== */
CREATE TABLE order_reviews (
  review_id               CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  order_id                CHAR(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  review_score            TINYINT UNSIGNED NOT NULL,
  review_comment_title    VARCHAR(255) NULL,
  review_comment_message  TEXT         NULL,
  review_creation_date    DATETIME     NOT NULL,
  review_answer_timestamp DATETIME     NOT NULL,
  PRIMARY KEY (review_id, order_id),
  KEY ix_reviews_order (order_id),
  CONSTRAINT fk_reviews_order FOREIGN KEY (order_id) REFERENCES orders (order_id),
  CONSTRAINT ck_reviews_score CHECK (review_score BETWEEN 1 AND 5)
) ENGINE = InnoDB;

INSERT INTO order_reviews
SELECT review_id, order_id, review_score,
       NULLIF(TRIM(review_comment_title), ''),
       NULLIF(TRIM(review_comment_message), ''),
       STR_TO_DATE(review_creation_date, '%Y-%m-%d %H:%i:%s'),
       STR_TO_DATE(review_answer_timestamp, '%Y-%m-%d %H:%i:%s')
FROM olist_stg.stg_order_reviews;

/* =====================================================================
   10. Cleaning audit — row counts raw vs clean
   ===================================================================== */
-- @Q CL01_row_reconciliation
SELECT 'orders' AS table_name, (SELECT COUNT(*) FROM olist_stg.stg_orders) AS raw_rows, (SELECT COUNT(*) FROM orders) AS clean_rows
UNION ALL SELECT 'customers', (SELECT COUNT(*) FROM olist_stg.stg_customers), (SELECT COUNT(*) FROM customers)
UNION ALL SELECT 'order_items', (SELECT COUNT(*) FROM olist_stg.stg_order_items), (SELECT COUNT(*) FROM order_items)
UNION ALL SELECT 'order_payments', (SELECT COUNT(*) FROM olist_stg.stg_order_payments), (SELECT COUNT(*) FROM order_payments)
UNION ALL SELECT 'order_reviews', (SELECT COUNT(*) FROM olist_stg.stg_order_reviews), (SELECT COUNT(*) FROM order_reviews)
UNION ALL SELECT 'products', (SELECT COUNT(*) FROM olist_stg.stg_products), (SELECT COUNT(*) FROM products)
UNION ALL SELECT 'sellers', (SELECT COUNT(*) FROM olist_stg.stg_sellers), (SELECT COUNT(*) FROM sellers)
UNION ALL SELECT 'category_translation', (SELECT COUNT(*) FROM olist_stg.stg_category_translation), (SELECT COUNT(*) FROM category_translation)
UNION ALL SELECT 'geolocation -> zip_code', (SELECT COUNT(*) FROM olist_stg.stg_geolocation), (SELECT COUNT(*) FROM zip_code);

-- @Q CL02_zip_code_dimension
SELECT has_geolocation,
       COUNT(*)                     AS zip_prefixes,
       SUM(latitude IS NULL)        AS without_coordinates,
       SUM(geo_points)              AS valid_points_used
FROM zip_code GROUP BY has_geolocation;

-- @Q CL03_city_standardisation_effect
SELECT 'geolocation (raw, exact spelling)' AS source,
       COUNT(DISTINCT geolocation_city COLLATE utf8mb4_bin) AS distinct_city_values
FROM olist_stg.stg_geolocation
UNION ALL SELECT 'zip_code.geo_city (standardised)', COUNT(DISTINCT geo_city COLLATE utf8mb4_bin) FROM zip_code
UNION ALL SELECT 'customers (raw)', COUNT(DISTINCT customer_city COLLATE utf8mb4_bin) FROM olist_stg.stg_customers
UNION ALL SELECT 'customers (standardised)', COUNT(DISTINCT customer_city COLLATE utf8mb4_bin) FROM customers
UNION ALL SELECT 'sellers (raw)', COUNT(DISTINCT seller_city COLLATE utf8mb4_bin) FROM olist_stg.stg_sellers
UNION ALL SELECT 'sellers (standardised)', COUNT(DISTINCT seller_city COLLATE utf8mb4_bin) FROM sellers;

-- @Q CL04_seller_city_fixes
SELECT s.seller_city AS raw_value, c.seller_city AS cleaned_value, c.seller_state
FROM olist_stg.stg_sellers s JOIN sellers c USING (seller_id)
WHERE s.seller_city REGEXP '[/,@0-9\\\\]| - |´' OR s.seller_city IN ('sp', 'sbc')
ORDER BY raw_value;

-- @Q CL05_flags_set
SELECT 'products.weight_was_zero -> NULL' AS cleaning_rule, SUM(weight_was_zero) AS rows_affected FROM products
UNION ALL SELECT 'products.category NULL (kept, labelled uncategorized)', SUM(product_category_name IS NULL) FROM products
UNION ALL SELECT 'payments.installments 0 -> 1', SUM(installments_recoded) FROM order_payments
UNION ALL SELECT 'reviews.comment_message NULL (kept)', SUM(review_comment_message IS NULL) FROM order_reviews
UNION ALL SELECT 'category_translation supplemented', SUM(is_supplemented) FROM category_translation;
