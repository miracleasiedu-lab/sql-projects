/* =====================================================================
   09_multivariate.sql — Stage 10: 10 analyses using 3+ variables
   Delivered orders only, unless stated.
   ===================================================================== */
USE olist;

-- M1  Category x Customer State x Revenue
--     "What is the #1 and #2 category in each of our 8 largest states?"
-- @Q M01_top_categories_per_state
WITH state_cat AS (
  SELECT customer_state, category, SUM(price) AS revenue
  FROM v_item_detail WHERE order_status = 'delivered'
  GROUP BY customer_state, category
),
ranked AS (
  SELECT sc.*,
         RANK() OVER (PARTITION BY customer_state ORDER BY revenue DESC) AS rnk,
         100 * revenue / SUM(revenue) OVER (PARTITION BY customer_state) AS pct_of_state
  FROM state_cat sc
),
big_states AS (
  SELECT customer_state FROM state_cat GROUP BY customer_state
  ORDER BY SUM(revenue) DESC LIMIT 8
)
SELECT r.customer_state, r.rnk, r.category, ROUND(r.revenue, 0) AS revenue, ROUND(r.pct_of_state, 2) AS pct_of_state
FROM ranked r JOIN big_states b USING (customer_state)
WHERE r.rnk <= 2
ORDER BY (SELECT SUM(revenue) FROM state_cat s WHERE s.customer_state = r.customer_state) DESC, r.rnk;

-- M2  Seller x Category x Revenue
--     "Are our top-10 sellers specialists or generalists?"
-- @Q M02_top_seller_category_mix
WITH seller_cat AS (
  SELECT seller_id, category, SUM(price) AS revenue
  FROM v_item_detail WHERE order_status = 'delivered'
  GROUP BY seller_id, category
),
seller_tot AS (
  SELECT seller_id, SUM(revenue) AS seller_revenue, COUNT(*) AS categories,
         RANK() OVER (ORDER BY SUM(revenue) DESC) AS seller_rank
  FROM seller_cat GROUP BY seller_id
),
main_cat AS (
  SELECT seller_id, category, revenue,
         ROW_NUMBER() OVER (PARTITION BY seller_id ORDER BY revenue DESC) AS rn
  FROM seller_cat
)
SELECT t.seller_rank, LEFT(t.seller_id, 8) AS seller, ROUND(t.seller_revenue, 0) AS seller_revenue,
       t.categories, m.category AS main_category,
       ROUND(100 * m.revenue / t.seller_revenue, 1) AS main_category_pct
FROM seller_tot t JOIN main_cat m ON m.seller_id = t.seller_id AND m.rn = 1
WHERE t.seller_rank <= 10 ORDER BY t.seller_rank;

-- M3  Delivery Performance x Review Score x Customer State (states >= 1,000 orders)
--     "Is low satisfaction in some states explained by late delivery?"
-- @Q M03_state_delivery_review
SELECT customer_state,
       COUNT(*)                                                    AS orders,
       ROUND(AVG(delivery_days), 1)                                AS avg_delivery_days,
       ROUND(100 * AVG(is_late), 1)                                AS late_pct,
       ROUND(AVG(review_score), 2)                                 AS avg_review_all,
       ROUND(AVG(CASE WHEN is_late = 0 THEN review_score END), 2)  AS avg_review_on_time,
       ROUND(AVG(CASE WHEN is_late = 1 THEN review_score END), 2)  AS avg_review_late
FROM fact_order
WHERE order_status = 'delivered' AND is_late IS NOT NULL
GROUP BY customer_state HAVING COUNT(*) >= 1000
ORDER BY late_pct DESC;

-- M4  Payment Type x Instalments x Order Value
--     "Do instalments enable bigger baskets?"
-- @Q M04_payment_installments_value
SELECT main_payment_type,
       CASE WHEN max_installments = 1 THEN '1x'
            WHEN max_installments <= 3 THEN '2-3x'
            WHEN max_installments <= 6 THEN '4-6x'
            ELSE '7x+' END                       AS installment_band,
       COUNT(*)                                  AS orders,
       ROUND(AVG(payment_value), 2)              AS avg_order_paid,
       ROUND(SUM(payment_value), 0)              AS total_paid,
       ROUND(AVG(review_score), 2)               AS avg_review
FROM fact_order
WHERE order_status = 'delivered' AND main_payment_type IN ('credit_card', 'boleto', 'debit_card', 'voucher')
GROUP BY main_payment_type, installment_band
HAVING COUNT(*) >= 100
ORDER BY main_payment_type, installment_band;

-- M5  Month x Category x Revenue (top-5 categories, quarterly, complete quarters)
--     "Which leading categories are growing, which are stalling?"
-- @Q M05_quarter_category_revenue
WITH top5 AS (
  SELECT category FROM v_item_detail WHERE order_status = 'delivered'
  GROUP BY category ORDER BY SUM(price) DESC LIMIT 5
)
SELECT CONCAT(YEAR(order_purchase_timestamp), '-Q', QUARTER(order_purchase_timestamp)) AS yr_qtr,
       ROUND(SUM(CASE WHEN category = 'health_beauty'         THEN price END), 0) AS health_beauty,
       ROUND(SUM(CASE WHEN category = 'watches_gifts'         THEN price END), 0) AS watches_gifts,
       ROUND(SUM(CASE WHEN category = 'bed_bath_table'        THEN price END), 0) AS bed_bath_table,
       ROUND(SUM(CASE WHEN category = 'sports_leisure'        THEN price END), 0) AS sports_leisure,
       ROUND(SUM(CASE WHEN category = 'computers_accessories' THEN price END), 0) AS computers_accessories
FROM v_item_detail
WHERE order_status = 'delivered'
  AND category IN (SELECT category FROM top5)
  AND order_purchase_timestamp >= '2017-01-01' AND order_purchase_timestamp < '2018-07-01'
GROUP BY yr_qtr ORDER BY yr_qtr;

-- M6  Seller x Revenue x Review x Delivery performance — seller segments
--     (sellers with >= 30 delivered orders)
-- @Q M06_seller_segments
WITH seller_order AS (            -- seller-order grain: avoids counting an order once per item
  SELECT i.seller_id, i.order_id, SUM(i.price) AS revenue,
         MAX(i.order_delivered_carrier_date > i.shipping_limit_date) AS shipped_late
  FROM v_item_detail i WHERE i.order_status = 'delivered'
  GROUP BY i.seller_id, i.order_id
),
seller_perf AS (
  SELECT so.seller_id,
         COUNT(*)                   AS orders,
         SUM(so.revenue)            AS revenue,
         AVG(f.review_score)        AS avg_review,
         AVG(f.is_late)             AS late_rate,
         AVG(so.shipped_late)       AS handover_late_rate
  FROM seller_order so JOIN fact_order f USING (order_id)
  GROUP BY so.seller_id HAVING COUNT(*) >= 30
)
SELECT CASE WHEN avg_review >= 4.2 AND late_rate <= 0.06 THEN '1: Stars (review>=4.2, late<=6%)'
            WHEN avg_review >= 4.0                         THEN '2: Solid (review 4.0-4.2 or late>6%)'
            WHEN avg_review >= 3.5                         THEN '3: At risk (review 3.5-4.0)'
            ELSE                                                '4: Problem (review<3.5)' END AS segment,
       COUNT(*)                              AS sellers,
       ROUND(SUM(revenue), 0)                AS revenue,
       ROUND(100 * SUM(revenue) / SUM(SUM(revenue)) OVER (), 1) AS pct_revenue,
       ROUND(AVG(avg_review), 2)             AS avg_review,
       ROUND(100 * AVG(late_rate), 1)        AS avg_late_pct,
       ROUND(100 * AVG(handover_late_rate), 1) AS avg_carrier_handover_late_pct
FROM seller_perf GROUP BY segment ORDER BY segment;

-- M7  Customer State x Freight share x Delivery time x Review
--     "Do remote customers pay more for shipping, wait longer and rate us lower?"
-- @Q M07_region_freight_delivery_review
SELECT CASE WHEN customer_state IN ('SP') THEN '1: SP'
            WHEN customer_state IN ('RJ','MG','ES') THEN '2: Southeast ex-SP'
            WHEN customer_state IN ('PR','SC','RS') THEN '3: South'
            WHEN customer_state IN ('DF','GO','MT','MS') THEN '4: Centre-West'
            WHEN customer_state IN ('BA','SE','AL','PE','PB','RN','CE','PI','MA') THEN '5: Northeast'
            ELSE '6: North' END                        AS region,
       COUNT(*)                                         AS orders,
       ROUND(AVG(item_revenue), 2)                      AS aov,
       ROUND(100 * SUM(freight) / SUM(item_revenue), 1) AS freight_pct,
       ROUND(AVG(delivery_days), 1)                     AS avg_delivery_days,
       ROUND(100 * AVG(is_late), 1)                     AS late_pct,
       ROUND(AVG(review_score), 2)                      AS avg_review
FROM fact_order
WHERE order_status = 'delivered' AND delivery_days IS NOT NULL
GROUP BY region ORDER BY region;

-- M8  Day-of-week x Hour band x Orders x Revenue — when do customers buy?
-- @Q M08_weekday_hour_demand
SELECT DAYOFWEEK(order_purchase_timestamp)                       AS dow_num,
       DAYNAME(order_purchase_timestamp)                         AS weekday,
       SUM(HOUR(order_purchase_timestamp) BETWEEN 0 AND 5)       AS h00_05,
       SUM(HOUR(order_purchase_timestamp) BETWEEN 6 AND 11)      AS h06_11,
       SUM(HOUR(order_purchase_timestamp) BETWEEN 12 AND 17)     AS h12_17,
       SUM(HOUR(order_purchase_timestamp) BETWEEN 18 AND 23)     AS h18_23,
       COUNT(*)                                                  AS orders,
       ROUND(SUM(item_revenue), 0)                               AS revenue,
       ROUND(AVG(item_revenue), 2)                               AS aov
FROM fact_order WHERE order_status = 'delivered'
GROUP BY dow_num, weekday ORDER BY dow_num;

-- M9  Seller-customer geography x Delivery time x Lateness x Review
--     "How much does cross-state shipping cost us in speed and satisfaction?"
--     Single-seller orders only, so each order has exactly one origin state.
-- @Q M09_same_vs_cross_state
WITH single_seller AS (
  SELECT order_id, MIN(seller_state) AS seller_state
  FROM v_item_detail WHERE order_status = 'delivered'
  GROUP BY order_id HAVING COUNT(DISTINCT seller_id) = 1
)
SELECT CASE WHEN s.seller_state = f.customer_state THEN 'same state' ELSE 'cross-state' END AS route,
       CASE WHEN s.seller_state = 'SP' THEN 'seller in SP' ELSE 'seller outside SP' END   AS origin,
       COUNT(*)                                       AS orders,
       ROUND(AVG(f.delivery_days), 1)                 AS avg_delivery_days,
       ROUND(AVG(f.freight), 2)                       AS avg_freight,
       ROUND(100 * AVG(f.is_late), 1)                 AS late_pct,
       ROUND(AVG(f.review_score), 2)                  AS avg_review
FROM single_seller s JOIN fact_order f USING (order_id)
WHERE f.delivery_days IS NOT NULL
GROUP BY route, origin ORDER BY route DESC, origin;

-- M10 Product weight x Freight x Delivery time x Review
--     "Are heavy items a logistics and satisfaction problem?"
-- @Q M10_weight_freight_delivery_review
WITH line AS (
  SELECT i.order_id, i.price, i.freight_value, i.product_weight_g,
         CASE WHEN i.product_weight_g IS NULL  THEN '0: unknown'
              WHEN i.product_weight_g < 500    THEN '1: < 0.5 kg'
              WHEN i.product_weight_g < 2000   THEN '2: 0.5-2 kg'
              WHEN i.product_weight_g < 5000   THEN '3: 2-5 kg'
              WHEN i.product_weight_g < 15000  THEN '4: 5-15 kg'
              ELSE '5: 15 kg+' END AS weight_band
  FROM v_item_detail i WHERE i.order_status = 'delivered'
)
SELECT l.weight_band,
       COUNT(*)                                           AS items,
       ROUND(AVG(l.price), 2)                             AS avg_price,
       ROUND(AVG(l.freight_value), 2)                     AS avg_freight,
       ROUND(100 * SUM(l.freight_value) / SUM(l.price), 1) AS freight_pct_of_price,
       ROUND(AVG(f.delivery_days), 1)                     AS avg_delivery_days,
       ROUND(100 * AVG(f.is_late), 1)                     AS late_pct,
       ROUND(AVG(f.review_score), 2)                      AS avg_review
FROM line l JOIN fact_order f USING (order_id)
GROUP BY l.weight_band ORDER BY l.weight_band;
