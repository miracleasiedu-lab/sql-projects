/* =====================================================================
   01_staging_load.sql
   Olist E-Commerce Analytics — Stage 0: raw staging layer
   ---------------------------------------------------------------------
   Purpose : Land the 9 CSV files exactly as supplied. Every column is
             loaded as text so that no value is silently coerced,
             truncated or rejected on import. Typing, NULL handling and
             de-duplication happen later, in 03_clean_model.sql, where
             each decision is explicit and auditable.
   Requires: local_infile=1 on server and client. Run from the project
             root with the 9 CSV files in ./data/ (paths are client-relative).
   ===================================================================== */

DROP DATABASE IF EXISTS olist_stg;
CREATE DATABASE olist_stg CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE olist_stg;

-- ---------------------------------------------------------------------
-- Staging tables (all text; names identical to CSV headers)
-- ---------------------------------------------------------------------
CREATE TABLE stg_orders (
  order_id                      VARCHAR(64),
  customer_id                   VARCHAR(64),
  order_status                  VARCHAR(32),
  order_purchase_timestamp      VARCHAR(32),
  order_approved_at             VARCHAR(32),
  order_delivered_carrier_date  VARCHAR(32),
  order_delivered_customer_date VARCHAR(32),
  order_estimated_delivery_date VARCHAR(32)
);

CREATE TABLE stg_customers (
  customer_id              VARCHAR(64),
  customer_unique_id       VARCHAR(64),
  customer_zip_code_prefix VARCHAR(16),
  customer_city            VARCHAR(100),
  customer_state           VARCHAR(8)
);

CREATE TABLE stg_order_items (
  order_id            VARCHAR(64),
  order_item_id       VARCHAR(8),
  product_id          VARCHAR(64),
  seller_id           VARCHAR(64),
  shipping_limit_date VARCHAR(32),
  price               VARCHAR(32),
  freight_value       VARCHAR(32)
);

CREATE TABLE stg_order_payments (
  order_id             VARCHAR(64),
  payment_sequential   VARCHAR(8),
  payment_type         VARCHAR(32),
  payment_installments VARCHAR(8),
  payment_value        VARCHAR(32)
);

CREATE TABLE stg_order_reviews (
  review_id               VARCHAR(64),
  order_id                VARCHAR(64),
  review_score            VARCHAR(8),
  review_comment_title    TEXT,
  review_comment_message  TEXT,
  review_creation_date    VARCHAR(32),
  review_answer_timestamp VARCHAR(32)
);

CREATE TABLE stg_products (
  product_id                 VARCHAR(64),
  product_category_name      VARCHAR(100),
  product_name_lenght        VARCHAR(16),   -- (sic) spelling as in source file
  product_description_lenght VARCHAR(16),   -- (sic)
  product_photos_qty         VARCHAR(16),
  product_weight_g           VARCHAR(16),
  product_length_cm          VARCHAR(16),
  product_height_cm          VARCHAR(16),
  product_width_cm           VARCHAR(16)
);

CREATE TABLE stg_sellers (
  seller_id              VARCHAR(64),
  seller_zip_code_prefix VARCHAR(16),
  seller_city            VARCHAR(100),
  seller_state           VARCHAR(8)
);

CREATE TABLE stg_geolocation (
  geolocation_zip_code_prefix VARCHAR(16),
  geolocation_lat             VARCHAR(40),
  geolocation_lng             VARCHAR(40),
  geolocation_city            VARCHAR(100),
  geolocation_state           VARCHAR(8)
);

CREATE TABLE stg_category_translation (
  product_category_name         VARCHAR(100),
  product_category_name_english VARCHAR(100)
);

-- ---------------------------------------------------------------------
-- Loads. Note the two files that use Windows CRLF line endings
-- (reviews, category translation). The reviews file also contains
-- line breaks INSIDE quoted comment fields: 104,720 physical lines but
-- only 99,224 records. OPTIONALLY ENCLOSED BY '"' with a '\r\n' record
-- terminator loads it correctly.
-- ESCAPED BY '' is required: the files do not use backslash escaping,
-- and one review comment ends in a literal backslash ( ...nada :\" ).
-- With MySQL's default ESCAPED BY '\\' that \" is read as an escaped
-- quote and two reviews are merged into one (99,223 instead of 99,224).
-- ---------------------------------------------------------------------
LOAD DATA LOCAL INFILE 'data/olist_orders_dataset.csv'
INTO TABLE stg_orders
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' ESCAPED BY ''
LINES TERMINATED BY '\n' IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'data/olist_customers_dataset.csv'
INTO TABLE stg_customers
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' ESCAPED BY ''
LINES TERMINATED BY '\n' IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'data/olist_order_items_dataset.csv'
INTO TABLE stg_order_items
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' ESCAPED BY ''
LINES TERMINATED BY '\n' IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'data/olist_order_payments_dataset.csv'
INTO TABLE stg_order_payments
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' ESCAPED BY ''
LINES TERMINATED BY '\n' IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'data/olist_order_reviews_dataset.csv'
INTO TABLE stg_order_reviews
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' ESCAPED BY ''
LINES TERMINATED BY '\r\n' IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'data/olist_products_dataset.csv'
INTO TABLE stg_products
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' ESCAPED BY ''
LINES TERMINATED BY '\n' IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'data/olist_sellers_dataset.csv'
INTO TABLE stg_sellers
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' ESCAPED BY ''
LINES TERMINATED BY '\n' IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'data/olist_geolocation_dataset.csv'
INTO TABLE stg_geolocation
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' ESCAPED BY ''
LINES TERMINATED BY '\n' IGNORE 1 LINES;

-- Header line carries a UTF-8 BOM; it is skipped by IGNORE 1 LINES.
LOAD DATA LOCAL INFILE 'data/product_category_name_translation.csv'
INTO TABLE stg_category_translation
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"' ESCAPED BY ''
LINES TERMINATED BY '\r\n' IGNORE 1 LINES;

-- ---------------------------------------------------------------------
-- Non-unique helper indexes so the profiling joins in 02 run quickly.
-- (They enforce nothing — uniqueness is tested, not assumed.)
-- ---------------------------------------------------------------------
CREATE INDEX ix_o_order    ON stg_orders (order_id);
CREATE INDEX ix_o_cust     ON stg_orders (customer_id);
CREATE INDEX ix_c_cust     ON stg_customers (customer_id);
CREATE INDEX ix_i_order    ON stg_order_items (order_id);
CREATE INDEX ix_i_product  ON stg_order_items (product_id);
CREATE INDEX ix_i_seller   ON stg_order_items (seller_id);
CREATE INDEX ix_p_order    ON stg_order_payments (order_id);
CREATE INDEX ix_r_order    ON stg_order_reviews (order_id);
CREATE INDEX ix_pr_product ON stg_products (product_id);
CREATE INDEX ix_s_seller   ON stg_sellers (seller_id);
CREATE INDEX ix_g_zip      ON stg_geolocation (geolocation_zip_code_prefix);
CREATE INDEX ix_t_cat      ON stg_category_translation (product_category_name);

-- ---------------------------------------------------------------------
-- Load reconciliation: staging row counts vs. source records
-- ---------------------------------------------------------------------
-- @Q LD01_load_reconciliation
SELECT 'stg_orders' AS tbl, COUNT(*) AS rows_loaded FROM stg_orders
UNION ALL SELECT 'stg_customers', COUNT(*) FROM stg_customers
UNION ALL SELECT 'stg_order_items', COUNT(*) FROM stg_order_items
UNION ALL SELECT 'stg_order_payments', COUNT(*) FROM stg_order_payments
UNION ALL SELECT 'stg_order_reviews', COUNT(*) FROM stg_order_reviews
UNION ALL SELECT 'stg_products', COUNT(*) FROM stg_products
UNION ALL SELECT 'stg_sellers', COUNT(*) FROM stg_sellers
UNION ALL SELECT 'stg_geolocation', COUNT(*) FROM stg_geolocation
UNION ALL SELECT 'stg_category_translation', COUNT(*) FROM stg_category_translation;
