/* =====================================================================
   07_univariate.sql — Stage 8: 10 single-variable analyses
   ===================================================================== */
USE olist;

-- U1  How are order values distributed? (delivered orders, product revenue)
-- @Q U01_order_value_distribution
SELECT CASE
         WHEN item_revenue <   50 THEN '01: < 50'
         WHEN item_revenue <  100 THEN '02: 50-99'
         WHEN item_revenue <  200 THEN '03: 100-199'
         WHEN item_revenue <  500 THEN '04: 200-499'
         WHEN item_revenue < 1000 THEN '05: 500-999'
         ELSE                          '06: 1000+'
       END                                              AS order_value_band_brl,
       COUNT(*)                                         AS orders,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct_orders,
       ROUND(SUM(item_revenue), 0)                      AS revenue,
       ROUND(100 * SUM(item_revenue) / SUM(SUM(item_revenue)) OVER (), 2) AS pct_revenue
FROM fact_order WHERE order_status = 'delivered'
GROUP BY order_value_band_brl ORDER BY order_value_band_brl;

-- @Q U01b_order_value_summary_stats
WITH v AS (
  SELECT item_revenue, ROW_NUMBER() OVER (ORDER BY item_revenue) rn, COUNT(*) OVER () n
  FROM fact_order WHERE order_status = 'delivered'
)
SELECT ROUND(MIN(item_revenue), 2) AS min_,
       MAX(CASE WHEN rn = CEIL(n * .25) THEN item_revenue END) AS p25,
       MAX(CASE WHEN rn = CEIL(n * .50) THEN item_revenue END) AS median,
       ROUND(AVG(item_revenue), 2) AS mean,
       MAX(CASE WHEN rn = CEIL(n * .75) THEN item_revenue END) AS p75,
       MAX(CASE WHEN rn = CEIL(n * .99) THEN item_revenue END) AS p99,
       ROUND(MAX(item_revenue), 2) AS max_,
       ROUND(STDDEV_SAMP(item_revenue), 2) AS std_dev
FROM v;

-- U2  Which product categories appear most often in sales? (item lines, delivered)
-- @Q U02_category_item_share
SELECT category,
       COUNT(*)                                          AS items_sold,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2)  AS pct_of_items,
       ROUND(100 * SUM(COUNT(*)) OVER (ORDER BY COUNT(*) DESC, category) / SUM(COUNT(*)) OVER (), 2)
                                                         AS cumulative_pct
FROM v_item_detail WHERE order_status = 'delivered'
GROUP BY category ORDER BY items_sold DESC LIMIT 15;

-- @Q U02b_category_count
SELECT COUNT(DISTINCT category) AS categories_with_sales,
       SUM(category = 'uncategorized') AS uncategorized_items
FROM v_item_detail WHERE order_status = 'delivered';

-- U3  What is the order-status mix?
-- @Q U03_order_status
SELECT order_status, COUNT(*) AS orders,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct
FROM orders GROUP BY order_status ORDER BY orders DESC;

-- U4  Which payment methods do customers use? (payment-record and value share)
-- @Q U04_payment_methods
SELECT payment_type,
       COUNT(DISTINCT order_id)                           AS orders_using,
       COUNT(*)                                           AS payment_records,
       ROUND(SUM(payment_value), 0)                       AS value_paid,
       ROUND(100 * SUM(payment_value) / SUM(SUM(payment_value)) OVER (), 2) AS pct_value
FROM order_payments GROUP BY payment_type ORDER BY value_paid DESC;

-- U5  How are review scores distributed? (one review per order)
-- @Q U05_review_scores
SELECT review_score, COUNT(*) AS orders,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct
FROM fact_order WHERE review_score IS NOT NULL
GROUP BY review_score ORDER BY review_score DESC;

-- U6  How is freight per order distributed? (delivered)
-- @Q U06_freight_distribution
SELECT CASE WHEN freight = 0  THEN '01: free (0)'
            WHEN freight < 10 THEN '02: 0.01-9.99'
            WHEN freight < 20 THEN '03: 10-19.99'
            WHEN freight < 30 THEN '04: 20-29.99'
            WHEN freight < 50 THEN '05: 30-49.99'
            WHEN freight < 100 THEN '06: 50-99.99'
            ELSE '07: 100+' END                         AS freight_band_brl,
       COUNT(*) AS orders,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct_orders
FROM fact_order WHERE order_status = 'delivered'
GROUP BY freight_band_brl ORDER BY freight_band_brl;

-- U7  Where are customers located? (unique customers by state)
-- @Q U07_customers_by_state
SELECT customer_state,
       COUNT(DISTINCT customer_unique_id) AS unique_customers,
       ROUND(100 * COUNT(DISTINCT customer_unique_id) / (SELECT COUNT(DISTINCT customer_unique_id) FROM customers), 2) AS pct
FROM customers GROUP BY customer_state ORDER BY unique_customers DESC LIMIT 12;

-- U8  Where are sellers located?
-- @Q U08_sellers_by_state
SELECT seller_state, COUNT(*) AS sellers,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct,
       ROUND(100 * SUM(COUNT(*)) OVER (ORDER BY COUNT(*) DESC, seller_state) / SUM(COUNT(*)) OVER (), 2) AS cumulative_pct
FROM sellers GROUP BY seller_state ORDER BY sellers DESC LIMIT 10;

-- U9  How many instalments do credit-card payers choose?
-- @Q U09_installments
SELECT CASE WHEN payment_installments = 1 THEN '01: 1x'
            WHEN payment_installments <= 3 THEN '02: 2-3x'
            WHEN payment_installments <= 6 THEN '03: 4-6x'
            WHEN payment_installments <= 10 THEN '04: 7-10x'
            ELSE '05: 11-24x' END                          AS installment_band,
       COUNT(*) AS credit_card_payments,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2)    AS pct,
       ROUND(AVG(payment_value), 2)                        AS avg_payment_value
FROM order_payments WHERE payment_type = 'credit_card'
GROUP BY installment_band ORDER BY installment_band;

-- U10 How long does delivery take? (purchase -> customer, delivered)
-- @Q U10_delivery_duration
SELECT CASE WHEN delivery_days < 3  THEN '01: < 3 days'
            WHEN delivery_days < 7  THEN '02: 3-6 days'
            WHEN delivery_days < 14 THEN '03: 7-13 days'
            WHEN delivery_days < 21 THEN '04: 14-20 days'
            WHEN delivery_days < 30 THEN '05: 21-29 days'
            WHEN delivery_days < 60 THEN '06: 30-59 days'
            ELSE '07: 60+ days' END                         AS delivery_band,
       COUNT(*) AS orders,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2)     AS pct,
       ROUND(100 * SUM(COUNT(*)) OVER (ORDER BY MIN(delivery_days)) / SUM(COUNT(*)) OVER (), 2) AS cumulative_pct
FROM fact_order
WHERE order_status = 'delivered' AND delivery_days IS NOT NULL
GROUP BY delivery_band ORDER BY delivery_band;
