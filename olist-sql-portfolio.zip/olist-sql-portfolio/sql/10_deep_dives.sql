/* =====================================================================
   10_deep_dives.sql
   Stages 11–16: Advanced SQL deep dives
     A. Customer analysis      (customer_unique_id = the real person)
     B. Product analysis
     C. Seller performance
     D. Delivery & satisfaction
     E. Time series
   Delivered orders only, unless stated.
   ===================================================================== */
USE olist;

/* =========================== A. CUSTOMERS =========================== */

-- C1  How many real customers do we have, and how many come back?
-- @Q C01_customer_overview
WITH cust AS (
  SELECT customer_unique_id, COUNT(*) AS orders, SUM(item_revenue) AS spend
  FROM fact_order WHERE order_status = 'delivered'
  GROUP BY customer_unique_id
)
SELECT COUNT(*)                                     AS unique_customers,
       SUM(orders >= 2)                             AS repeat_customers,
       ROUND(100 * AVG(orders >= 2), 2)             AS repeat_rate_pct,
       ROUND(AVG(orders), 4)                        AS avg_orders_per_customer,
       ROUND(AVG(spend), 2)                         AS avg_lifetime_spend,
       ROUND(100 * SUM(CASE WHEN orders >= 2 THEN spend END) / SUM(spend), 2) AS pct_revenue_from_repeaters
FROM cust;

-- C2  Order-frequency distribution
-- @Q C02_order_frequency
SELECT orders AS delivered_orders_per_customer,
       COUNT(*) AS customers,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 3) AS pct_customers,
       ROUND(AVG(spend), 2) AS avg_lifetime_spend
FROM (SELECT customer_unique_id, COUNT(*) AS orders, SUM(item_revenue) AS spend
      FROM fact_order WHERE order_status = 'delivered' GROUP BY customer_unique_id) c
GROUP BY orders ORDER BY orders;

-- C3  Spending deciles — how concentrated is customer value?
-- @Q C03_spend_deciles
WITH cust AS (
  SELECT customer_unique_id, SUM(item_revenue) AS spend
  FROM fact_order WHERE order_status = 'delivered' GROUP BY customer_unique_id
),
deciles AS (SELECT spend, NTILE(10) OVER (ORDER BY spend DESC) AS decile FROM cust)
SELECT decile,
       COUNT(*)                                          AS customers,
       ROUND(MIN(spend), 2)                              AS min_spend,
       ROUND(MAX(spend), 2)                              AS max_spend,
       ROUND(SUM(spend), 0)                              AS revenue,
       ROUND(100 * SUM(spend) / SUM(SUM(spend)) OVER (), 2) AS pct_revenue,
       ROUND(100 * SUM(SUM(spend)) OVER (ORDER BY decile) / SUM(SUM(spend)) OVER (), 2) AS cumulative_pct
FROM deciles GROUP BY decile ORDER BY decile;

-- C4  Top-10 customers by lifetime spend (IDs truncated)
-- @Q C04_top_customers
SELECT RANK() OVER (ORDER BY SUM(item_revenue) DESC) AS spend_rank,
       CONCAT(LEFT(customer_unique_id, 8), '...')    AS customer,
       MIN(customer_state)                           AS state,
       COUNT(*)                                      AS orders,
       ROUND(SUM(item_revenue), 2)                   AS lifetime_spend,
       ROUND(AVG(item_revenue), 2)                   AS avg_order_value,
       ROUND(AVG(review_score), 1)                   AS avg_review
FROM fact_order WHERE order_status = 'delivered'
GROUP BY customer_unique_id
ORDER BY lifetime_spend DESC LIMIT 10;

-- C5  Repeat rate and spend by state (states with >= 2,000 customers)
-- @Q C05_state_customer_value
SELECT customer_state,
       COUNT(*)                          AS unique_customers,
       ROUND(100 * AVG(orders >= 2), 2)  AS repeat_rate_pct,
       ROUND(AVG(spend), 2)              AS avg_lifetime_spend
FROM (SELECT customer_unique_id, MIN(customer_state) AS customer_state,
             COUNT(*) AS orders, SUM(item_revenue) AS spend
      FROM fact_order WHERE order_status = 'delivered'
      GROUP BY customer_unique_id) c
GROUP BY customer_state HAVING COUNT(*) >= 2000
ORDER BY repeat_rate_pct DESC;

-- C6  How long until a customer orders again? (LAG over each customer's orders)
-- @Q C06_days_to_next_order
WITH seq AS (
  SELECT customer_unique_id, order_purchase_timestamp,
         LAG(order_purchase_timestamp) OVER (PARTITION BY customer_unique_id
                                             ORDER BY order_purchase_timestamp) AS prev_ts
  FROM fact_order WHERE order_status = 'delivered'
)
SELECT CASE WHEN DATEDIFF(order_purchase_timestamp, prev_ts) = 0  THEN '1: same day'
            WHEN DATEDIFF(order_purchase_timestamp, prev_ts) <= 30 THEN '2: 1-30 days'
            WHEN DATEDIFF(order_purchase_timestamp, prev_ts) <= 90 THEN '3: 31-90 days'
            WHEN DATEDIFF(order_purchase_timestamp, prev_ts) <= 180 THEN '4: 91-180 days'
            ELSE '5: 181+ days' END AS gap_band,
       COUNT(*) AS repeat_orders,
       ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) AS pct
FROM seq WHERE prev_ts IS NOT NULL
GROUP BY gap_band ORDER BY gap_band;

-- C7  Does the first-order experience relate to coming back?
-- @Q C07_first_review_vs_repeat
WITH ranked AS (
  SELECT customer_unique_id, review_score, is_late,
         ROW_NUMBER() OVER (PARTITION BY customer_unique_id ORDER BY order_purchase_timestamp) AS order_no,
         COUNT(*)     OVER (PARTITION BY customer_unique_id)                                    AS total_orders
  FROM fact_order WHERE order_status = 'delivered'
)
SELECT CASE WHEN review_score >= 4 THEN '1: first order rated 4-5'
            WHEN review_score = 3  THEN '2: first order rated 3'
            WHEN review_score <= 2 THEN '3: first order rated 1-2'
            ELSE '4: first order not reviewed' END AS first_experience,
       COUNT(*)                                    AS customers,
       ROUND(100 * AVG(total_orders >= 2), 2)      AS repeat_rate_pct
FROM ranked WHERE order_no = 1
GROUP BY first_experience ORDER BY first_experience;

/* =========================== B. PRODUCTS ============================ */

-- P1  Category league table: revenue rank, review rank, Pareto position
-- @Q P01_category_league
WITH cat AS (
  SELECT category, SUM(price) AS revenue, COUNT(*) AS units, AVG(price) AS avg_price,
         AVG(freight_value) AS avg_freight
  FROM v_item_detail WHERE order_status = 'delivered' GROUP BY category
),
cat_rev AS (                   -- review at (order, category) grain
  SELECT oc.category, AVG(f.review_score) AS avg_review
  FROM (SELECT DISTINCT order_id, category FROM v_item_detail WHERE order_status = 'delivered') oc
  JOIN fact_order f USING (order_id) GROUP BY oc.category
)
SELECT RANK()       OVER (ORDER BY c.revenue DESC)          AS revenue_rank,
       c.category,
       ROUND(c.revenue, 0)                                  AS revenue,
       c.units,
       ROUND(c.avg_price, 2)                                AS avg_price,
       ROUND(c.avg_freight, 2)                              AS avg_freight,
       ROUND(r.avg_review, 2)                               AS avg_review,
       DENSE_RANK() OVER (ORDER BY ROUND(r.avg_review, 2) DESC) AS review_rank,
       ROUND(100 * SUM(c.revenue) OVER (ORDER BY c.revenue DESC) / SUM(c.revenue) OVER (), 1) AS cumulative_revenue_pct
FROM cat c JOIN cat_rev r USING (category)
ORDER BY revenue_rank LIMIT 20;

-- @Q P01b_categories_for_80pct
WITH cat AS (SELECT category, SUM(price) rev FROM v_item_detail WHERE order_status = 'delivered' GROUP BY category),
     cum AS (SELECT category, SUM(rev) OVER (ORDER BY rev DESC) / SUM(rev) OVER () AS cum_share FROM cat)
SELECT (SELECT COUNT(*) FROM cat)               AS total_categories,
       (SELECT COUNT(*) FROM cum WHERE cum_share < 0.8) + 1 AS categories_needed_for_80pct_revenue;

-- P2  Best-selling product inside each top-5 category (ROW_NUMBER)
-- @Q P02_top_product_per_category
WITH prod AS (
  SELECT category, product_id, SUM(price) AS revenue, COUNT(*) AS units,
         ROW_NUMBER() OVER (PARTITION BY category ORDER BY SUM(price) DESC) AS rn,
         SUM(SUM(price)) OVER (PARTITION BY category) AS category_revenue
  FROM v_item_detail WHERE order_status = 'delivered'
  GROUP BY category, product_id
)
SELECT category, LEFT(product_id, 8) AS product, ROUND(revenue, 0) AS revenue, units,
       ROUND(100 * revenue / category_revenue, 2) AS pct_of_category
FROM prod
WHERE rn = 1 AND category IN (SELECT category FROM (
        SELECT category FROM v_item_detail WHERE order_status = 'delivered'
        GROUP BY category ORDER BY SUM(price) DESC LIMIT 5) t)
ORDER BY category_revenue DESC;

-- P3  Product listing quality: photos x units per product x review
-- @Q P03_photos_vs_performance
WITH prod AS (
  SELECT p.product_id, p.product_photos_qty, COUNT(*) AS units, SUM(i.price) AS revenue
  FROM order_items i JOIN orders o USING (order_id) JOIN products p USING (product_id)
  WHERE o.order_status = 'delivered'
  GROUP BY p.product_id, p.product_photos_qty
)
SELECT CASE WHEN product_photos_qty IS NULL THEN '0: unknown'
            WHEN product_photos_qty = 1 THEN '1: 1 photo'
            WHEN product_photos_qty = 2 THEN '2: 2 photos'
            WHEN product_photos_qty <= 4 THEN '3: 3-4 photos'
            ELSE '4: 5+ photos' END                 AS photo_band,
       COUNT(*)                                     AS products,
       ROUND(AVG(units), 2)                         AS avg_units_per_product,
       ROUND(AVG(revenue), 2)                       AS avg_revenue_per_product
FROM prod GROUP BY photo_band ORDER BY photo_band;

-- P4  Long tail: how many products sell once vs drive the bulk?
-- @Q P04_product_long_tail
WITH prod AS (
  SELECT product_id, COUNT(*) AS units, SUM(price) AS revenue
  FROM v_item_detail WHERE order_status = 'delivered' GROUP BY product_id
),
r AS (SELECT revenue, units, ROW_NUMBER() OVER (ORDER BY revenue DESC) AS rn, COUNT(*) OVER () AS n FROM prod)
SELECT MAX(n)                                                       AS products_sold,
       SUM(units = 1)                                               AS sold_exactly_once,
       ROUND(100 * AVG(units = 1), 1)                               AS pct_sold_once,
       ROUND(100 * SUM(CASE WHEN rn <= n * 0.01 THEN revenue END) / SUM(revenue), 1) AS top1pct_products_revenue_share,
       ROUND(100 * SUM(CASE WHEN rn <= n * 0.10 THEN revenue END) / SUM(revenue), 1) AS top10pct_products_revenue_share
FROM r;

/* =========================== C. SELLERS ============================= */

-- S1  Seller scorecard — top 15 by revenue with multi-metric ranks
-- @Q S01_seller_scorecard
WITH seller_order AS (
  SELECT seller_id, order_id, SUM(price) AS revenue, COUNT(*) AS items,
         MAX(order_delivered_carrier_date > shipping_limit_date) AS handover_late
  FROM v_item_detail WHERE order_status = 'delivered'
  GROUP BY seller_id, order_id
),
perf AS (
  SELECT so.seller_id, COUNT(*) AS orders, SUM(so.items) AS items, SUM(so.revenue) AS revenue,
         AVG(f.review_score) AS avg_review, AVG(f.is_late) AS late_rate,
         AVG(so.handover_late) AS handover_late_rate
  FROM seller_order so JOIN fact_order f USING (order_id)
  GROUP BY so.seller_id
)
SELECT RANK() OVER (ORDER BY revenue DESC)                   AS revenue_rank,
       LEFT(p.seller_id, 8)                                  AS seller,
       s.seller_state,
       ROUND(p.revenue, 0) AS revenue, p.orders, p.items,
       ROUND(p.avg_review, 2)                                AS avg_review,
       ROUND(100 * p.late_rate, 1)                           AS late_pct,
       ROUND(100 * p.handover_late_rate, 1)                  AS handover_late_pct,
       DENSE_RANK() OVER (ORDER BY ROUND(p.avg_review, 2) DESC) AS review_rank_among_all
FROM perf p JOIN sellers s USING (seller_id)
ORDER BY revenue_rank LIMIT 15;

-- S2  Seller revenue concentration (Pareto)
-- @Q S02_seller_concentration
WITH s AS (SELECT seller_id, SUM(price) AS revenue FROM v_item_detail
           WHERE order_status = 'delivered' GROUP BY seller_id),
     r AS (SELECT revenue, ROW_NUMBER() OVER (ORDER BY revenue DESC) AS rn, COUNT(*) OVER () AS n FROM s)
SELECT MAX(n) AS active_sellers,
       ROUND(100 * SUM(CASE WHEN rn <= n * 0.01 THEN revenue END) / SUM(revenue), 1) AS top1pct_share,
       ROUND(100 * SUM(CASE WHEN rn <= n * 0.10 THEN revenue END) / SUM(revenue), 1) AS top10pct_share,
       ROUND(100 * SUM(CASE WHEN rn <= n * 0.20 THEN revenue END) / SUM(revenue), 1) AS top20pct_share,
       ROUND(100 * SUM(CASE WHEN rn >  n * 0.50 THEN revenue END) / SUM(revenue), 1) AS bottom50pct_share
FROM r;

-- S3  Seller-side lateness: does missing the carrier hand-over deadline relate to reviews?
-- @Q S03_handover_vs_review
WITH so AS (
  SELECT order_id,
         MAX(order_delivered_carrier_date > shipping_limit_date) AS any_seller_handover_late
  FROM v_item_detail WHERE order_status = 'delivered' AND order_delivered_carrier_date IS NOT NULL
  GROUP BY order_id
)
SELECT CASE so.any_seller_handover_late WHEN 1 THEN 'seller missed hand-over deadline'
                                        ELSE 'seller handed over on time' END AS seller_handover,
       CASE f.is_late WHEN 1 THEN 'customer delivery late' ELSE 'customer delivery on time' END AS customer_outcome,
       COUNT(*)                         AS orders,
       ROUND(AVG(f.review_score), 2)    AS avg_review
FROM so JOIN fact_order f USING (order_id)
WHERE f.is_late IS NOT NULL
GROUP BY seller_handover, customer_outcome ORDER BY seller_handover DESC, customer_outcome DESC;

/* ===================== D. DELIVERY & SATISFACTION =================== */

-- D1  Where does the time go? Stage durations (valid full delivery chain only)
-- @Q D01_stage_durations
WITH s AS (
  SELECT TIMESTAMPDIFF(MINUTE, order_purchase_timestamp, order_approved_at) / 60     AS purchase_to_approval_h,
         TIMESTAMPDIFF(MINUTE, order_approved_at, order_delivered_carrier_date) / 1440 AS approval_to_carrier_d,
         TIMESTAMPDIFF(MINUTE, order_delivered_carrier_date, order_delivered_customer_date) / 1440 AS carrier_to_customer_d,
         TIMESTAMPDIFF(MINUTE, order_purchase_timestamp, order_delivered_customer_date) / 1440 AS total_d,
         TIMESTAMPDIFF(MINUTE, order_purchase_timestamp, order_estimated_delivery_date) / 1440 AS promised_d
  FROM fact_order WHERE valid_delivery_chain = 1
)
SELECT COUNT(*)                              AS orders,
       ROUND(AVG(purchase_to_approval_h), 1) AS avg_purchase_to_approval_hours,
       ROUND(AVG(approval_to_carrier_d), 2)  AS avg_approval_to_carrier_days,
       ROUND(AVG(carrier_to_customer_d), 2)  AS avg_carrier_to_customer_days,
       ROUND(AVG(total_d), 2)                AS avg_total_days,
       ROUND(AVG(promised_d), 2)             AS avg_promised_days,
       ROUND(100 * AVG(carrier_to_customer_d) / AVG(total_d), 1) AS carrier_leg_pct_of_total
FROM s;

-- D2  Monthly delivery performance (complete months only)
-- @Q D02_monthly_delivery
SELECT purchase_month,
       COUNT(*)                          AS delivered_orders,
       ROUND(AVG(delivery_days), 1)      AS avg_delivery_days,
       ROUND(100 * AVG(is_late), 1)      AS late_pct,
       ROUND(AVG(review_score), 2)       AS avg_review
FROM fact_order
WHERE order_status = 'delivered' AND is_late IS NOT NULL
  AND purchase_month BETWEEN '2017-01' AND '2018-08'
GROUP BY purchase_month ORDER BY purchase_month;

-- D3  Strength of association: Pearson r computed in SQL
-- @Q D03_correlations
WITH d AS (
  SELECT delay_days AS x1, delivery_days AS x2,
         CAST(review_score AS SIGNED) AS y        -- review_score is UNSIGNED: cast before multiplying by negative delays
  FROM fact_order
  WHERE order_status = 'delivered' AND delay_days IS NOT NULL AND review_score IS NOT NULL
)
SELECT COUNT(*) AS n,
       ROUND((AVG(x1 * y) - AVG(x1) * AVG(y)) / (STDDEV_POP(x1) * STDDEV_POP(y)), 3) AS r_delay_days_vs_review,
       ROUND((AVG(x2 * y) - AVG(x2) * AVG(y)) / (STDDEV_POP(x2) * STDDEV_POP(y)), 3) AS r_delivery_days_vs_review
FROM d;

-- D4  Late vs on-time: satisfaction gap, with and without comments
-- @Q D04_late_vs_ontime_review
SELECT CASE is_late WHEN 1 THEN 'late' ELSE 'on time / early' END AS delivery_outcome,
       COUNT(*)                                AS orders,
       ROUND(AVG(review_score), 2)             AS avg_review,
       ROUND(100 * AVG(review_score <= 2), 1)  AS pct_negative,
       ROUND(100 * AVG(review_score = 5), 1)   AS pct_five_star
FROM fact_order
WHERE order_status = 'delivered' AND is_late IS NOT NULL AND review_score IS NOT NULL
GROUP BY delivery_outcome;

/* =========================== E. TIME SERIES ========================= */

-- T1  Monthly trend with MoM growth (LAG), running total, 3-month moving avg
-- @Q T01_monthly_trend
WITH m AS (
  SELECT purchase_month,
         SUM(item_revenue)                  AS revenue,
         COUNT(*)                           AS orders,
         COUNT(DISTINCT customer_unique_id) AS customers,
         AVG(item_revenue)                  AS aov
  FROM fact_order
  WHERE order_status = 'delivered' AND purchase_month BETWEEN '2017-01' AND '2018-08'
  GROUP BY purchase_month
)
SELECT purchase_month,
       ROUND(revenue, 0)                                                   AS revenue,
       orders, customers,
       ROUND(aov, 2)                                                       AS aov,
       ROUND(100 * (revenue - LAG(revenue) OVER w) / LAG(revenue) OVER w, 1) AS mom_revenue_growth_pct,
       ROUND(100 * (orders - LAG(orders) OVER w) / LAG(orders) OVER w, 1)    AS mom_orders_growth_pct,
       ROUND(SUM(revenue) OVER (ORDER BY purchase_month ROWS UNBOUNDED PRECEDING), 0) AS running_revenue,
       ROUND(AVG(revenue) OVER (ORDER BY purchase_month ROWS 2 PRECEDING), 0)         AS revenue_3m_moving_avg
FROM m
WINDOW w AS (ORDER BY purchase_month)
ORDER BY purchase_month;

-- T2  Year -> Quarter hierarchy with subtotals (WITH ROLLUP), all delivered orders
-- @Q T02_year_quarter_rollup
SELECT COALESCE(CAST(yr AS CHAR), 'ALL YEARS')         AS year_,
       COALESCE(CONCAT('Q', qtr), IF(yr IS NULL, '', 'year total')) AS quarter_,
       orders, ROUND(revenue, 0) AS revenue, ROUND(revenue / orders, 2) AS aov
FROM (
  SELECT YEAR(order_purchase_timestamp) AS yr, QUARTER(order_purchase_timestamp) AS qtr,
         COUNT(*) AS orders, SUM(item_revenue) AS revenue
  FROM fact_order WHERE order_status = 'delivered'
  GROUP BY yr, qtr WITH ROLLUP
) r;

-- T3  Year-over-year: Jan–Aug 2018 vs Jan–Aug 2017, month by month
-- @Q T03_yoy_jan_aug
WITH m AS (
  SELECT YEAR(order_purchase_timestamp) AS yr, MONTH(order_purchase_timestamp) AS mon,
         SUM(item_revenue) AS revenue, COUNT(*) AS orders
  FROM fact_order
  WHERE order_status = 'delivered' AND MONTH(order_purchase_timestamp) <= 8
    AND YEAR(order_purchase_timestamp) IN (2017, 2018)
  GROUP BY yr, mon
)
SELECT LPAD(mon, 2, '0') AS month_,
       ROUND(MAX(CASE WHEN yr = 2017 THEN revenue END), 0) AS revenue_2017,
       ROUND(MAX(CASE WHEN yr = 2018 THEN revenue END), 0) AS revenue_2018,
       ROUND(100 * (MAX(CASE WHEN yr = 2018 THEN revenue END) / MAX(CASE WHEN yr = 2017 THEN revenue END) - 1), 1) AS yoy_growth_pct
FROM m GROUP BY mon
UNION ALL
SELECT 'Jan-Aug total',
       ROUND(SUM(CASE WHEN yr = 2017 THEN revenue END), 0),
       ROUND(SUM(CASE WHEN yr = 2018 THEN revenue END), 0),
       ROUND(100 * (SUM(CASE WHEN yr = 2018 THEN revenue END) / SUM(CASE WHEN yr = 2017 THEN revenue END) - 1), 1)
FROM m
ORDER BY month_;

-- T4  Category momentum: Jan–Aug 2018 vs Jan–Aug 2017 (categories >= R$100k in 2018)
-- @Q T04_category_momentum
WITH c AS (
  SELECT category,
         SUM(CASE WHEN order_purchase_timestamp >= '2017-01-01' AND order_purchase_timestamp < '2017-09-01' THEN price END) AS rev_2017,
         SUM(CASE WHEN order_purchase_timestamp >= '2018-01-01' AND order_purchase_timestamp < '2018-09-01' THEN price END) AS rev_2018
  FROM v_item_detail WHERE order_status = 'delivered'
  GROUP BY category
)
SELECT category, ROUND(rev_2017, 0) AS jan_aug_2017, ROUND(rev_2018, 0) AS jan_aug_2018,
       ROUND(100 * (rev_2018 / rev_2017 - 1), 1) AS growth_pct,
       RANK() OVER (ORDER BY rev_2018 / rev_2017 DESC) AS growth_rank
FROM c WHERE rev_2018 >= 100000
ORDER BY growth_pct DESC;

-- T5  Peak trading days (all delivered orders)
-- @Q T05_peak_days
SELECT purchase_date, DAYNAME(purchase_date) AS weekday, COUNT(*) AS orders,
       ROUND(SUM(item_revenue), 0) AS revenue,
       ROUND(COUNT(*) / (SELECT COUNT(*) / COUNT(DISTINCT purchase_date) FROM fact_order
                         WHERE order_status = 'delivered'
                           AND purchase_month BETWEEN '2017-01' AND '2018-08'), 1) AS x_average_day
FROM fact_order WHERE order_status = 'delivered'
GROUP BY purchase_date ORDER BY orders DESC LIMIT 5;
