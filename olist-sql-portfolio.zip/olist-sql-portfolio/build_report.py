"""Assemble README.md from REPORT_TEMPLATE.md.
   {{T:TAG}}  -> result table captured by run_sql.py (results/*.json)
   {{S:TAG}}  -> the exact SQL statement tagged `-- @Q TAG` in sql/*.sql
   {{DICT}}   -> data dictionary generated from information_schema
Nothing numeric is typed by hand into result tables."""
import json, glob, re, os, pymysql
from run_sql import to_md

RES = {}
for f in sorted(glob.glob('results/*.json')):
    RES.update(json.load(open(f)))

SQL = {}
for f in sorted(glob.glob('sql/*.sql')):
    lines = open(f).read().splitlines()
    for i, l in enumerate(lines):
        m = re.match(r'\s*--\s*@Q\s+(\S+)', l)
        if m:
            buf = []
            for l2 in lines[i + 1:]:
                buf.append(l2)
                if l2.rstrip().endswith(';') and not l2.lstrip().startswith('--'):
                    break
            SQL[m.group(1)] = '\n'.join(buf).strip()

DESC = {
 ('orders','order_id'): 'Order identifier (one row per order)',
 ('orders','customer_id'): 'Order-level customer key; UNIQUE, so customers→orders is 1:1',
 ('orders','order_status'): 'Lifecycle status (8 observed values)',
 ('orders','order_purchase_timestamp'): 'Purchase time; basis of all time-series analysis',
 ('orders','order_approved_at'): 'Payment approval time (NULL for 160 orders)',
 ('orders','order_delivered_carrier_date'): 'Hand-over to carrier (NULL for 1,783 orders)',
 ('orders','order_delivered_customer_date'): 'Delivery to customer (NULL for 2,965 orders)',
 ('orders','order_estimated_delivery_date'): 'Delivery date promised at purchase',
 ('customers','customer_id'): 'PK; one per order (not a persistent person ID)',
 ('customers','customer_unique_id'): 'Persistent person ID; repeats across orders — use for customer counts',
 ('customers','customer_zip_code_prefix'): 'First 5 digits of ZIP; FK → zip_code',
 ('customers','customer_city'): 'Standardised city name (lower case, no diacritics)',
 ('customers','customer_state'): 'Brazilian state code (UF)',
 ('order_items','order_id'): 'FK → orders; part of composite PK',
 ('order_items','order_item_id'): 'Line sequence 1..n inside the order; part of composite PK',
 ('order_items','product_id'): 'FK → products',
 ('order_items','seller_id'): 'FK → sellers',
 ('order_items','shipping_limit_date'): 'Deadline for seller to hand item to carrier',
 ('order_items','price'): 'Item price, BRL (CHECK > 0) — revenue base',
 ('order_items','freight_value'): 'Freight charged for the item, BRL (CHECK ≥ 0)',
 ('order_payments','order_id'): 'FK → orders; part of composite PK',
 ('order_payments','payment_sequential'): 'Payment sequence within order; part of composite PK',
 ('order_payments','payment_type'): 'credit_card / boleto / voucher / debit_card / not_defined',
 ('order_payments','payment_installments'): 'Number of instalments (0 recoded to 1 for 2 rows)',
 ('order_payments','payment_value'): 'Amount paid in this payment record, BRL',
 ('order_payments','installments_recoded'): 'Cleaning flag: 1 if instalments was 0 in source',
 ('order_reviews','review_id'): 'Review identifier — NOT unique alone; part of composite PK',
 ('order_reviews','order_id'): 'FK → orders; part of composite PK',
 ('order_reviews','review_score'): '1–5 stars (CHECK 1..5)',
 ('order_reviews','review_comment_title'): 'Optional title (NULL in 88% of reviews)',
 ('order_reviews','review_comment_message'): 'Optional free text (NULL in 59%)',
 ('order_reviews','review_creation_date'): 'Date the survey was sent',
 ('order_reviews','review_answer_timestamp'): 'Time the customer answered; used to pick latest review',
 ('products','product_id'): 'Product identifier',
 ('products','product_category_name'): 'Portuguese category; FK → category_translation (NULL for 610)',
 ('products','product_name_lenght'): 'Characters in product name (source spelling kept)',
 ('products','product_description_lenght'): 'Characters in description (source spelling kept)',
 ('products','product_photos_qty'): 'Number of listing photos',
 ('products','product_weight_g'): 'Weight in grams (0 g → NULL for 4 products)',
 ('products','product_length_cm'): 'Package length, cm',
 ('products','product_height_cm'): 'Package height, cm',
 ('products','product_width_cm'): 'Package width, cm',
 ('products','weight_was_zero'): 'Cleaning flag: 1 if source weight was 0 g',
 ('sellers','seller_id'): 'Seller identifier',
 ('sellers','seller_zip_code_prefix'): 'FK → zip_code',
 ('sellers','seller_city'): 'Cleaned city (free text repaired; 2 invalid values → NULL)',
 ('sellers','seller_state'): 'Brazilian state code (UF)',
 ('category_translation','product_category_name'): 'Portuguese category name',
 ('category_translation','product_category_name_english'): 'English category name',
 ('category_translation','is_supplemented'): '1 for the 2 rows added because the source file lacked them',
 ('zip_code','zip_code_prefix'): '5-digit ZIP prefix (unique after aggregation)',
 ('zip_code','latitude'): 'Centroid of de-duplicated, in-Brazil points',
 ('zip_code','longitude'): 'Centroid of de-duplicated, in-Brazil points',
 ('zip_code','geo_city'): 'Most frequent standardised city for the prefix',
 ('zip_code','geo_state'): 'Most frequent state for the prefix',
 ('zip_code','geo_points'): 'Distinct valid raw points behind the centroid',
 ('zip_code','has_geolocation'): '0 = prefix used by customers/sellers but absent from source geolocation',
}

def data_dictionary():
    conn = pymysql.connect(user='root', unix_socket='/var/run/mysqld/mysqld.sock', database='olist')
    cur = conn.cursor()
    tables = ['orders','customers','order_items','order_payments','order_reviews',
              'products','sellers','category_translation','zip_code']
    out = []
    for t in tables:
        cur.execute(f'SELECT COUNT(*) FROM {t}')
        n = cur.fetchone()[0]
        cur.execute("""SELECT column_name, column_type, is_nullable, column_key
                       FROM information_schema.columns
                       WHERE table_schema='olist' AND table_name=%s ORDER BY ordinal_position""", (t,))
        out.append(f'#### `{t}` — {n:,} rows\n')
        out.append('| Column | MySQL type | Null | Key | Description |\n|---|---|---|---|---|')
        for c, ty, nl, k in cur.fetchall():
            ty = ty if len(ty) < 40 else 'enum(…)'
            out.append(f'| `{c}` | {ty} | {nl} | {k} | {DESC.get((t, c), "")} |')
        out.append('')
    return '\n'.join(out)

tpl = open('REPORT_TEMPLATE.md').read()
missing = []
def rep_t(m):
    tag = m.group(1)
    if tag not in RES: missing.append(tag); return f'**MISSING {tag}**'
    return to_md(RES[tag]['cols'], RES[tag]['rows'], limit=80)
def rep_s(m):
    tag = m.group(1)
    if tag not in SQL: missing.append('SQL ' + tag); return f'**MISSING SQL {tag}**'
    return '```sql\n' + SQL[tag] + '\n```'
out = re.sub(r'\{\{T:(\S+?)\}\}', rep_t, tpl)
out = re.sub(r'\{\{S:(\S+?)\}\}', rep_s, out)
out = out.replace('{{DICT}}', data_dictionary())
open('README.md', 'w').write(out)
print('README.md written,', len(out), 'chars; missing:', missing)
