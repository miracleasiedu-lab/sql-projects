### LD01_load_reconciliation

| tbl | rows_loaded |
|---|---|
| stg_orders | 99,441 |
| stg_customers | 99,441 |
| stg_order_items | 112,650 |
| stg_order_payments | 103,886 |
| stg_order_reviews | 99,224 |
| stg_products | 32,951 |
| stg_sellers | 3,095 |
| stg_geolocation | 1,000,163 |
| stg_category_translation | 71 |

