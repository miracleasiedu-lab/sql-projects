### M01_top_categories_per_state

| customer_state | rnk | category | revenue | pct_of_state |
|---|---|---|---|---|
| SP | 1 | bed_bath_table | 472,238 | 9.32 |
| SP | 2 | health_beauty | 453,916 | 8.96 |
| RJ | 1 | watches_gifts | 174,895 | 9.94 |
| RJ | 2 | bed_bath_table | 144,252 | 8.2 |
| MG | 1 | health_beauty | 154,324 | 9.94 |
| MG | 2 | bed_bath_table | 128,760 | 8.29 |
| RS | 1 | bed_bath_table | 60,041 | 8.24 |
| RS | 2 | furniture_decor | 53,775 | 7.38 |
| PR | 1 | sports_leisure | 57,653 | 8.66 |
| PR | 2 | watches_gifts | 57,287 | 8.6 |
| SC | 1 | sports_leisure | 41,579 | 8.2 |
| SC | 2 | health_beauty | 39,261 | 7.74 |
| BA | 1 | health_beauty | 49,955 | 10.12 |
| BA | 2 | watches_gifts | 45,632 | 9.24 |
| DF | 1 | watches_gifts | 32,292 | 10.89 |
| DF | 2 | health_beauty | 29,543 | 9.96 |

### M02_top_seller_category_mix

| seller_rank | seller | seller_revenue | categories | main_category | main_category_pct |
|---|---|---|---|---|---|
| 1 | 4869f7a5 | 226,988 | 10 | watches_gifts | 87.6 |
| 2 | 53243585 | 217,940 | 2 | computers | 74.9 |
| 3 | 4a3ca931 | 196,882 | 7 | bed_bath_table | 82.4 |
| 4 | fa1c13f2 | 190,917 | 5 | watches_gifts | 99 |
| 5 | 7c67e144 | 186,570 | 6 | office_furniture | 92 |
| 6 | 7e93a43e | 165,981 | 7 | watches_gifts | 96.4 |
| 7 | da8622b1 | 159,817 | 4 | bed_bath_table | 95 |
| 8 | 7a67c85e | 139,659 | 2 | cool_stuff | 95.5 |
| 9 | 1025f0e2 | 138,209 | 4 | furniture_decor | 80.1 |
| 10 | 955fee92 | 131,837 | 23 | furniture_decor | 29.1 |

### M03_state_delivery_review

| customer_state | orders | avg_delivery_days | late_pct | avg_review_all | avg_review_on_time | avg_review_late |
|---|---|---|---|---|---|---|
| CE | 1,279 | 21.3 | 13.8 | 3.94 | 4.25 | 2.04 |
| BA | 3,256 | 19.3 | 12.2 | 3.93 | 4.14 | 2.35 |
| RJ | 12,350 | 15.3 | 12.1 | 3.97 | 4.24 | 1.91 |
| ES | 1,995 | 15.8 | 10.7 | 4.08 | 4.26 | 2.51 |
| PE | 1,593 | 18.4 | 9.6 | 4.08 | 4.3 | 2.03 |
| SC | 3,546 | 15 | 8.2 | 4.13 | 4.29 | 2.35 |
| GO | 1,957 | 15.6 | 6.5 | 4.11 | 4.24 | 2.2 |
| RS | 5,344 | 15.3 | 6.1 | 4.18 | 4.31 | 2.21 |
| DF | 2,080 | 13 | 5.7 | 4.13 | 4.26 | 1.97 |
| MG | 11,354 | 12 | 4.6 | 4.19 | 4.28 | 2.36 |
| SP | 40,494 | 8.8 | 4.5 | 4.25 | 4.32 | 2.55 |
| PR | 4,923 | 12 | 4 | 4.24 | 4.3 | 2.68 |

### M04_payment_installments_value

| main_payment_type | installment_band | orders | avg_order_paid | total_paid | avg_review |
|---|---|---|---|---|---|
| boleto | 1x | 19,191 | 144.33 | 2,769,933 | 4.16 |
| credit_card | 1x | 23,358 | 100.62 | 2,350,193 | 4.22 |
| credit_card | 2-3x | 22,020 | 134.96 | 2,971,882 | 4.15 |
| credit_card | 4-6x | 15,696 | 181.72 | 2,852,287 | 4.13 |
| credit_card | 7x+ | 11,751 | 334.26 | 3,927,844 | 4.08 |
| debit_card | 1x | 1,484 | 140.41 | 208,371 | 4.24 |
| voucher | 1x | 2,783 | 107.5 | 299,169 | 4.12 |
| voucher | 2-3x | 139 | 206.23 | 28,666 | 4.13 |

### M05_quarter_category_revenue

| yr_qtr | health_beauty | watches_gifts | bed_bath_table | sports_leisure | computers_accessories |
|---|---|---|---|---|---|
| 2017-Q1 | 60,079 | 43,971 | 44,497 | 50,315 | 43,322 |
| 2017-Q2 | 100,173 | 87,293 | 90,581 | 89,166 | 99,307 |
| 2017-Q3 | 133,919 | 114,622 | 171,473 | 126,216 | 100,043 |
| 2017-Q4 | 179,662 | 229,724 | 184,046 | 169,978 | 149,114 |
| 2018-Q1 | 240,471 | 229,908 | 203,561 | 242,371 | 265,344 |
| 2018-Q2 | 292,339 | 293,016 | 213,502 | 169,919 | 149,809 |

### M06_seller_segments

| segment | sellers | revenue | pct_revenue | avg_review | avg_late_pct | avg_carrier_handover_late_pct |
|---|---|---|---|---|---|---|
| 1: Stars (review>=4.2, late<=6%) | 213 | 2,833,636 | 27.8 | 4.4 | 2.8 | 4.4 |
| 2: Solid (review 4.0-4.2 or late>6%) | 261 | 5,087,319 | 49.9 | 4.19 | 7.5 | 9 |
| 3: At risk (review 3.5-4.0) | 130 | 1,812,686 | 17.8 | 3.85 | 9.1 | 12.7 |
| 4: Problem (review<3.5) | 23 | 465,051 | 4.6 | 3.26 | 15.5 | 34.5 |

### M07_region_freight_delivery_review

| region | orders | aov | freight_pct | avg_delivery_days | late_pct | avg_review |
|---|---|---|---|---|---|---|
| 1: SP | 40,494 | 125.12 | 13.9 | 8.8 | 4.5 | 4.25 |
| 2: Southeast ex-SP | 25,699 | 139.34 | 17.1 | 13.9 | 8.7 | 4.07 |
| 3: South | 13,813 | 137.68 | 17.7 | 14 | 5.9 | 4.19 |
| 4: Centre-West | 5,624 | 150.6 | 17.6 | 15 | 6.5 | 4.13 |
| 5: Northeast | 9,044 | 165.53 | 21.7 | 20 | 12.7 | 3.97 |
| 6: North | 1,796 | 182.11 | 22.7 | 22.6 | 8.6 | 4.03 |

### M08_weekday_hour_demand

| dow_num | weekday | h00_05 | h06_11 | h12_17 | h18_23 | orders | revenue | aov |
|---|---|---|---|---|---|---|---|---|
| 1 | Sunday | 555 | 1,893 | 4,175 | 5,012 | 11,635 | 1,545,648 | 132.84 |
| 2 | Monday | 587 | 3,495 | 6,068 | 5,551 | 15,701 | 2,168,906 | 138.14 |
| 3 | Tuesday | 610 | 3,603 | 5,987 | 5,303 | 15,503 | 2,122,265 | 136.89 |
| 4 | Wednesday | 725 | 3,631 | 5,817 | 4,903 | 15,076 | 2,051,534 | 136.08 |
| 5 | Thursday | 680 | 3,408 | 5,668 | 4,567 | 14,323 | 1,958,600 | 136.75 |
| 6 | Friday | 808 | 3,423 | 5,415 | 4,039 | 13,685 | 1,910,496 | 139.61 |
| 7 | Saturday | 629 | 2,141 | 4,053 | 3,732 | 10,555 | 1,464,050 | 138.71 |

### M09_same_vs_cross_state

| route | origin | orders | avg_delivery_days | avg_freight | late_pct | avg_review |
|---|---|---|---|---|---|---|
| same state | seller in SP | 30,313 | 8 | 14.94 | 4.7 | 4.26 |
| same state | seller outside SP | 3,921 | 8 | 17.07 | 3.4 | 4.41 |
| cross-state | seller in SP | 37,182 | 16 | 25.63 | 9.6 | 4.05 |
| cross-state | seller outside SP | 23,779 | 13.9 | 28 | 5.8 | 4.21 |

### M10_weight_freight_delivery_review

| weight_band | items | avg_price | avg_freight | freight_pct_of_price | avg_delivery_days | late_pct | avg_review |
|---|---|---|---|---|---|---|---|
| 0: unknown | 26 | 132.56 | 17.39 | 13.1 | 12.2 | 0 | 4.23 |
| 1: < 0.5 kg | 43,821 | 75.02 | 15.17 | 20.2 | 11.8 | 6.3 | 4.1 |
| 2: 0.5-2 kg | 41,234 | 111.96 | 17.78 | 15.9 | 12.5 | 6.4 | 4.08 |
| 3: 2-5 kg | 11,436 | 178.41 | 22.62 | 12.7 | 12.9 | 7.2 | 4.1 |
| 4: 5-15 kg | 11,388 | 202.42 | 33.65 | 16.6 | 14 | 7.2 | 4.02 |
| 5: 15 kg+ | 2,292 | 422.62 | 68.91 | 16.3 | 15.5 | 10 | 3.91 |

