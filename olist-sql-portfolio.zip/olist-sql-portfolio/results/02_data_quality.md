### DQ01_missing_orders

| total_rows | order_id | customer_id | order_status | purchase_ts | approved_at | delivered_carrier | delivered_customer | estimated_delivery |
|---|---|---|---|---|---|---|---|---|
| 99,441 | 0 | 0 | 0 | 0 | 160 | 1,783 | 2,965 | 0 |

### DQ02_missing_products

| total_rows | category | name_length | description_length | photos_qty | weight_g | length_cm | height_cm | width_cm |
|---|---|---|---|---|---|---|---|---|
| 32,951 | 610 | 610 | 610 | 610 | 2 | 2 | 2 | 2 |

### DQ03_missing_reviews

| total_rows | comment_title_missing | pct_title_missing | comment_message_missing | pct_message_missing | score_missing |
|---|---|---|---|---|---|
| 99,224 | 87,656 | 88.34 | 58,247 | 58.7 | 0 |

### DQ04_missing_other_tables

| tbl | missing_cells |
|---|---|
| customers | 0 |
| order_items | 0 |
| order_payments | 0 |
| sellers | 0 |
| geolocation | 0 |
| category_translation | 0 |

### DQ05_key_uniqueness

| candidate_key | total_rows | distinct_values |
|---|---|---|
| orders.order_id | 99,441 | 99,441 |
| orders.customer_id | 99,441 | 99,441 |
| customers.customer_id | 99,441 | 99,441 |
| customers.customer_unique_id | 99,441 | 96,096 |
| order_items.order_id | 112,650 | 98,666 |
| order_items.(order_id, order_item_id) | 112,650 | 112,650 |
| order_payments.order_id | 103,886 | 99,440 |
| order_payments.(order_id, payment_sequential) | 103,886 | 103,886 |
| order_reviews.review_id | 99,224 | 98,410 |
| order_reviews.order_id | 99,224 | 98,673 |
| order_reviews.(review_id, order_id) | 99,224 | 99,224 |
| products.product_id | 32,951 | 32,951 |
| sellers.seller_id | 3,095 | 3,095 |
| geolocation.zip_code_prefix | 1,000,163 | 19,015 |
| category_translation.product_category_name | 71 | 71 |

### DQ06_full_row_duplicates

| tbl | duplicate_rows |
|---|---|
| customers | 0 |
| orders | 0 |
| order_items | 0 |
| order_payments | 0 |
| order_reviews | 0 |
| products | 0 |
| sellers | 0 |
| geolocation | 279,667 |

### DQ07_customer_unique_id_distribution

| orders_per_unique_customer | unique_customers |
|---|---|
| 1 | 93,099 |
| 2 | 2,745 |
| 3 | 203 |
| 4 | 30 |
| 5 | 8 |
| 6 | 6 |
| 7 | 3 |
| 9 | 1 |
| 17 | 1 |

### DQ08_review_grain

| orders_with_multiple_reviews | of_which_conflicting_scores | review_ids_reused_across_orders |
|---|---|---|
| 547 | 202 | 789 |

### DQ09_rows_per_order

| tbl | rows_ | orders | orders_with_gt1_row | max_rows_per_order |
|---|---|---|---|---|
| order_items | 112,650 | 98,666 | 9,803 | 21 |
| order_payments | 103,886 | 99,440 | 2,961 | 29 |
| order_reviews | 99,224 | 98,673 | 547 | 3 |

### DQ10_numeric_ranges

| measure | min_val | max_val | zero_or_negative |
|---|---|---|---|
| order_items.price | 0.85 | 6,735 | 0 |
| order_items.freight_value | 0 | 409.68 | 383 |
| payments.payment_value | 0 | 13,664.08 | 9 |
| payments.payment_installments | 0 | 24 | 2 |
| products.product_weight_g | 0 | 40,425 | 4 |
| reviews.review_score | 1 | 5 | 0 |

### DQ11_payment_type_values

| payment_type | rows_ | zero_value_rows |
|---|---|---|
| credit_card | 76,795 | 0 |
| boleto | 19,784 | 0 |
| voucher | 5,775 | 6 |
| debit_card | 1,529 | 0 |
| not_defined | 3 | 3 |

### DQ12_date_parse_check

| bad_purchase | bad_approved | bad_carrier | bad_customer | bad_estimated | first_purchase | last_purchase |
|---|---|---|---|---|---|---|
| 0 | 0 | 0 | 0 | 0 | 2016-09-04 21:15:19 | 2018-10-17 17:30:18 |

### DQ13_chronology_violations

| approved_before_purchase | carrier_before_approval | carrier_before_purchase | delivered_before_purchase | delivered_before_carrier |
|---|---|---|---|---|
| 0 | 1,359 | 166 | 0 | 23 |

### DQ14_status_vs_timestamps

| order_status | orders | no_approval_ts | no_carrier_ts | no_delivery_ts | has_delivery_ts |
|---|---|---|---|---|---|
| delivered | 96,478 | 14 | 2 | 8 | 96,470 |
| shipped | 1,107 | 0 | 0 | 1,107 | 0 |
| canceled | 625 | 141 | 550 | 619 | 6 |
| unavailable | 609 | 0 | 609 | 609 | 0 |
| invoiced | 314 | 0 | 314 | 314 | 0 |
| processing | 301 | 0 | 301 | 301 | 0 |
| created | 5 | 5 | 5 | 5 | 0 |
| approved | 2 | 0 | 2 | 2 | 0 |

### DQ15_monthly_order_volume

| purchase_month | orders |
|---|---|
| 2016-09 | 4 |
| 2016-10 | 324 |
| 2016-12 | 1 |
| 2017-01 | 800 |
| 2017-02 | 1,780 |
| 2017-03 | 2,682 |
| 2017-04 | 2,404 |
| 2017-05 | 3,700 |
| 2017-06 | 3,245 |
| 2017-07 | 4,026 |
| 2017-08 | 4,331 |
| 2017-09 | 4,285 |
| 2017-10 | 4,631 |
| 2017-11 | 7,544 |
| 2017-12 | 5,673 |
| 2018-01 | 7,269 |
| 2018-02 | 6,728 |
| 2018-03 | 7,211 |
| 2018-04 | 6,939 |
| 2018-05 | 6,873 |
| 2018-06 | 6,167 |
| 2018-07 | 6,292 |
| 2018-08 | 6,512 |
| 2018-09 | 16 |
| 2018-10 | 4 |

### DQ16_untranslated_categories

| product_category_name | products |
|---|---|
| (blank) | 610 |
| portateis_cozinha_e_preparadores_de_alimentos | 10 |
| pc_gamer | 3 |

### DQ17_geolocation_profile

| raw_rows | distinct_rows | distinct_zip_prefixes | points_outside_brazil_bbox | zips_in_gt1_state | zips_with_gt1_city_spelling |
|---|---|---|---|---|---|
| 1,000,163 | 720,496 | 19,015 | 42 | 8 | 551 |

### DQ18_city_spelling_variants_example

| geolocation_city_exact | rows_ |
|---|---|
| sao paulo | 124,780 |
| são paulo | 23,337 |
| sp | 3 |
| sao bernardo do campo | 1 |
| jundiaí | 1 |
| taboão da serra | 1 |
| sãopaulo | 1 |
| sa£o paulo | 1 |
| sao jose dos campos | 1 |

### DQ19_dirty_seller_cities

| seller_city | seller_state | sellers |
|---|---|---|
| sao paulo - sp | SP | 3 |
| santa barbara d´oeste | SP | 2 |
| 04482255 | RJ | 1 |
| auriflama/sp | SP | 1 |
| barbacena/ minas gerais | MG | 1 |
| carapicuiba / sao paulo | SP | 1 |
| cariacica / es | ES | 1 |
| jacarei / sao paulo | SP | 1 |
| lages - sc | SC | 1 |
| maua/sao paulo | SP | 1 |
| mogi das cruzes / sp | SP | 1 |
| novo hamburgo, rio grande do sul, brasil | RS | 1 |
| pinhais/pr | PR | 1 |
| ribeirao preto / sao paulo | SP | 1 |
| rio de janeiro / rio de janeiro | RJ | 1 |
| rio de janeiro \rio de janeiro | RJ | 1 |
| rio de janeiro, rio de janeiro, brasil | RJ | 1 |
| santo andre/sao paulo | SP | 1 |
| sao paulo / sao paulo | SP | 1 |
| sao sebastiao da grama/sp | SP | 1 |
| sbc/sp | SP | 1 |
| sp / sp | SP | 1 |
| vendas@creditparts.com.br | PR | 1 |

### DQ20_orphan_summary

| relationship | orphan_rows |
|---|---|
| orders.customer_id -> customers | 0 |
| order_items.order_id -> orders | 0 |
| order_items.product_id -> products | 0 |
| order_items.seller_id -> sellers | 0 |
| order_payments.order_id -> orders | 0 |
| order_reviews.order_id -> orders | 0 |
| products.category -> translation (non-blank) | 13 |
| customers.zip -> geolocation | 278 |
| sellers.zip -> geolocation | 7 |

### DQ21_parents_without_children

| check_ | rows_ |
|---|---|
| orders without items | 775 |
| orders without payments | 1 |
| orders without reviews | 768 |
| customers without orders | 0 |
| products never sold | 0 |
| sellers with no sales | 0 |

### DQ22_orders_without_items_by_status

| order_status | orders_without_items |
|---|---|
| unavailable | 603 |
| canceled | 164 |
| created | 5 |
| invoiced | 2 |
| shipped | 1 |

### DQ23_items_vs_payments_reconciliation

| orders_in_both | match_within_1_centavo | paid_more_than_items | paid_less_than_items | sum_price_plus_freight | sum_payment_value |
|---|---|---|---|---|---|
| 98,665 | 98,285 | 291 | 89 | 15,843,409.78 | 15,846,280.17 |

