### RV01_enforced_foreign_keys

| child_table | fk_column | parent_table | parent_key | CONSTRAINT_NAME |
|---|---|---|---|---|
| customers | customer_zip_code_prefix | zip_code | zip_code_prefix | fk_customers_zip |
| order_items | order_id | orders | order_id | fk_items_order |
| order_items | product_id | products | product_id | fk_items_product |
| order_items | seller_id | sellers | seller_id | fk_items_seller |
| order_payments | order_id | orders | order_id | fk_payments_order |
| order_reviews | order_id | orders | order_id | fk_reviews_order |
| orders | customer_id | customers | customer_id | fk_orders_customer |
| products | product_category_name | category_translation | product_category_name | fk_products_category |
| sellers | seller_zip_code_prefix | zip_code | zip_code_prefix | fk_sellers_zip |

### RV02_primary_keys

| table_name | primary_key_columns | key_type |
|---|---|---|
| category_translation | product_category_name | single |
| customers | customer_id | single |
| fact_order | order_id | single |
| order_items | order_id,order_item_id | composite |
| order_payments | order_id,payment_sequential | composite |
| order_reviews | review_id,order_id | composite |
| orders | order_id | single |
| products | product_id | single |
| sellers | seller_id | single |
| zip_code | zip_code_prefix | single |

### RV03_orders_customers

| orders | orders_without_customer | customers_without_order | max_orders_per_customer_id | max_orders_per_customer_unique_id |
|---|---|---|---|---|
| 99,441 | 0 | 0 | 1 | 17 |

### RV04_orders_items

| items_without_order | orders_without_items | delivered_orders_without_items | avg_items_per_order | max_items_per_order |
|---|---|---|---|---|
| 0 | 775 | 0 | 1.142 | 21 |

### RV05_items_products_sellers

| items_without_product | products_never_sold | items_without_seller | sellers_never_sold | multi_seller_orders |
|---|---|---|---|---|
| 0 | 0 | 0 | 0 | 1,278 |

### RV06_orders_payments

| payments_without_order | orders_without_payment | which_order | orders_with_multiple_payments |
|---|---|---|---|
| 0 | 1 | bfbd0f9bdef84302105ad712db648a6c (delivered) | 2,961 |

### RV07_orders_reviews

| reviews_without_order | orders_without_review | orders_with_multiple_reviews |
|---|---|---|
| 0 | 768 | 547 |

### RV08_products_categories

| products_without_category | products_with_untranslated_category | products_using_supplemented_translation | translations_never_used |
|---|---|---|---|
| 610 | 0 | 13 | 0 |

### RV09_geography_coverage

| entity | rows_ | rows_without_coordinates | pct_geocoded |
|---|---|---|---|
| customers | 99,441 | 279 | 99.72 |
| sellers | 3,095 | 7 | 99.77 |

### RV10_join_inflation_wrong_vs_right

| method | revenue | payments | joined_rows | orders |
|---|---|---|---|---|
| naive multi-join | 13,876,336.76 | 19,881,945.07 | 115,720 | 96,477 |
| aggregate-then-join | 13,221,363.14 | 15,422,461.77 | 96,477 | 96,477 |
| overstatement (naive - correct) | 654,973.62 | 4,459,483.30 | 19,243 | 0 |

### RV11_worst_inflated_order

| order_id | n_items | n_pay | n_reviews | rows_after_naive_join | true_revenue | naive_revenue |
|---|---|---|---|---|---|---|
| 895ab968e7bb0d5659d16cd74cd1650c | 3 | 21 | 1 | 63 | 109.78 | 2,305.38 |
| fedcd9f7ccdc8cba3a18defedd1a5547 | 2 | 19 | 1 | 38 | 159.98 | 3,039.62 |
| fa65dad1b0e818e3ccc5cb0e39231352 | 1 | 29 | 1 | 29 | 392.55 | 11,383.95 |
| ccf804e764ed5650cd8759557269dc13 | 1 | 26 | 1 | 26 | 49.99 | 1,299.74 |
| 465c2e1bee4561cb39e0db8c5993aafc | 2 | 12 | 1 | 24 | 824 | 9,888 |

