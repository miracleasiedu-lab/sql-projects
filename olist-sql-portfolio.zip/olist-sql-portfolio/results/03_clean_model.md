### CL01_row_reconciliation

| table_name | raw_rows | clean_rows |
|---|---|---|
| orders | 99,441 | 99,441 |
| customers | 99,441 | 99,441 |
| order_items | 112,650 | 112,650 |
| order_payments | 103,886 | 103,886 |
| order_reviews | 99,224 | 99,224 |
| products | 32,951 | 32,951 |
| sellers | 3,095 | 3,095 |
| category_translation | 71 | 73 |
| geolocation -> zip_code | 1,000,163 | 19,177 |

### CL02_zip_code_dimension

| has_geolocation | zip_prefixes | without_coordinates | valid_points_used |
|---|---|---|---|
| 1 | 19,015 | 5 | 720,462 |
| 0 | 162 | 162 | 0 |

### CL03_city_standardisation_effect

| source | distinct_city_values |
|---|---|
| geolocation (raw, exact spelling) | 8,010 |
| zip_code.geo_city (standardised) | 5,771 |
| customers (raw) | 4,119 |
| customers (standardised) | 4,119 |
| sellers (raw) | 611 |
| sellers (standardised) | 584 |

### CL04_seller_city_fixes

| raw_value | cleaned_value | seller_state |
|---|---|---|
| 04482255 | NULL | RJ |
| auriflama/sp | auriflama | SP |
| barbacena/ minas gerais | barbacena | MG |
| carapicuiba / sao paulo | carapicuiba | SP |
| cariacica / es | cariacica | ES |
| jacarei / sao paulo | jacarei | SP |
| lages - sc | lages | SC |
| maua/sao paulo | maua | SP |
| mogi das cruzes / sp | mogi das cruzes | SP |
| novo hamburgo, rio grande do sul, brasil | novo hamburgo | RS |
| pinhais/pr | pinhais | PR |
| ribeirao preto / sao paulo | ribeirao preto | SP |
| rio de janeiro / rio de janeiro | rio de janeiro | RJ |
| rio de janeiro \rio de janeiro | rio de janeiro | RJ |
| rio de janeiro, rio de janeiro, brasil | rio de janeiro | RJ |
| santa barbara d´oeste | santa barbara d'oeste | SP |
| santa barbara d´oeste | santa barbara d'oeste | SP |
| santo andre/sao paulo | santo andre | SP |
| sao paulo - sp | sao paulo | SP |
| sao paulo - sp | sao paulo | SP |
| sao paulo - sp | sao paulo | SP |
| sao paulo / sao paulo | sao paulo | SP |
| sao sebastiao da grama/sp | sao sebastiao da grama | SP |
| sbc | sao bernardo do campo | SP |
| sbc/sp | sao bernardo do campo | SP |
| sp | sao paulo | SP |
| sp | sao paulo | SP |
| sp | sao paulo | SP |
| sp | sao paulo | SP |
| sp / sp | sao paulo | SP |
| vendas@creditparts.com.br | NULL | PR |

### CL05_flags_set

| cleaning_rule | rows_affected |
|---|---|
| products.weight_was_zero -> NULL | 4 |
| products.category NULL (kept, labelled uncategorized) | 610 |
| payments.installments 0 -> 1 | 2 |
| reviews.comment_message NULL (kept) | 58,256 |
| category_translation supplemented | 2 |

