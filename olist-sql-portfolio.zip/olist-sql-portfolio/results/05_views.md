### VW01_view_grain_checks

| object_ | rows_ | distinct_grain_keys | expected_rows |
|---|---|---|---|
| v_order_summary | 99,441 | 99,441 | 99,441 |
| v_item_detail | 112,650 | 112,650 | 112,650 |
| fact_order | 99,441 | 99,441 | 99,441 |

### VW02_revenue_tie_out

| revenue_order_grain | revenue_item_grain | revenue_base_tables |
|---|---|---|
| 13,221,498.11 | 13,221,498.11 | 13,221,498.11 |

### VW03_delivery_chain_quality

| delivered_orders | with_delivery_timestamp | with_valid_full_chain | excluded_from_stage_analysis |
|---|---|---|---|
| 96,478 | 96,470 | 95,082 | 1,388 |

