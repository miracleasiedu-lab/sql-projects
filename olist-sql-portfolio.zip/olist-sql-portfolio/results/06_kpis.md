### KPI01_total_revenue

| total_revenue | total_freight | gmv_incl_freight | total_payment_value |
|---|---|---|---|
| 13,221,498.11 | 2,198,275.64 | 15,419,773.75 | 15,422,461.77 |

### KPI02_total_orders

| all_orders | delivered_orders | canceled_or_unavailable | pct_delivered | pct_canceled_unavailable |
|---|---|---|---|---|
| 99,441 | 96,478 | 1,234 | 97.02 | 1.24 |

### KPI03_unique_customers

| unique_customers_delivered | customer_ids_delivered | overcount_if_customer_id_used |
|---|---|---|
| 93,358 | 96,478 | 3,120 |

### KPI04_average_order_value

| aov_product_revenue | aov_incl_freight | avg_amount_paid |
|---|---|---|
| 137.04 | 159.83 | 159.86 |

### KPI05_items_sold

| items_sold | avg_items_per_order | multi_item_orders | pct_multi_item_orders |
|---|---|---|---|
| 110,197 | 1.142 | 9,635 | 9.99 |

### KPI06_freight

| avg_freight_per_order | avg_freight_per_item | freight_pct_of_revenue |
|---|---|---|
| 22.79 | 19.95 | 16.63 |

### KPI07_review_score

| reviewed_orders | avg_review_score | pct_positive_4_5 | pct_negative_1_2 |
|---|---|---|---|
| 98,673 | 4.086 | 77.07 | 14.69 |

### KPI08_active_sellers

| active_sellers | registered_sellers | avg_revenue_per_active_seller |
|---|---|---|
| 2,970 | 3,095 | 4,451.68 |

### KPI09_delivery_time

| avg_delivery_days | median_delivery_days | p90_delivery_days | orders_measured |
|---|---|---|---|
| 12.56 | 10.22 | 23.1 | 96,470 |

### KPI10_on_time_rate

| delivered_with_date | on_time | late | on_time_rate_pct | avg_days_vs_estimate |
|---|---|---|---|---|
| 96,470 | 89,936 | 6,534 | 93.23 | -11.88 |

### KPI11_executive_scorecard

| revenue | delivered_orders | unique_customers | aov | items_sold | avg_freight | avg_review | active_sellers | avg_delivery_days | on_time_pct |
|---|---|---|---|---|---|---|---|---|---|
| 13,221,498 | 96,478 | 93,358 | 137.04 | 110,197 | 22.79 | 4.09 | 2,970 | 12.6 | 93.2 |

