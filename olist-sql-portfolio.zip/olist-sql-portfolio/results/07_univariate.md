### U01_order_value_distribution

| order_value_band_brl | orders | pct_orders | revenue | pct_revenue |
|---|---|---|---|---|
| 01: < 50 | 28,791 | 29.84 | 916,592 | 6.93 |
| 02: 50-99 | 27,726 | 28.74 | 2,091,913 | 15.82 |
| 03: 100-199 | 25,313 | 26.24 | 3,636,981 | 27.51 |
| 04: 200-499 | 11,148 | 11.55 | 3,321,288 | 25.12 |
| 05: 500-999 | 2,592 | 2.69 | 1,787,162 | 13.52 |
| 06: 1000+ | 908 | 0.94 | 1,467,562 | 11.1 |

### U01b_order_value_summary_stats

| min_ | p25 | median | mean | p75 | p99 | max_ | std_dev |
|---|---|---|---|---|---|---|---|
| 0.85 | 45.9 | 86.57 | 137.04 | 149.9 | 990 | 13,440 | 209.05 |

### U02_category_item_share

| category | items_sold | pct_of_items | cumulative_pct |
|---|---|---|---|
| bed_bath_table | 10,953 | 9.94 | 9.94 |
| health_beauty | 9,465 | 8.59 | 18.53 |
| sports_leisure | 8,431 | 7.65 | 26.18 |
| furniture_decor | 8,160 | 7.4 | 33.58 |
| computers_accessories | 7,644 | 6.94 | 40.52 |
| housewares | 6,795 | 6.17 | 46.69 |
| watches_gifts | 5,859 | 5.32 | 52 |
| telephony | 4,430 | 4.02 | 56.02 |
| garden_tools | 4,268 | 3.87 | 59.9 |
| auto | 4,140 | 3.76 | 63.65 |
| toys | 4,030 | 3.66 | 67.31 |
| cool_stuff | 3,718 | 3.37 | 70.69 |
| perfumery | 3,340 | 3.03 | 73.72 |
| baby | 2,982 | 2.71 | 76.42 |
| electronics | 2,729 | 2.48 | 78.9 |

### U02b_category_count

| categories_with_sales | uncategorized_items |
|---|---|
| 74 | 1,537 |

### U03_order_status

| order_status | orders | pct |
|---|---|---|
| delivered | 96,478 | 97.02 |
| shipped | 1,107 | 1.11 |
| canceled | 625 | 0.63 |
| unavailable | 609 | 0.61 |
| invoiced | 314 | 0.32 |
| processing | 301 | 0.3 |
| created | 5 | 0.01 |
| approved | 2 | 0 |

### U04_payment_methods

| payment_type | orders_using | payment_records | value_paid | pct_value |
|---|---|---|---|---|
| credit_card | 76,505 | 76,795 | 12,542,084 | 78.34 |
| boleto | 19,784 | 19,784 | 2,869,361 | 17.92 |
| voucher | 3,866 | 5,775 | 379,437 | 2.37 |
| debit_card | 1,528 | 1,529 | 217,990 | 1.36 |
| not_defined | 3 | 3 | 0 | 0 |

### U05_review_scores

| review_score | orders | pct |
|---|---|---|
| 5 | 57,008 | 57.77 |
| 4 | 19,038 | 19.29 |
| 3 | 8,133 | 8.24 |
| 2 | 3,131 | 3.17 |
| 1 | 11,363 | 11.52 |

### U06_freight_distribution

| freight_band_brl | orders | pct_orders |
|---|---|---|
| 01: free (0) | 336 | 0.35 |
| 02: 0.01-9.99 | 10,728 | 11.12 |
| 03: 10-19.99 | 52,356 | 54.27 |
| 04: 20-29.99 | 16,349 | 16.95 |
| 05: 30-49.99 | 10,604 | 10.99 |
| 06: 50-99.99 | 5,044 | 5.23 |
| 07: 100+ | 1,061 | 1.1 |

### U07_customers_by_state

| customer_state | unique_customers | pct |
|---|---|---|
| SP | 40,302 | 41.94 |
| RJ | 12,384 | 12.89 |
| MG | 11,259 | 11.72 |
| RS | 5,277 | 5.49 |
| PR | 4,882 | 5.08 |
| SC | 3,534 | 3.68 |
| BA | 3,277 | 3.41 |
| DF | 2,075 | 2.16 |
| ES | 1,964 | 2.04 |
| GO | 1,952 | 2.03 |
| PE | 1,609 | 1.67 |
| CE | 1,313 | 1.37 |

### U08_sellers_by_state

| seller_state | sellers | pct | cumulative_pct |
|---|---|---|---|
| SP | 1,849 | 59.74 | 59.74 |
| PR | 349 | 11.28 | 71.02 |
| MG | 244 | 7.88 | 78.9 |
| SC | 190 | 6.14 | 85.04 |
| RJ | 171 | 5.53 | 90.57 |
| RS | 129 | 4.17 | 94.73 |
| GO | 40 | 1.29 | 96.03 |
| DF | 30 | 0.97 | 97 |
| ES | 23 | 0.74 | 97.74 |
| BA | 19 | 0.61 | 98.35 |

### U09_installments

| installment_band | credit_card_payments | pct | avg_payment_value |
|---|---|---|---|
| 01: 1x | 25,457 | 33.15 | 95.87 |
| 02: 2-3x | 22,874 | 29.79 | 134.23 |
| 03: 4-6x | 16,257 | 21.17 | 181.32 |
| 04: 7-10x | 11,866 | 15.45 | 333.83 |
| 05: 11-24x | 341 | 0.44 | 358.34 |

### U10_delivery_duration

| delivery_band | orders | pct | cumulative_pct |
|---|---|---|---|
| 01: < 3 days | 4,736 | 4.91 | 4.91 |
| 02: 3-6 days | 21,272 | 22.05 | 26.96 |
| 03: 7-13 days | 40,225 | 41.7 | 68.66 |
| 04: 14-20 days | 17,732 | 18.38 | 87.04 |
| 05: 21-29 days | 7,952 | 8.24 | 95.28 |
| 06: 30-59 days | 4,246 | 4.4 | 99.68 |
| 07: 60+ days | 307 | 0.32 | 100 |

