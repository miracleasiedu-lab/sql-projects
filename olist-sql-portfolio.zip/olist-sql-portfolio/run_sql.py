"""Execute a .sql script statement-by-statement against MySQL and capture
results of statements tagged with a preceding comment line `-- @Q <ID>`.
Results are written to results/<script>.json and results/<script>.md."""
import sys, json, re, os, decimal, datetime, pymysql

def split_sql(text):
    stmts, buf, tag, delim = [], [], None, ';'
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.S)
    for line in text.splitlines():
        d = re.match(r'\s*DELIMITER\s+(\S+)', line, re.I)
        if d:
            delim = d.group(1); continue
        m = re.match(r'\s*--\s*@Q\s+(\S+)', line)
        if m:
            tag = m.group(1)
        if delim != ';' and line.rstrip().endswith(delim):
            line = line.rstrip()[:-len(delim)]
            buf.append(line)
            stmts.append((tag, '\n'.join(l for l in buf if not l.strip().startswith('--')).strip())); buf, tag = [], None
            continue
        buf.append(line)
        if delim == ';' and line.rstrip().endswith(';') and not line.lstrip().startswith('--'):
            body = '\n'.join(buf).strip()
            code = '\n'.join(l for l in buf if not l.strip().startswith('--')).strip()
            if code:
                stmts.append((tag, code))
            buf, tag = [], None
    return stmts

def conv(v):
    if isinstance(v, decimal.Decimal): return float(v)
    if isinstance(v, (datetime.date, datetime.datetime)): return str(v)
    return v

def fmt(v):
    if v is None: return 'NULL'
    if isinstance(v, float):
        if v == int(v): v = int(v)
        else: return f'{v:,.2f}' if abs(v) >= 1000 else f'{v:.4f}'.rstrip('0').rstrip('.')
    if isinstance(v, int): return f'{v:,}' if abs(v) >= 1000 else str(v)
    return str(v).replace('|', '\\|')

def to_md(cols, rows, limit=60):
    out = ['| ' + ' | '.join(cols) + ' |', '|' + '---|' * len(cols)]
    for r in rows[:limit]:
        out.append('| ' + ' | '.join(fmt(v) for v in r) + ' |')
    if len(rows) > limit: out.append(f'\n*({len(rows)} rows; first {limit} shown)*')
    return '\n'.join(out)

def main(path, db=None):
    conn = pymysql.connect(user='root', unix_socket='/var/run/mysqld/mysqld.sock',
                           database=db, local_infile=True, autocommit=True)
    cur = conn.cursor()
    results = {}
    for tag, code in split_sql(open(path).read()):
        try:
            cur.execute(code)
        except Exception as e:
            print(f'ERROR in {tag}: {e}\n{code[:400]}'); raise
        if tag and cur.description:
            cols = [d[0] for d in cur.description]
            rows = [[conv(v) for v in r] for r in cur.fetchall()]
            results[tag] = {'cols': cols, 'rows': rows}
    base = os.path.splitext(os.path.basename(path))[0]
    os.makedirs('results', exist_ok=True)
    json.dump(results, open(f'results/{base}.json', 'w'), indent=1, default=str)
    with open(f'results/{base}.md', 'w') as f:
        for t, r in results.items():
            f.write(f'### {t}\n\n{to_md(r["cols"], r["rows"])}\n\n')
    print(f'{path}: {len(results)} tagged results captured')

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
